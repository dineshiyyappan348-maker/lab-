import React from 'react';
import { UserProfile, Achievement } from '../types';
import { getTitleForLevel, calculateXpForNextLevel } from '../utils/storage';
import { EXPERIMENTS_DATA } from '../data/experiments';

interface ProfilePageProps {
  user: UserProfile;
  achievements: Achievement[];
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ user, achievements }) => {
  const levelProgress = Math.min(100, Math.round((user.xp / user.xpForNextLevel) * 100));

  const unlockedBadges = achievements.filter((a) => user.unlockedBadges.includes(a.id));

  // Discipline Progress Stats dynamically calculated from 60 experiments
  const completedIds = user.completedExperimentIds || [];
  const disciplines = [
    {
      name: 'Physics',
      icon: '⚡',
      color: '#080B4F',
      total: EXPERIMENTS_DATA.filter((e) => e.category === 'physics').length,
      completed: completedIds.filter((id: string) =>
        EXPERIMENTS_DATA.find((e) => e.id === id)?.category === 'physics'
      ).length
    },
    {
      name: 'Chemistry',
      icon: '⚗️',
      color: '#A27F35',
      total: EXPERIMENTS_DATA.filter((e) => e.category === 'chemistry').length,
      completed: completedIds.filter((id: string) =>
        EXPERIMENTS_DATA.find((e) => e.id === id)?.category === 'chemistry'
      ).length
    },
    {
      name: 'Biology',
      icon: '🌱',
      color: '#080B4F',
      total: EXPERIMENTS_DATA.filter((e) => e.category === 'biology').length,
      completed: completedIds.filter((id: string) =>
        EXPERIMENTS_DATA.find((e) => e.id === id)?.category === 'biology'
      ).length
    },
    {
      name: 'Environmental Science',
      icon: '🌍',
      color: '#8194C6',
      total: EXPERIMENTS_DATA.filter((e) => e.category === 'environmental').length,
      completed: completedIds.filter((id: string) =>
        EXPERIMENTS_DATA.find((e) => e.id === id)?.category === 'environmental'
      ).length
    }
  ].map((d) => ({
    ...d,
    progress: d.total > 0 ? Math.min(100, Math.round((d.completed / d.total) * 100)) : 0
  }));

  const levelsLadder = [
    { level: 1, title: 'Science Beginner', xp: '0 – 200' },
    { level: 2, title: 'Junior Scientist', xp: '200 – 450' },
    { level: 3, title: 'Lab Explorer', xp: '450 – 700' },
    { level: 4, title: 'Research Student', xp: '700 – 1000' },
    { level: 5, title: 'Young Scientist', xp: '1000 – 1400' },
    { level: 10, title: 'Master Scientist', xp: '4000+' }
  ];

  return (
    <div className="space-y-8 py-6">
      {/* Profile Header Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-10 border border-[#080B4F]/15 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <div className="w-20 h-20 rounded-2xl bg-[#080B4F] text-[#F4E5C8] font-serif-display font-bold text-3xl flex items-center justify-center shadow-lg border-2 border-[#A27F35]">
              {user.name.charAt(0)}
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h1 className="font-serif-display text-2xl sm:text-3xl font-bold text-[#080B4F]">
                  {user.name}
                </h1>
                <span className="bg-[#A27F35] text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                  Level {user.level}
                </span>
              </div>
              <div className="text-xs font-semibold text-[#A27F35]">
                {user.role} · {user.title}
              </div>
              <div className="text-xs font-mono-data text-slate-500">
                {user.email} · {user.settings.gradeLevel}
              </div>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="flex items-center gap-4 border-t sm:border-t-0 pt-4 sm:pt-0 border-slate-100">
            <div className="text-center px-4 py-2 bg-slate-50 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500">Completed</div>
              <div className="font-mono-data text-xl font-bold text-[#080B4F]">
                {user.experimentsCompleted}
              </div>
            </div>
            <div className="text-center px-4 py-2 bg-slate-50 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500">Success</div>
              <div className="font-mono-data text-xl font-bold text-emerald-700">
                {user.successRate}%
              </div>
            </div>
            <div className="text-center px-4 py-2 bg-slate-50 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500">Science XP</div>
              <div className="font-mono-data text-xl font-bold text-[#A27F35]">
                {user.xp}
              </div>
            </div>
          </div>
        </div>

        {/* Animated XP Progress Bar */}
        <div className="p-5 bg-[#080B4F] text-[#F4E5C8] rounded-2xl shadow-inner space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold tracking-wide">
              Level {user.level} Advancement Progress
            </span>
            <span className="font-mono-data text-[#C9A95C] font-semibold">
              XP: {user.xp} / {user.xpForNextLevel} ({levelProgress}%)
            </span>
          </div>

          <div className="w-full h-3 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full bg-[#C9A95C] rounded-full transition-all duration-1000 shadow"
              style={{ width: `${levelProgress}%` }}
            />
          </div>

          <div className="text-[11px] text-[#D5DEEE] text-right font-mono-data">
            {user.xpForNextLevel - user.xp} XP needed to reach Level {user.level + 1} ({getTitleForLevel(user.level + 1)})
          </div>
        </div>
      </div>

      {/* Two Column Grid: Domain Progress & Badges */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Discipline Progress Bars */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-[#080B4F]/15 shadow-sm space-y-6">
          <div>
            <h2 className="font-serif-display text-xl font-bold text-[#080B4F]">
              Discipline Progress & Mastery
            </h2>
            <p className="text-xs text-slate-600 mt-1">
              Curricular completion breakdown across core scientific departments
            </p>
          </div>

          <div className="space-y-5">
            {disciplines.map((d) => (
              <div key={d.name} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <div className="flex items-center gap-2 text-[#080B4F]">
                    <span>{d.icon}</span>
                    <span>{d.name}</span>
                  </div>
                  <span className="font-mono-data text-slate-600">
                    {d.progress}% ({d.completed}/{d.total} Labs)
                  </span>
                </div>

                <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${d.progress}%`,
                      backgroundColor: d.color
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Unlocked Badges Showcase */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-8 border border-[#080B4F]/15 shadow-sm space-y-6">
          <div>
            <h2 className="font-serif-display text-xl font-bold text-[#080B4F]">
              Earned Badges
            </h2>
            <p className="text-xs text-slate-600 mt-1">
              {unlockedBadges.length} honours awarded to date
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {unlockedBadges.map((badge) => (
              <div
                key={badge.id}
                className="p-3 bg-amber-50/50 rounded-xl border border-amber-200/60 flex items-center gap-2.5"
              >
                <span className="text-2xl">{badge.icon}</span>
                <div className="truncate">
                  <div className="font-semibold text-xs text-[#080B4F] truncate">{badge.title}</div>
                  <div className="text-[10px] text-[#A27F35] font-mono-data">+{badge.xpBonus} XP</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Science Level Ladder */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#080B4F]/15 shadow-sm space-y-4">
        <div>
          <h2 className="font-serif-display text-xl font-bold text-[#080B4F]">
            Academic Rank & Level Ladder
          </h2>
          <p className="text-xs text-slate-600 mt-1">
            Complete simulated trials, discover physical constants, and ascend through researcher tiers
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {levelsLadder.map((l) => {
            const isCurrent = user.level === l.level;
            const isPassed = user.level > l.level;

            return (
              <div
                key={l.level}
                className={`p-3 rounded-2xl border text-center transition-all ${
                  isCurrent
                    ? 'bg-[#080B4F] text-[#F4E5C8] border-[#A27F35] shadow-md scale-105'
                    : isPassed
                    ? 'bg-slate-50 border-slate-200 text-slate-800'
                    : 'bg-slate-50/50 border-slate-200/50 text-slate-400 opacity-60'
                }`}
              >
                <div className="text-[10px] font-mono-data uppercase tracking-wider mb-1">
                  Level {l.level}
                </div>
                <div className="font-serif-display font-bold text-xs truncate">
                  {l.title}
                </div>
                <div className="text-[10px] font-mono-data mt-1 opacity-75">
                  {l.xp} XP
                </div>
                {isCurrent && (
                  <div className="mt-1.5 text-[9px] font-bold text-[#C9A95C] uppercase">
                    Current Tier
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
