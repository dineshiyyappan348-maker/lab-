export type ScienceCategory = 'physics' | 'chemistry' | 'biology' | 'environmental';

export type DifficultyLevel = 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert';

export interface InputControlDef {
  id: string;
  label: string;
  unit: string;
  min: number;
  max: number;
  step: number;
  defaultValue: number;
  description: string;
}

export interface ExperimentEquipmentItem {
  name: string;
  icon: string;
  spec: string;
}

export interface ChartDataPoint {
  x: number | string;
  y: number;
  label?: string;
  secondaryY?: number;
}

export interface ExperimentDef {
  id: string;
  title: string;
  category: ScienceCategory;
  subcategory?: string;
  topic?: string;
  keywords?: string[];
  shortDescription: string;
  learningObjective: string;
  scientificPrinciple: string;
  whyItWorks: string;
  observationGuide: string;
  conclusionTemplate: string;
  formula: string;
  difficulty: DifficultyLevel;
  duration: string;
  xpReward: number;
  procedure: string[];
  learningPoints: string[];
  equipment: ExperimentEquipmentItem[];
  controls: InputControlDef[];
  simulationType: string;
  imagePath?: string;
  recommendedNextId?: string;
}

export interface ExperimentResult {
  id: string;
  experimentId: string;
  experimentTitle: string;
  category: ScienceCategory;
  difficulty: DifficultyLevel;
  completedAt: string; // ISO date
  dateFormatted: string;
  xpEarned: number;
  isFirstCompletion?: boolean;
  inputs: Record<string, number | string | boolean>;
  calculatedOutputs: Record<string, number | string>;
  outputUnits: Record<string, string>;
  observation: string;
  conclusion?: string;
  learningResult: string;
  scientificPrinciple: string;
  formula: string;
  chartData?: ChartDataPoint[];
  chartTitle?: string;
  chartXLabel?: string;
  chartYLabel?: string;
  studentNotes?: string;
  accuracyScore: number; // percentage
}

export interface Achievement {
  id: string;
  title: string;
  icon: string;
  description: string;
  categoryRequirement?: ScienceCategory | 'all';
  requiredCount: number;
  xpBonus: number;
  unlockedAt?: string;
}

export interface UserProfile {
  name: string;
  email: string;
  role: string;
  level: number;
  title: string;
  xp: number;
  xpForNextLevel: number;
  experimentsCompleted: number;
  experimentsAttempted: number;
  successRate: number;
  unlockedBadges: string[];
  completedExperimentIds?: string[];
  recentExperimentId?: string;
  recentExperimentProgress?: number;
  settings: {
    soundEnabled: boolean;
    themeMode: 'soft-beige' | 'warm-paper' | 'crisp-ivory';
    gradeLevel: string;
  };
}

export type NavigationPage =
  | 'login'
  | 'dashboard'
  | 'categories'
  | 'category_detail'
  | 'experiment_details'
  | 'virtual_lab'
  | 'experiment_result'
  | 'history'
  | 'achievements'
  | 'profile'
  | 'settings';
