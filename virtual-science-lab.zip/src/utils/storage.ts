import { UserProfile, ExperimentResult, Achievement } from '../types';
import { INITIAL_ACHIEVEMENTS } from '../data/experiments';

const STORAGE_KEYS = {
  USER_PROFILE: 'vsl_user_profile_v1',
  HISTORY: 'vsl_experiment_history_v1',
  ACHIEVEMENTS: 'vsl_achievements_v1'
};

const DEFAULT_PROFILE: UserProfile = {
  name: 'Alex Morgan',
  email: 'alex.morgan@science.edu',
  role: 'Science Explorer',
  level: 4,
  title: 'Research Student',
  xp: 720,
  xpForNextLevel: 1000,
  experimentsCompleted: 18,
  experimentsAttempted: 22,
  successRate: 82,
  unlockedBadges: ['first_exp', 'lab_explorer', 'physics_explorer', 'chem_explorer'],
  completedExperimentIds: ['ohm-law', 'plant-growth', 'acid-base', 'water-quality', 'series-circuit'],
  recentExperimentId: 'ohm-law',
  recentExperimentProgress: 65,
  settings: {
    soundEnabled: true,
    themeMode: 'soft-beige',
    gradeLevel: 'Grade 10 / High School'
  }
};

const SEED_HISTORY: ExperimentResult[] = [
  {
    id: 'res_seed_01',
    experimentId: 'ohm-law',
    experimentTitle: "Ohm's Law",
    category: 'physics',
    difficulty: 'Beginner',
    completedAt: '2026-10-08T08:30:00.000Z',
    dateFormatted: '08 Oct 2026',
    xpEarned: 30,
    inputs: { voltage: 10, resistance: 5 },
    calculatedOutputs: {
      Current: 2.0,
      Power: 20.0,
      Resistance: 5,
      'Filament Temp': 920
    },
    outputUnits: {
      Current: 'A',
      Power: 'W',
      Resistance: 'Ω',
      'Filament Temp': '°C'
    },
    observation: 'The current increased when voltage increased while resistance remained constant.',
    learningResult: 'You successfully demonstrated Ohm\'s Law (I = V / R).',
    scientificPrinciple: 'V = I × R (Voltage = Current × Resistance)',
    formula: 'I = V / R',
    accuracyScore: 100
  },
  {
    id: 'res_seed_02',
    experimentId: 'plant-growth',
    experimentTitle: 'Plant Growth & Environmental Factors',
    category: 'biology',
    difficulty: 'Beginner',
    completedAt: '2026-10-07T14:15:00.000Z',
    dateFormatted: '07 Oct 2026',
    xpEarned: 30,
    inputs: { lightIntensity: 120, co2Level: 500, temperatureBio: 25 },
    calculatedOutputs: {
      'O₂ Bubble Rate': 48,
      'Vegetative Growth': 3.1,
      'Photosynthetic Index': 74,
      'Primary Limiting Factor': 'Light Intensity'
    },
    outputUnits: {
      'O₂ Bubble Rate': 'bubbles/min',
      'Vegetative Growth': 'mm / day',
      'Photosynthetic Index': '%',
      'Primary Limiting Factor': ''
    },
    observation: 'Elevating light exposure accelerated vegetative vigor and growth rate.',
    learningResult: 'Photosynthetic energy synthesis is governed by light and carbon dioxide availability.',
    scientificPrinciple: '6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂',
    formula: 'Growth = G_max · min(f_light, f_water)',
    accuracyScore: 95
  },
  {
    id: 'res_seed_03',
    experimentId: 'neutralization',
    experimentTitle: 'Neutralization & Titration Curve',
    category: 'chemistry',
    difficulty: 'Intermediate',
    completedAt: '2026-10-05T11:45:00.000Z',
    dateFormatted: '05 Oct 2026',
    xpEarned: 50,
    inputs: { acidVol: 25, acidMolarity: 0.1, baseAdded: 25 },
    calculatedOutputs: {
      'Current pH': 7.0,
      'Solution State': 'Exact Neutral Equivalence Point',
      'Equivalence Volume': 25.0,
      'Acid Moles': 0.0025,
      'Base Added Moles': 0.0025
    },
    outputUnits: {
      'Current pH': '',
      'Solution State': '',
      'Equivalence Volume': 'mL',
      'Acid Moles': 'mol',
      'Base Added Moles': 'mol'
    },
    observation: 'At equivalence volume of 25mL, rapid pH transition produced pink endpoint in phenolphthalein.',
    learningResult: 'H⁺ ions from hydrochloric acid precisely neutralized by OH⁻ ions from sodium hydroxide.',
    scientificPrinciple: 'H⁺ + OH⁻ → H₂O',
    formula: 'M₁V₁ = M₂V₂, pH = -log[H⁺]',
    accuracyScore: 98
  },
  {
    id: 'res_seed_04',
    experimentId: 'water-quality',
    experimentTitle: 'Water Quality & Multi-Parameter Index',
    category: 'environmental',
    difficulty: 'Intermediate',
    completedAt: '2026-10-03T16:20:00.000Z',
    dateFormatted: '03 Oct 2026',
    xpEarned: 50,
    inputs: { dissolvedOxygen: 8.5, turbidity: 12, nitrates: 2.0, waterPh: 7.2 },
    calculatedOutputs: {
      'Water Quality Index (WQI)': 84,
      'Ecological Status': 'Good (Supports Aquatic Life)',
      'DO Saturation Score': 94,
      'Clarity & Turbidity Score': 87,
      'Nutrient Pollution Score': 90
    },
    outputUnits: {
      'Water Quality Index (WQI)': 'pts',
      'Ecological Status': '',
      'DO Saturation Score': '/100',
      'Clarity & Turbidity Score': '/100',
      'Nutrient Pollution Score': '/100'
    },
    observation: 'High dissolved oxygen levels correlated with low turbidity, yielding pristine WQI.',
    learningResult: 'Multi-parameter environmental analysis confirms healthy aquatic habitat viability.',
    scientificPrinciple: 'Composite NSF Water Quality Index formulation',
    formula: 'WQI = Σ (w_i × q_i)',
    accuracyScore: 100
  },
  {
    id: 'res_seed_05',
    experimentId: 'series-circuit',
    experimentTitle: 'Series Circuit',
    category: 'physics',
    difficulty: 'Intermediate',
    completedAt: '2026-10-01T09:10:00.000Z',
    dateFormatted: '01 Oct 2026',
    xpEarned: 50,
    inputs: { sourceVoltage: 12, resistor1: 4, resistor2: 6 },
    calculatedOutputs: {
      'Equivalent Resistance': 10,
      'Loop Current': 1.2,
      'Voltage Drop across R₁': 4.8,
      'Voltage Drop across R₂': 7.2,
      'Total Circuit Power': 14.4
    },
    outputUnits: {
      'Equivalent Resistance': 'Ω',
      'Loop Current': 'A',
      'Voltage Drop across R₁': 'V',
      'Voltage Drop across R₂': 'V',
      'Total Circuit Power': 'W'
    },
    observation: 'Sum of individual resistance loads equaled total circuit equivalent resistance.',
    learningResult: 'Kirchhoff’s loop rule verified with proportional voltage drops.',
    scientificPrinciple: 'R_eq = R₁ + R₂, V = V₁ + V₂',
    formula: 'R_eq = Σ R_i, I = V / R_eq',
    accuracyScore: 96
  }
];

export function getStoredUserProfile(): UserProfile {
  if (typeof window === 'undefined') return DEFAULT_PROFILE;
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
    if (!raw) {
      saveUserProfile(DEFAULT_PROFILE);
      return DEFAULT_PROFILE;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_PROFILE;
  }
}

export function saveUserProfile(profile: UserProfile): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
  } catch (e) {
    console.error('Failed to save profile to localStorage', e);
  }
}

export function getStoredHistory(): ExperimentResult[] {
  if (typeof window === 'undefined') return SEED_HISTORY;
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.HISTORY);
    if (!raw) {
      saveHistory(SEED_HISTORY);
      return SEED_HISTORY;
    }
    return JSON.parse(raw);
  } catch {
    return SEED_HISTORY;
  }
}

export function saveHistory(history: ExperimentResult[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(history));
  } catch (e) {
    console.error('Failed to save history to localStorage', e);
  }
}

export function getStoredAchievements(): Achievement[] {
  if (typeof window === 'undefined') return INITIAL_ACHIEVEMENTS;
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ACHIEVEMENTS);
    if (!raw) {
      const initial = INITIAL_ACHIEVEMENTS.map((a) => {
        // Unlock initial default badges
        if (DEFAULT_PROFILE.unlockedBadges.includes(a.id)) {
          return { ...a, unlockedAt: '2026-10-01' };
        }
        return a;
      });
      saveAchievements(initial);
      return initial;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_ACHIEVEMENTS;
  }
}

export function saveAchievements(achievements: Achievement[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.ACHIEVEMENTS, JSON.stringify(achievements));
  } catch (e) {
    console.error('Failed to save achievements', e);
  }
}

export function recordNewExperimentRun(newResult: ExperimentResult): {
  profile: UserProfile;
  newAchievementsUnlocked: Achievement[];
} {
  const currentProfile = getStoredUserProfile();
  const currentHistory = getStoredHistory();
  const currentAchievements = getStoredAchievements();

  // Check if this experiment has already been completed before
  const alreadyCompleted =
    (currentProfile.completedExperimentIds || []).includes(newResult.experimentId) ||
    currentHistory.some((h) => h.experimentId === newResult.experimentId);

  // Award XP only on the first completion to prevent unlimited farming
  const actualXpAwarded = alreadyCompleted ? 0 : newResult.xpEarned;
  newResult.xpEarned = actualXpAwarded;
  newResult.isFirstCompletion = !alreadyCompleted;

  // 1. Add to history
  const updatedHistory = [newResult, ...currentHistory];
  saveHistory(updatedHistory);

  // 2. Track unique completed experiment IDs
  const completedIds = Array.from(
    new Set([...(currentProfile.completedExperimentIds || []), newResult.experimentId])
  );

  // 3. Calculate XP and Level
  const newXp = currentProfile.xp + actualXpAwarded;
  const level = calculateLevelFromXp(newXp);
  const xpForNextLevel = calculateXpForNextLevel(level);
  const title = getTitleForLevel(level);

  const completed = completedIds.length;
  const attempted = currentProfile.experimentsAttempted + 1;
  const successRate = Math.round((completed / attempted) * 100);

  // 4. Check achievements
  const newUnlocked: Achievement[] = [];
  const updatedAchievements = currentAchievements.map((ach) => {
    if (ach.unlockedAt) return ach; // already unlocked

    let count = 0;
    if (ach.categoryRequirement === 'all') {
      count = completedIds.length;
    } else {
      count = updatedHistory.filter((h) => h.category === ach.categoryRequirement).length;
    }

    if (count >= ach.requiredCount) {
      const unlockedAch: Achievement = {
        ...ach,
        unlockedAt: new Date().toISOString()
      };
      newUnlocked.push(unlockedAch);
      return unlockedAch;
    }
    return ach;
  });

  saveAchievements(updatedAchievements);

  const badgeIds = updatedAchievements.filter((a) => a.unlockedAt).map((a) => a.id);

  const updatedProfile: UserProfile = {
    ...currentProfile,
    xp: newXp + newUnlocked.reduce((sum, a) => sum + a.xpBonus, 0),
    level,
    title,
    xpForNextLevel,
    experimentsCompleted: completed,
    experimentsAttempted: attempted,
    successRate,
    unlockedBadges: badgeIds,
    completedExperimentIds: completedIds,
    recentExperimentId: newResult.experimentId,
    recentExperimentProgress: 100
  };

  saveUserProfile(updatedProfile);

  return {
    profile: updatedProfile,
    newAchievementsUnlocked: newUnlocked
  };
}

export function calculateLevelFromXp(xp: number): number {
  if (xp < 200) return 1;
  if (xp < 450) return 2;
  if (xp < 700) return 3;
  if (xp < 1000) return 4;
  if (xp < 1400) return 5;
  if (xp < 1900) return 6;
  if (xp < 2500) return 7;
  if (xp < 3200) return 8;
  if (xp < 4000) return 9;
  return 10;
}

export function calculateXpForNextLevel(level: number): number {
  const thresholds: Record<number, number> = {
    1: 200,
    2: 450,
    3: 700,
    4: 1000,
    5: 1400,
    6: 1900,
    7: 2500,
    8: 3200,
    9: 4000,
    10: 5000
  };
  return thresholds[level] || (level + 1) * 600;
}

export function getTitleForLevel(level: number): string {
  if (level <= 1) return 'Science Beginner';
  if (level === 2) return 'Junior Scientist';
  if (level === 3) return 'Lab Explorer';
  if (level === 4) return 'Research Student';
  if (level === 5) return 'Young Scientist';
  if (level === 6) return 'Associate Researcher';
  if (level === 7) return 'Senior Investigator';
  if (level === 8) return 'Lead Physicist / Chemist';
  if (level === 9) return 'Principal Scientist';
  return 'Master Scientist';
}

export function resetApplicationData(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(STORAGE_KEYS.USER_PROFILE);
  localStorage.removeItem(STORAGE_KEYS.HISTORY);
  localStorage.removeItem(STORAGE_KEYS.ACHIEVEMENTS);
}
