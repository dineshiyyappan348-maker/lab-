import React, { useState } from 'react';
import { ExperimentResult, ScienceCategory } from '../types';
import { ReportModal } from '../components/lab/ReportModal';
import { soundEngine } from '../utils/audio';

interface HistoryPageProps {
  history: ExperimentResult[];
  studentName: string;
  onSelectResult: (result: ExperimentResult) => void;
  onClearHistory?: () => void;
}

export const HistoryPage: React.FC<HistoryPageProps> = ({
  history,
  studentName,
  onSelectResult
}) => {
  const [selectedCategory, setSelectedCategory] = useState<ScienceCategory | 'all'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'highest_xp'>('newest');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeReportModalResult, setActiveReportModalResult] = useState<ExperimentResult | null>(null);

  // Filter
  const filtered = history.filter((item) => {
    if (selectedCategory !== 'all' && item.category !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = item.experimentTitle.toLowerCase().includes(q);
      const matchObservation = item.observation.toLowerCase().includes(q);
      if (!matchTitle && !matchObservation) return false;
    }
    return true;
  });

  // Sort
  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === 'newest') {
      return new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime();
    }
    if (sortBy === 'oldest') {
      return new Date(a.completedAt).getTime() - new Date(b.completedAt).getTime();
    }
    if (sortBy === 'highest_xp') {
      return b.xpEarned - a.xpEarned;
    }
    return 0;
  });

  const categoriesList: { id: ScienceCategory | 'all'; label: string }[] = [
    { id: 'all', label: 'All Experiments' },
    { id: 'chemistry', label: 'Chemistry' },
    { id: 'physics', label: 'Physics' },
    { id: 'biology', label: 'Biology' },
    { id: 'environmental', label: 'Environmental Science' }
  ];

  return (
    <div className="space-y-6 py-6">
      {/* Page Header */}
      <div className="border-b border-[#080B4F]/15 pb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-serif-display text-3xl sm:text-4xl font-bold text-[#080B4F]">
            Experiment History
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Complete archive of your laboratory simulations, data logs, and research records
          </p>
        </div>

        {/* Search input */}
        <div className="relative w-full sm:w-72">
          <span className="absolute left-3.5 top-2.5 text-slate-400 text-sm">🔍</span>
          <input
            type="text"
            placeholder="Search experiments..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-white border border-[#080B4F]/20 focus:outline-none focus:ring-2 focus:ring-[#080B4F]"
          />
        </div>
      </div>

      {/* Filter Tabs & Sorting Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Category Filters */}
        <div className="flex flex-wrap gap-2">
          {categoriesList.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                soundEngine.click();
                setSelectedCategory(cat.id);
              }}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                selectedCategory === cat.id
                  ? 'bg-[#080B4F] text-[#F4E5C8] shadow-sm'
                  : 'bg-white hover:bg-slate-50 text-[#080B4F] border border-[#080B4F]/15'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Sort selector */}
        <div className="flex items-center gap-2 text-xs text-slate-600 self-end sm:self-auto">
          <span>Sort by:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="px-3 py-1.5 rounded-lg bg-white border border-[#080B4F]/20 font-medium text-xs focus:outline-none focus:ring-2 focus:ring-[#080B4F]"
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="highest_xp">Highest XP</option>
          </select>
        </div>
      </div>

      {/* Experiment History Cards Stream */}
      <div className="space-y-4">
        {sorted.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-2xl p-5 border border-[#080B4F]/15 hover:border-[#080B4F] shadow-sm hover:shadow-md transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
          >
            <div className="space-y-1.5 flex-1">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="font-semibold capitalize text-[#080B4F]">
                  {item.category}
                </span>
                <span className="text-slate-300">·</span>
                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                  <span>✓</span>
                  <span>Completed</span>
                </span>
                <span className="text-slate-300">·</span>
                <span className="font-mono-data text-slate-500">
                  {item.dateFormatted}
                </span>
              </div>

              <h3 className="font-serif-display font-bold text-lg sm:text-xl text-[#080B4F]">
                {item.experimentTitle}
              </h3>

              <p className="text-xs text-slate-600 line-clamp-1 italic">
                "{item.observation}"
              </p>
            </div>

            <div className="flex items-center justify-between sm:justify-end gap-4 pt-3 sm:pt-0 border-t sm:border-t-0 border-slate-100">
              <span className="text-xs font-mono-data font-bold text-[#A27F35] bg-amber-50 px-2.5 py-1 rounded border border-amber-200">
                +{item.xpEarned} XP
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    soundEngine.click();
                    setActiveReportModalResult(item);
                  }}
                  className="px-3.5 py-2 rounded-xl text-xs font-medium text-slate-700 hover:bg-slate-100 border border-slate-200 transition-colors"
                >
                  Print Report
                </button>

                <button
                  onClick={() => {
                    soundEngine.click();
                    onSelectResult(item);
                  }}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-[#080B4F] hover:bg-[#0e1363] text-[#F4E5C8] shadow-sm transition-all"
                >
                  VIEW RESULT
                </button>
              </div>
            </div>
          </div>
        ))}

        {sorted.length === 0 && (
          <div className="text-center py-16 bg-white rounded-3xl border border-dashed border-slate-300">
            <div className="text-4xl mb-2">📚</div>
            <h3 className="font-serif-display text-lg font-bold text-slate-700">
              No experiment records found
            </h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              {searchQuery
                ? 'Try searching with a different keyword or removing active filters.'
                : 'Complete your first virtual lab experiment to start building your academic history.'}
            </p>
          </div>
        )}
      </div>

      {/* Printable Report Modal if requested */}
      {activeReportModalResult && (
        <ReportModal
          result={activeReportModalResult}
          studentName={studentName}
          onClose={() => setActiveReportModalResult(null)}
        />
      )}
    </div>
  );
};
