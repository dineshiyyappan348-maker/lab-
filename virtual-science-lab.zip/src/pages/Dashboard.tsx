import React from 'react';
import { UserProfile, ScienceCategory } from '../types';
import { CATEGORIES_DATA, EXPERIMENTS_DATA } from '../data/experiments';
import { soundEngine } from '../utils/audio';

interface DashboardProps {
  user: UserProfile;
  onSelectCategory: (cat: ScienceCategory) => void;
  onSelectExperiment: (expId: string) => void;
  onNavigateHistory: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  user,
  onSelectCategory,
  onSelectExperiment,
  onNavigateHistory
}) => {
  // Determine greeting based on time
  const hour = new Date().getHours();
  const greetingTime = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  // Find recent experiment
  const recentExp = EXPERIMENTS_DATA.find((e) => e.id === user.recentExperimentId) || EXPERIMENTS_DATA[0];

  // Find recommended experiment based on recent
  const recommendedExp =
    EXPERIMENTS_DATA.find((e) => e.id === recentExp.recommendedNextId) ||
    EXPERIMENTS_DATA.find((e) => e.id === 'series-circuit') ||
    EXPERIMENTS_DATA[1];

  return (
    <div className="space-y-10 py-6">
      {/* 1. WELCOME MESSAGE SECTION */}
      <section className="bg-gradient-to-r from-[#080B4F] to-[#121868] text-[#F4E5C8] rounded-3xl p-6 sm:p-10 shadow-xl border border-[#8194C6]/30 relative overflow-hidden">
        {/* Subtle background decoration */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10 pointer-events-none flex items-center justify-center text-9xl">
          🔬
        </div>

        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="flex items-center gap-2 text-xs font-mono-data uppercase tracking-wider text-[#C9A95C]">
            <span>Level {user.level} · {user.title}</span>
            <span>·</span>
            <span>Science Explorer</span>
          </div>

          <h1 className="font-serif-display text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white leading-tight">
            {greetingTime}, Scientist {user.name.split(' ')[0]}!
          </h1>

          <p className="text-sm sm:text-base text-[#D5DEEE] leading-relaxed">
            Ready to perform your next experiment? Explore interactive physics apparatus, chemistry titrations, and environmental simulators.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => {
                soundEngine.click();
                onSelectExperiment(recentExp.id);
              }}
              className="px-5 py-2.5 rounded-xl font-semibold text-xs sm:text-sm bg-[#A27F35] hover:bg-[#8e6f2c] text-white shadow-md transition-all flex items-center gap-2"
            >
              <span>⚡</span>
              <span>Launch Virtual Lab</span>
            </button>
            <button
              onClick={() => {
                soundEngine.click();
                onNavigateHistory();
              }}
              className="px-4 py-2.5 rounded-xl font-semibold text-xs sm:text-sm bg-white/10 hover:bg-white/15 text-[#F4E5C8] border border-white/20 transition-all"
            >
              View Past Experiment Log
            </button>
          </div>
        </div>
      </section>

      {/* 2. QUICK STATISTICS SECTION */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-serif-display text-xl sm:text-2xl font-bold text-[#080B4F]">
            Quick Statistics
          </h2>
          <span className="text-xs text-[#080B4F]/70 font-mono-data">
            Academic Period · Fall 2026
          </span>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Stat 1: Experiments Completed */}
          <div className="bg-white rounded-2xl p-5 border border-[#080B4F]/10 shadow-sm space-y-1">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Experiments Completed
            </div>
            <div className="font-mono-data text-3xl font-extrabold text-[#080B4F]">
              {user.experimentsCompleted}
            </div>
            <div className="text-[11px] text-emerald-600 font-medium">
              Verified lab submissions
            </div>
          </div>

          {/* Stat 2: Experiments This Week */}
          <div className="bg-white rounded-2xl p-5 border border-[#080B4F]/10 shadow-sm space-y-1">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Experiments This Week
            </div>
            <div className="font-mono-data text-3xl font-extrabold text-[#080B4F]">
              5
            </div>
            <div className="text-[11px] text-emerald-600 font-medium">
              On track with syllabus
            </div>
          </div>

          {/* Stat 3: Success Rate */}
          <div className="bg-white rounded-2xl p-5 border border-[#080B4F]/10 shadow-sm space-y-1">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Success Rate
            </div>
            <div className="font-mono-data text-3xl font-extrabold text-[#080B4F]">
              {user.successRate}%
            </div>
            <div className="text-[11px] text-slate-500 font-medium">
              {user.experimentsCompleted} of {user.experimentsAttempted} trials
            </div>
          </div>

          {/* Stat 4: Science XP */}
          <div className="bg-white rounded-2xl p-5 border border-[#080B4F]/10 shadow-sm space-y-1">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Science XP
            </div>
            <div className="font-mono-data text-3xl font-extrabold text-[#A27F35]">
              {user.xp}
            </div>
            <div className="text-[11px] text-[#A27F35] font-medium font-mono-data">
              {user.xpForNextLevel - user.xp} XP to Level {user.level + 1}
            </div>
          </div>
        </div>
      </section>

      {/* 3. EXPLORE EXPERIMENTS — LARGE CATEGORY CARDS */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-serif-display text-xl sm:text-2xl font-bold text-[#080B4F]">
              Explore Experiments
            </h2>
            <p className="text-xs text-[#080B4F]/70">
              Select a scientific discipline to access tailored virtual instruments
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {CATEGORIES_DATA.map((cat) => (
            <div
              key={cat.id}
              onClick={() => {
                soundEngine.click();
                onSelectCategory(cat.id);
              }}
              className="group cursor-pointer bg-white rounded-2xl p-6 border border-[#080B4F]/15 hover:border-[#080B4F] shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-xl bg-[#080B4F] text-white flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                  {cat.icon}
                </div>

                <div>
                  <h3 className="font-serif-display font-bold text-lg text-[#080B4F] group-hover:text-[#A27F35] transition-colors">
                    {cat.name.toUpperCase()}
                  </h3>
                  <p className="text-xs text-slate-600 mt-1 line-clamp-2">
                    {cat.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100">
                  <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
                    Experiments involving:
                  </div>
                  <ul className="text-xs text-slate-700 mt-1 space-y-0.5">
                    {cat.id === 'physics' && (
                      <>
                        <li>• Ohm's Law & Kirchhoff's Circuit Laws</li>
                        <li>• Projectile Motion & Newton's 2nd Law</li>
                        <li>• Hooke's Law, Pendulums & Friction</li>
                        <li>• Optics, Refraction & Standing Waves</li>
                      </>
                    )}
                    {cat.id === 'chemistry' && (
                      <>
                        <li>• Acids, Bases & Titration Curves</li>
                        <li>• pH Measurement & Chemical Indicators</li>
                        <li>• Reaction Rates, Temperature & Catalysts</li>
                        <li>• Solubility, Density & Crystallization</li>
                      </>
                    )}
                    {cat.id === 'biology' && (
                      <>
                        <li>• Plant Growth, Photosynthesis & Transpiration</li>
                        <li>• Cell Osmosis, Diffusion & Organelles</li>
                        <li>• Mendelian Genetics & Punnett Crosses</li>
                        <li>• Enzymes, Respiration & Human Systems</li>
                      </>
                    )}
                    {cat.id === 'environmental' && (
                      <>
                        <li>• Water Quality (WQI) & Eutrophication</li>
                        <li>• Renewable Solar & Wind Energy Grids</li>
                        <li>• Air Quality Index (AQI) & Smog</li>
                        <li>• Climate Modeling & Carbon Footprints</li>
                      </>
                    )}
                  </ul>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="font-mono-data text-slate-500">
                  {cat.experimentCount} Simulations
                </span>
                <span className="font-semibold text-[#080B4F] group-hover:translate-x-1 transition-transform flex items-center gap-1">
                  Enter Lab →
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. CONTINUE LEARNING & RECOMMENDED FOR YOU (2-COLUMNS) */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Continue Learning card */}
        <div className="bg-white rounded-2xl p-6 border border-[#080B4F]/15 shadow-sm space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#A27F35] flex items-center gap-1.5">
                <span>🔥</span>
                <span>Continue Learning</span>
              </span>
              <span className="text-xs font-mono-data text-slate-500 capitalize">
                {recentExp.category}
              </span>
            </div>

            <h3 className="font-serif-display font-bold text-xl text-[#080B4F]">
              {recentExp.title}
            </h3>
            <p className="text-xs text-slate-600 mt-1 line-clamp-2">
              {recentExp.shortDescription}
            </p>

            {/* Progress indicator */}
            <div className="mt-4 space-y-1.5">
              <div className="flex justify-between text-xs font-medium">
                <span className="text-slate-600">Module Progress</span>
                <span className="font-mono-data text-[#080B4F]">
                  {user.recentExperimentProgress || 65}% completed
                </span>
              </div>
              <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#080B4F] rounded-full transition-all duration-500"
                  style={{ width: `${user.recentExperimentProgress || 65}%` }}
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs font-mono-data text-emerald-700">
              +{recentExp.xpReward} XP upon completion
            </span>
            <button
              onClick={() => {
                soundEngine.click();
                onSelectExperiment(recentExp.id);
              }}
              className="px-5 py-2 rounded-xl text-xs font-bold bg-[#080B4F] hover:bg-[#0e1363] text-[#F4E5C8] shadow transition-all"
            >
              CONTINUE
            </button>
          </div>
        </div>

        {/* Recommended For You card */}
        <div className="bg-white rounded-2xl p-6 border border-[#080B4F]/15 shadow-sm space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#080B4F] flex items-center gap-1.5">
                <span>⭐</span>
                <span>Recommended For You</span>
              </span>
              <span className="text-xs font-mono-data text-slate-500 capitalize">
                {recommendedExp.category}
              </span>
            </div>

            <div className="text-xs text-slate-500 italic mb-1">
              "You completed a {recentExp.category} experiment."
            </div>

            <h3 className="font-serif-display font-bold text-xl text-[#080B4F]">
              Try: {recommendedExp.title}
            </h3>
            <p className="text-xs text-slate-600 mt-1 line-clamp-2">
              {recommendedExp.shortDescription}
            </p>

            <div className="flex items-center gap-4 mt-4 text-xs font-mono-data text-slate-600">
              <div>Difficulty: <span className="font-semibold text-[#080B4F]">{recommendedExp.difficulty}</span></div>
              <span>•</span>
              <div>Duration: <span className="font-semibold text-[#080B4F]">{recommendedExp.duration}</span></div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs font-mono-data text-[#A27F35] font-semibold">
              +{recommendedExp.xpReward} XP Reward
            </span>
            <button
              onClick={() => {
                soundEngine.click();
                onSelectExperiment(recommendedExp.id);
              }}
              className="px-5 py-2 rounded-xl text-xs font-bold bg-[#A27F35] hover:bg-[#8e6f2c] text-white shadow transition-all"
            >
              START EXPERIMENT
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
