import React from 'react';
import { ExperimentResult } from '../../types';
import { soundEngine } from '../../utils/audio';

interface ReportModalProps {
  result: ExperimentResult;
  studentName: string;
  onClose: () => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  result,
  studentName,
  onClose
}) => {
  const handlePrint = () => {
    soundEngine.click();
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white text-slate-900 rounded-2xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl relative border border-slate-200">
        {/* Modal Controls Header */}
        <div className="no-print flex items-center justify-between border-b border-slate-200 pb-4 mb-6">
          <div className="flex items-center gap-2">
            <span className="text-xl">📋</span>
            <span className="font-serif-display font-semibold text-lg text-[#080B4F]">
              Scientific Laboratory Report
            </span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="px-4 py-2 rounded-lg bg-[#080B4F] text-[#F4E5C8] hover:bg-[#0e1363] text-xs font-semibold flex items-center gap-1.5 shadow"
            >
              <span>🖨️</span>
              <span>Print / Save as PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100"
              aria-label="Close"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* The Printable Laboratory Document */}
        <div className="print-page space-y-6 text-sm text-slate-800">
          {/* Document Header */}
          <div className="border-b-2 border-[#080B4F] pb-4 flex flex-col sm:flex-row justify-between items-start sm:items-end gap-3">
            <div>
              <div className="text-[11px] font-mono-data tracking-wider uppercase text-slate-500">
                Virtual Science Laboratory · Academic Report
              </div>
              <h2 className="font-serif-display text-2xl font-bold text-[#080B4F] mt-1">
                {result.experimentTitle}
              </h2>
              <div className="text-xs text-slate-600 mt-1">
                Domain: <span className="font-semibold capitalize text-[#080B4F]">{result.category}</span>
              </div>
            </div>
            <div className="text-right text-xs font-mono-data text-slate-600">
              <div>Date: <span className="font-semibold text-slate-900">{result.dateFormatted}</span></div>
              <div>Student: <span className="font-semibold text-slate-900">{studentName}</span></div>
              <div>Report ID: <span className="text-slate-500">{result.id.slice(0, 10)}</span></div>
            </div>
          </div>

          {/* Section 1: Objective & Scientific Principle */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <div className="text-xs font-bold uppercase tracking-wide text-[#080B4F] mb-1">
                Scientific Principle & Governing Formula
              </div>
              <div className="font-mono-data font-semibold text-xs text-[#A27F35] mb-1">
                {result.formula}
              </div>
              <p className="text-xs text-slate-700 leading-relaxed">
                {result.scientificPrinciple}
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <div className="text-xs font-bold uppercase tracking-wide text-[#080B4F] mb-1">
                Learning Award & Verification
              </div>
              <div className="flex items-center gap-3 mt-2">
                <span className="text-2xl">🏆</span>
                <div>
                  <div className="font-mono-data font-bold text-sm text-[#080B4F]">
                    +{result.xpEarned} Science XP Awarded
                  </div>
                  <div className="text-xs text-emerald-700 font-medium">
                    Accuracy Score: {result.accuracyScore}% · Verified Simulation
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Input Variables */}
          <div>
            <div className="text-xs font-bold uppercase tracking-wide text-[#080B4F] mb-2">
              1. Experimental Parameters (Controlled Variables)
            </div>
            <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                {Object.entries(result.inputs).map(([key, val]) => (
                  <div key={key} className="font-mono-data">
                    <span className="text-slate-500 capitalize">{key}: </span>
                    <span className="font-semibold text-slate-900">{String(val)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Section 3: Calculated Results & Quantitative Telemetry */}
          <div>
            <div className="text-xs font-bold uppercase tracking-wide text-[#080B4F] mb-2">
              2. Quantitative Observations & Measured Outputs
            </div>
            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#080B4F] text-[#F4E5C8]">
                  <tr>
                    <th className="py-2 px-3 font-semibold">Parameter Output</th>
                    <th className="py-2 px-3 font-semibold font-mono-data">Measured Value</th>
                    <th className="py-2 px-3 font-semibold font-mono-data">Unit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 bg-white">
                  {Object.entries(result.calculatedOutputs).map(([key, val]) => (
                    <tr key={key} className="hover:bg-slate-50">
                      <td className="py-2 px-3 font-medium text-slate-800">{key}</td>
                      <td className="py-2 px-3 font-mono-data font-semibold text-[#080B4F]">
                        {String(val)}
                      </td>
                      <td className="py-2 px-3 font-mono-data text-slate-500">
                        {result.outputUnits[key] || '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 4: Qualitative Observations & Scientific Deduction */}
          <div>
            <div className="text-xs font-bold uppercase tracking-wide text-[#080B4F] mb-1.5">
              3. Empirical Observation
            </div>
            <p className="p-3 bg-amber-50/60 text-slate-800 rounded-lg border border-amber-200 text-xs leading-relaxed italic">
              "{result.observation}"
            </p>
          </div>

          {/* Section 5: Conclusion & Learning Result */}
          <div className="space-y-3">
            <div>
              <div className="text-xs font-bold uppercase tracking-wide text-[#080B4F] mb-1.5">
                4. Scientific Conclusion
              </div>
              <p className="p-3 bg-emerald-50/70 text-emerald-950 font-medium rounded-lg border border-emerald-200 text-xs leading-relaxed">
                {result.conclusion || result.learningResult}
              </p>
            </div>

            <div>
              <div className="text-xs font-bold uppercase tracking-wide text-[#080B4F] mb-1.5">
                5. Concept Mastery & Takeaway
              </div>
              <p className="p-3 bg-blue-50/60 text-slate-800 rounded-lg border border-blue-200 text-xs leading-relaxed">
                {result.learningResult}
              </p>
            </div>
          </div>

          {/* Official Sign-off stamp */}
          <div className="pt-4 border-t border-slate-200 flex justify-between items-center text-[11px] text-slate-500">
            <div>Virtual Science Lab Simulation Engine v1.0</div>
            <div className="font-mono-data">Digital Certification Stamp: 🔬 VALIDATED</div>
          </div>
        </div>
      </div>
    </div>
  );
};
