import React, { useState } from 'react';
import { NavigationPage, UserProfile } from '../../types';
import { soundEngine } from '../../utils/audio';

interface NavbarProps {
  currentPage: NavigationPage;
  onNavigate: (page: NavigationPage) => void;
  user: UserProfile;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  onNavigate,
  user,
  onLogout
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNav = (page: NavigationPage) => {
    soundEngine.click();
    onNavigate(page);
    setMobileMenuOpen(false);
  };

  const navLinks: { label: string; page: NavigationPage }[] = [
    { label: 'Dashboard', page: 'dashboard' },
    { label: 'Experiments', page: 'categories' },
    { label: 'History', page: 'history' },
    { label: 'Achievements', page: 'achievements' },
    { label: 'Profile', page: 'profile' }
  ];

  return (
    <header className="no-print sticky top-0 z-40 bg-[#080B4F] text-[#F4E5C8] border-b border-[#080B4F]/40 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Zone 1: Single text wordmark in display face */}
          <button
            onClick={() => handleNav('dashboard')}
            className="flex items-center gap-2.5 text-left focus:outline-none group"
          >
            <span className="text-2xl" role="img" aria-label="Microscope">🔬</span>
            <span className="font-serif-display text-xl font-bold tracking-tight text-[#F4E5C8] group-hover:text-white transition-colors whitespace-nowrap">
              Virtual Science Lab
            </span>
          </button>

          {/* Zone 2: 4-6 clean text navigation links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
            {navLinks.map((link) => {
              const isActive =
                currentPage === link.page ||
                (link.page === 'categories' &&
                  (currentPage === 'category_detail' ||
                    currentPage === 'experiment_details' ||
                    currentPage === 'virtual_lab' ||
                    currentPage === 'experiment_result'));

              return (
                <button
                  key={link.page}
                  onClick={() => handleNav(link.page)}
                  className={`relative py-1 transition-colors whitespace-nowrap ${
                    isActive
                      ? 'text-[#C9A95C] font-semibold'
                      : 'text-[#D5DEEE] hover:text-[#F4E5C8]'
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 w-full h-0.5 bg-[#C9A95C] rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1-2 primary actions */}
          <div className="hidden md:flex items-center gap-4">
            {/* Quick XP Chip & Level */}
            <button
              onClick={() => handleNav('profile')}
              className="flex items-center gap-2.5 px-3 py-1.5 rounded-lg bg-[#0e1363] hover:bg-[#151c7d] border border-[#8194C6]/30 transition-all text-xs"
              title="View student profile and XP status"
            >
              <div className="w-6 h-6 rounded-full bg-[#A27F35] text-white flex items-center justify-center font-bold text-[11px]">
                L{user.level}
              </div>
              <div className="text-left">
                <div className="text-[11px] font-semibold text-[#F4E5C8] truncate max-w-[100px]">
                  {user.name}
                </div>
                <div className="text-[10px] text-[#C9A95C] font-mono-data">
                  {user.xp} XP
                </div>
              </div>
            </button>

            {/* Settings button */}
            <button
              onClick={() => handleNav('settings')}
              className={`p-2 rounded-lg transition-colors ${
                currentPage === 'settings'
                  ? 'bg-[#8194C6]/30 text-white'
                  : 'text-[#D5DEEE] hover:text-white hover:bg-white/10'
              }`}
              title="Lab Settings"
              aria-label="Settings"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
                />
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                />
              </svg>
            </button>

            {/* Logout button */}
            <button
              onClick={onLogout}
              className="text-xs text-[#D5DEEE] hover:text-[#C9A95C] px-2 py-1 transition-colors whitespace-nowrap"
              title="Switch user / Sign out"
            >
              Sign out
            </button>
          </div>

          {/* Mobile hamburger */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#F4E5C8] hover:text-white focus:outline-none"
              aria-label="Toggle mobile menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {mobileMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0a0f5a] border-b border-[#8194C6]/30 px-4 pt-2 pb-4 space-y-1">
          <div className="px-3 py-2 mb-2 rounded bg-[#080B4F] flex items-center justify-between text-xs">
            <span className="font-medium text-[#F4E5C8]">{user.name} (L{user.level})</span>
            <span className="font-mono-data text-[#C9A95C]">{user.xp} XP</span>
          </div>
          {navLinks.map((link) => (
            <button
              key={link.page}
              onClick={() => handleNav(link.page)}
              className={`block w-full text-left px-3 py-2 rounded text-sm ${
                currentPage === link.page
                  ? 'bg-[#8194C6]/20 text-[#C9A95C] font-semibold'
                  : 'text-[#D5DEEE] hover:bg-white/5'
              }`}
            >
              {link.label}
            </button>
          ))}
          <button
            onClick={() => handleNav('settings')}
            className="block w-full text-left px-3 py-2 rounded text-sm text-[#D5DEEE] hover:bg-white/5"
          >
            Settings
          </button>
          <button
            onClick={onLogout}
            className="block w-full text-left px-3 py-2 rounded text-sm text-red-300 hover:bg-white/5"
          >
            Sign out
          </button>
        </div>
      )}
    </header>
  );
};
