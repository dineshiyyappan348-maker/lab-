import React, { useState } from 'react';
import { ScienceCategory } from '../types';
import { EXPERIMENTS_DATA, CATEGORIES_DATA } from '../data/experiments';
import { soundEngine } from '../utils/audio';

interface CategoriesPageProps {
  initialCategory?: ScienceCategory | 'all';
  onSelectExperiment: (expId: string) => void;
  completedExperimentIds: string[];
}

export const CategoriesPage: React.FC<CategoriesPageProps> = ({
  initialCategory = 'all',
  onSelectExperiment,
  completedExperimentIds
}) => {
  const [selectedFilter, setSelectedFilter] = useState<ScienceCategory | 'all'>(initialCategory);
  const [difficultyFilter, setDifficultyFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filterTabs: { id: ScienceCategory | 'all'; label: string; icon: string }[] = [
    { id: 'all', label: 'All Laboratories', icon: '🔬' },
    { id: 'physics', label: 'Physics Lab', icon: '⚡' },
    { id: 'chemistry', label: 'Chemistry Lab', icon: '⚗️' },
    { id: 'biology', label: 'Biology Lab', icon: '🌱' },
    { id: 'environmental', label: 'Environmental Science', icon: '🌍' }
  ];

  const filteredExperiments = EXPERIMENTS_DATA.filter((exp) => {
    if (selectedFilter !== 'all' && exp.category !== selectedFilter) return false;
    if (difficultyFilter !== 'all' && exp.difficulty.toLowerCase() !== difficultyFilter.toLowerCase()) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = exp.title.toLowerCase().includes(q);
      const matchDesc = exp.shortDescription.toLowerCase().includes(q);
      const matchObjective = exp.learningObjective.toLowerCase().includes(q);
      if (!matchTitle && !matchDesc && !matchObjective) return false;
    }
    return true;
  });

  return (
    <div className="space-y-8 py-6">
      {/* Header Banner */}
      <div className="border-b border-[#080B4F]/15 pb-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="font-serif-display text-3xl sm:text-4xl font-bold text-[#080B4F]">
              Experiment Laboratory Catalog
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Select an apparatus to conduct simulations, test physical laws, and earn Science XP
            </p>
          </div>

          {/* Quick Search */}
          <div className="relative w-full sm:w-64">
            <span className="absolute left-3 top-2.5 text-slate-400 text-sm">🔍</span>
            <input
              type="text"
              placeholder="Search experiments..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-white border border-[#080B4F]/20 focus:outline-none focus:ring-2 focus:ring-[#080B4F]"
            />
          </div>
        </div>

        {/* Category Tabs (Segmented Buttons) */}
        <div className="flex flex-wrap items-center justify-between gap-3 mt-6">
          <div className="flex flex-wrap gap-2">
            {filterTabs.map((tab) => {
              const isActive = selectedFilter === tab.id;
              const count = tab.id === 'all'
                ? EXPERIMENTS_DATA.length
                : EXPERIMENTS_DATA.filter((e) => e.category === tab.id).length;

              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    soundEngine.click();
                    setSelectedFilter(tab.id);
                  }}
                  className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all whitespace-nowrap ${
                    isActive
                      ? 'bg-[#080B4F] text-[#F4E5C8] shadow-md'
                      : 'bg-white hover:bg-[#FBF4E8] text-[#080B4F] border border-[#080B4F]/15'
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono-data font-bold ${
                      isActive ? 'bg-[#A27F35] text-white' : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500 font-mono-data text-[11px]">Difficulty:</span>
            {['all', 'Beginner', 'Intermediate', 'Advanced', 'Expert'].map((lvl) => (
              <button
                key={lvl}
                onClick={() => {
                  soundEngine.click();
                  setDifficultyFilter(lvl);
                }}
                className={`px-2 py-1 rounded-lg text-[11px] font-medium transition-all ${
                  difficultyFilter.toLowerCase() === lvl.toLowerCase()
                    ? 'bg-[#A27F35] text-white font-bold'
                    : 'bg-white/80 text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                {lvl === 'all' ? 'All' : lvl}
              </button>
            ))}
          </div>
        </div>

        {/* Telemetry Count Summary */}
        <div className="flex items-center justify-between mt-4 text-xs font-mono-data text-slate-500">
          <div>
            Showing <strong className="text-[#080B4F] font-bold">{filteredExperiments.length}</strong> of{' '}
            <strong className="text-[#080B4F] font-bold">{EXPERIMENTS_DATA.length}</strong> Virtual Science Lab Experiments
          </div>
          {completedExperimentIds.length > 0 && (
            <div className="text-emerald-700 font-medium">
              ✓ {completedExperimentIds.length}/{EXPERIMENTS_DATA.length} Mastered
            </div>
          )}
        </div>
      </div>

      {/* Grid of Experiment Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredExperiments.map((exp, idx) => {
          const isCompleted = completedExperimentIds.includes(exp.id);
          const categoryExperiments = EXPERIMENTS_DATA.filter(e => e.category === exp.category);
          const categoryIndex = categoryExperiments.findIndex(e => e.id === exp.id) + 1;

          return (
            <div
              key={exp.id}
              className="bg-white rounded-2xl p-6 border border-[#080B4F]/15 hover:border-[#080B4F] shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                {/* Top card metadata row */}
                <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                  <div className="flex items-center gap-1.5 font-medium">
                    <span className="capitalize text-[#080B4F] font-semibold">{exp.category} #{categoryIndex}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-data">{exp.duration}</span>
                  </div>
                  {isCompleted ? (
                    <span className="text-[11px] font-bold text-emerald-700 flex items-center gap-1">
                      <span>✓</span>
                      <span>Completed</span>
                    </span>
                  ) : (
                    <span className="text-[11px] font-mono-data text-slate-400">
                      Not attempted
                    </span>
                  )}
                </div>

                {/* Subcategory Pill */}
                {exp.subcategory && (
                  <div className="inline-block text-[10px] font-mono-data uppercase tracking-wider text-[#A27F35] bg-amber-50 px-2 py-0.5 rounded border border-amber-200/50 mb-1.5">
                    {exp.subcategory}
                  </div>
                )}

                {/* Title */}
                <h3 className="font-serif-display font-bold text-xl text-[#080B4F] mb-2 leading-snug">
                  {exp.title}
                </h3>

                {/* Description */}
                <p className="text-xs text-slate-600 leading-relaxed mb-4 line-clamp-3">
                  {exp.shortDescription}
                </p>

                {/* Equipment icons */}
                <div className="py-2 border-t border-slate-100">
                  <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Virtual Apparatus
                  </div>
                  <div className="flex flex-wrap gap-1 text-base">
                    {exp.equipment.slice(0, 4).map((eq, i) => (
                      <span key={i} title={eq.name}>
                        {eq.icon}
                      </span>
                    ))}
                    {exp.equipment.length > 4 && (
                      <span className="text-xs text-slate-400 self-center">
                        +{exp.equipment.length - 4}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Bottom footer: XP and Start CTA */}
              <div className="pt-4 mt-2 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <div className="text-[10px] text-slate-400 uppercase">Difficulty</div>
                  <div className="text-xs font-semibold text-[#080B4F]">{exp.difficulty}</div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono-data font-bold text-[#A27F35]">
                    +{exp.xpReward} XP
                  </span>
                  <button
                    onClick={() => {
                      soundEngine.click();
                      onSelectExperiment(exp.id);
                    }}
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-[#080B4F] hover:bg-[#0e1363] text-[#F4E5C8] transition-all shadow-sm flex items-center gap-1.5"
                  >
                    <span>START</span>
                    <span>→</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredExperiments.length === 0 && (
        <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-slate-300">
          <div className="text-3xl mb-2">🔍</div>
          <div className="font-serif-display text-lg text-slate-700">No experiments found</div>
          <p className="text-xs text-slate-500 mt-1">Try adjusting your category filter or search keywords.</p>
        </div>
      )}
    </div>
  );
};
