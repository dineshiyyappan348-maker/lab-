import { ExperimentDef } from '../types';

export const ENVIRONMENTAL_EXPERIMENTS: ExperimentDef[] = [
  {
    id: 'water-quality',
    title: 'Water Quality & Multi-Parameter Index',
    category: 'environmental',
    subcategory: 'Aquatic Ecosystems',
    topic: 'Water Quality Index (WQI)',
    keywords: ['water quality', 'wqi', 'dissolved oxygen', 'turbidity', 'nitrates', 'ph', 'river'],
    shortDescription: 'Sample river and urban watershed streams for Dissolved Oxygen, Turbidity, Nitrates, and pH to calculate the composite Water Quality Index (WQI).',
    learningObjective: 'Calculate the composite NSF Water Quality Index and diagnose aquatic ecosystem health from chemical and physical indicators.',
    scientificPrinciple: 'WQI = Σ (w_i × q_i). Dissolved oxygen is vital for aquatic gill respiration; excessive nitrates trigger algal blooms; turbidity impairs light penetration.',
    whyItWorks: 'Runoff introducing fertilizer nitrates prompts rapid algae proliferation. When algae die, decomposing bacteria consume dissolved oxygen, collapsing aquatic life.',
    observationGuide: 'Healthy streams display DO > 8.0 mg/L and low turbidity, earning Excellent WQI > 90. Industrial runoff collapses DO below 4 mg/L.',
    conclusionTemplate: 'Ecosystem health classified as Good to Excellent. Water sample supports sensitive macroinvertebrates and clean watershed biodiversity.',
    formula: 'WQI = Σ (w_i · q_i),  DO > 6.0 mg/L',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Calibrate an optical dissolved oxygen sensor, nephelometric turbidity meter, and glass pH probe in reference standards.",
      "Collect representative water samples from three watershed sites: pristine mountain headwater, agricultural run-off, and urban outflow.",
      "Measure physical and chemical water quality parameters: Dissolved Oxygen (mg/L), Turbidity (NTU), Nitrates (ppm), and pH.",
      "Normalize measured parameters to sub-index quality ratings (q_i) using standard National Sanitation Foundation (NSF) rating curves.",
      "Calculate the composite weighted Water Quality Index (WQI = Σ w_i · q_i) to categorize overall stream ecological health."
],
    learningPoints: [
      "Water Quality Index (WQI) aggregates diverse physical, chemical, and biological indicators into a single standardized health score (0–100).",
      "High dissolved oxygen (>8 mg/L) is vital for sensitive cold-water fish, whereas levels below 4 mg/L cause widespread hypoxia.",
      "Elevated turbidity blocks sunlight required by benthic submerged plants and absorbs solar heat, decreasing dissolved oxygen capacity."
],
    simulationType: 'water-quality',
    equipment: [
      { name: 'Multiparameter Water Probe', icon: '🌊', spec: 'YSI optical DO & turbidity sensor' },
      { name: 'Colorimetric Nitrate Kit', icon: '🧪', spec: 'Cadmium reduction 0 – 50 ppm' },
      { name: 'Secchi Turbidity Tube', icon: '📏', spec: 'Nephelometric Turbidity Units (NTU)' },
      { name: 'Catchment Sample Bottles', icon: '🍶', spec: 'Sterile river catchment vessels' }
    ],
    controls: [
      { id: 'dissolvedOxygen', label: 'Dissolved Oxygen (DO)', unit: 'mg/L', min: 1.0, max: 12.0, step: 0.5, defaultValue: 8.5, description: 'Free oxygen dissolved in river water' },
      { id: 'turbidity', label: 'Turbidity', unit: 'NTU', min: 1, max: 100, step: 5, defaultValue: 12, description: 'Water cloudiness / suspended solids' },
      { id: 'nitrates', label: 'Nitrate Nitrogen', unit: 'ppm', min: 0.1, max: 20.0, step: 0.5, defaultValue: 2.0, description: 'Agricultural fertilizer / sewage runoff level' },
      { id: 'waterPh', label: 'Water pH', unit: '', min: 4.5, max: 9.5, step: 0.2, defaultValue: 7.2, description: 'Acid-base balance of stream' }
    ]
  },
  {
    id: 'water-pollution',
    title: 'Water Pollution & Eutrophication Modeling',
    category: 'environmental',
    subcategory: 'Aquatic Ecosystems',
    topic: 'BOD & Hypoxic Dead Zones',
    keywords: ['pollution', 'eutrophication', 'bod', 'algae', 'phosphorus', 'hypoxia', 'dead zone'],
    shortDescription: 'Simulate nutrient runoff into freshwater lakes to track agricultural phosphorus accumulation, algal blooms, and dissolved oxygen collapse.',
    learningObjective: 'Model cultural eutrophication and calculate Biological Oxygen Demand (BOD) leading to hypoxic "dead zones".',
    scientificPrinciple: 'Nutrient Enrichment → Algal Bloom → Senescence → Bacterial Decomposition → Dissolved Oxygen Collapse (Hypoxia < 2 mg/L).',
    whyItWorks: 'Phosphorus is typically the limiting macronutrient in freshwater ecosystems. Elevated phosphorus causes cyanobacteria blooms that block sunlight and exhaust oxygen.',
    observationGuide: 'Excess phosphorus (>0.05 mg/L) drives an explosion of surface green algae, followed within 5 simulated days by severe bottom hypoxia.',
    conclusionTemplate: 'Cultural eutrophication modeled: phosphorus runoff triggers massive biological oxygen demand, precipitating fish kills.',
    formula: 'BOD = DO_initial - DO_final (5 days),  Hypoxia threshold < 2.0 mg/L',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Set up a 50-liter aquatic mesocosm tank simulating a freshwater lake ecosystem with native phytoplankon and macroinvertebrates.",
      "Introduce agricultural fertilizer runoff containing dissolved orthophosphate (0.01 to 0.50 mg/L PO₄³⁻).",
      "Monitor daily algal biomass expansion via in-situ fluorometric chlorophyll sensors under constant photoperiod illumination.",
      "Observe algal bloom senescence, die-off, and subsequent bacterial decomposition at the lake bottom.",
      "Measure Biological Oxygen Demand (BOD₅) and track the development of bottom-water hypoxia (<2 mg/L DO)."
],
    learningPoints: [
      "Cultural eutrophication is the human-induced nutrient enrichment of aquatic systems, primarily driven by agricultural phosphorus runoff.",
      "Phosphorus is the limiting nutrient in most freshwaters; excess phosphorus triggers explosive cyanobacteria algal blooms.",
      "Decomposition of dead algal biomass by aerobic bacteria exhausts dissolved oxygen, creating benthic dead zones and fish kills."
],
    simulationType: 'water-pollution',
    equipment: [
      { name: 'Aquatic Mesocosm Tank', icon: '🐟', spec: '50-liter simulated lake ecosystem' },
      { name: 'Spectrophotometric Chlorophyll Sensor', icon: '📊', spec: 'In-situ algal biomass fluorometer' },
      { name: 'BOD Incubation Bottle Array', icon: '🍶', spec: 'Standard 300 mL 5-day sealed vials' },
      { name: 'Dissolved Phosphate Meter', icon: '🧪', spec: 'Molybdenum blue colorimeter' }
    ],
    controls: [
      { id: 'phosphateLoad', label: 'Phosphate Runoff', unit: 'mg/L', min: 0.01, max: 0.50, step: 0.02, defaultValue: 0.08, description: 'Agricultural fertilizer phosphorus input' },
      { id: 'lakeFlushingRate', label: 'Lake Water Turnover', unit: 'days', min: 5, max: 60, step: 5, defaultValue: 30, description: 'Hydrologic residence time of the lake' }
    ]
  },
  {
    id: 'air-quality',
    title: 'Air Quality Index (AQI) & Particulate Matter',
    category: 'environmental',
    subcategory: 'Atmospheric Science',
    topic: 'PM2.5, PM10 & Air Pollution',
    keywords: ['air quality', 'aqi', 'pm2.5', 'pm10', 'smog', 'particulate matter', 'atmosphere'],
    shortDescription: 'Analyze concentrations of PM2.5, PM10, nitrogen dioxide, and ground-level ozone to compute the EPA Air Quality Index (AQI).',
    learningObjective: 'Calculate the multi-pollutant Air Quality Index and identify health risk advisory tiers for sensitive and general populations.',
    scientificPrinciple: 'AQI = [(I_high - I_low)/(C_high - C_low)] × (C - C_low) + I_low. Fine particulates PM2.5 penetrate deep into alveolar lung tissues.',
    whyItWorks: 'Combustion of fossil fuels in vehicles and power plants generates microscopic aerosols and nitrogen oxides that form photochemical smog in presence of sunlight.',
    observationGuide: 'As PM2.5 rises above 35 μg/m³, the AQI crosses 100 into the orange "Unhealthy for Sensitive Groups" threshold.',
    conclusionTemplate: 'AQI score computed. Emission reductions from traffic and industry are essential to maintain clean breathable air.',
    formula: 'AQI = Piecewise linear interpolation of maximum breakpoint indicator',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Deploy optical laser particle counters measuring fine particulate matter (PM2.5 and PM10) alongside electrochemical gas sensors (NO₂, O₃, CO).",
      "Sample ambient air across four distinct monitoring stations: rural forest, suburban residential, busy highway interchange, and industrial zone.",
      "Calculate the Air Quality Index (AQI) for each pollutant using the US EPA piecewise linear interpolation equation.",
      "Identify the \"critical pollutant\" (the constituent responsible for the highest individual sub-index) to assign the final city AQI.",
      "Simulate the effect of traffic restrictions and atmospheric temperature inversions on ground-level particulate accumulation."
],
    learningPoints: [
      "Particulate matter PM2.5 consists of microscopic airborne particles ≤ 2.5 micrometers that penetrate deep into pulmonary alveoli.",
      "Air Quality Index (AQI) translates complex pollutant concentrations into an intuitive color-coded scale from 0 (Good) to 500 (Hazardous).",
      "Thermal inversions trap pollutants near ground level beneath a warm cap of air, multiplying pollutant concentration and exposure risk."
],
    simulationType: 'air-quality',
    equipment: [
      { name: 'Optical Particle Counter (OPC)', icon: '💨', spec: 'Laser light scattering PM2.5/PM10 meter' },
      { name: 'Chemiluminescence NO₂ Analyzer', icon: '📊', spec: 'Ambient gas detector (ppb sensitivity)' },
      { name: 'UV Photometric Ozone Sensor', icon: '☀️', spec: 'Ground-level O₃ monitor' },
      { name: 'Meteorological Weather Mast', icon: '🌡️', spec: 'Wind speed, humidity, temperature' }
    ],
    controls: [
      { id: 'pm25Level', label: 'Fine Particulates (PM2.5)', unit: 'μg/m³', min: 2, max: 150, step: 5, defaultValue: 22, description: 'Aerosols with aerodynamic diameter ≤ 2.5 μm' },
      { id: 'ozonePpb', label: 'Ground-Level Ozone (O₃)', unit: 'ppb', min: 10, max: 120, step: 5, defaultValue: 45, description: 'Photochemical smog oxidant concentration' }
    ]
  },
  {
    id: 'carbon-footprint',
    title: 'Personal Carbon Footprint Calculator',
    category: 'environmental',
    subcategory: 'Climate & Sustainability',
    topic: 'Greenhouse Gas Accounting',
    keywords: ['carbon footprint', 'co2', 'emissions', 'transport', 'diet', 'energy', 'climate change'],
    shortDescription: 'Calculate annual personal greenhouse gas emissions across vehicle transportation, residential electricity, diet, and consumer goods.',
    learningObjective: 'Quantify personal carbon dioxide equivalents (CO₂e) and evaluate the most impactful emissions reduction strategies.',
    scientificPrinciple: 'Carbon Footprint = Σ (Activity Data_i × Emission Factor_i). Burning 1 gallon of gasoline releases ~8.89 kg of CO₂.',
    whyItWorks: 'Fossil energy powering grid electricity and petroleum internal combustion engines releases ancient geological carbon back into the active carbon cycle.',
    observationGuide: 'Switching 5,000 annual driving miles to electric transit combined with vegetarian meal planning cuts annual emissions by over 3.2 metric tons CO₂e.',
    conclusionTemplate: 'Carbon accounting completed. Targeted dietary and transportation choices yield the largest per-capita emission reductions.',
    formula: 'Total CO₂e = E_electricity + E_transport + E_diet + E_waste',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Input household utility energy consumption: monthly kilowatt-hours of grid electricity and therms of natural gas.",
      "Record transportation activity: annual vehicle miles traveled, fuel economy (MPG), public transit usage, and airline flight segments.",
      "Specify dietary patterns (vegan, vegetarian, moderate meat, heavy beef) and consumer goods purchasing frequency.",
      "Apply standard IPCC emissions factors to convert activity data into equivalent kilograms of carbon dioxide (kg CO₂e).",
      "Simulate mitigation interventions (rooftop solar, EV adoption, diet shift) to quantify personal emissions reduction potential."
],
    learningPoints: [
      "A carbon footprint quantifies the total greenhouse gas emissions caused directly and indirectly by an individual, organization, or product.",
      "Electricity generation and personal automotive transportation constitute the largest direct emissions sources for most households.",
      "Ruminant meat consumption (beef and dairy) produces disproportionate emissions due to enteric fermentation methane (CH₄)."
],
    simulationType: 'carbon-footprint',
    equipment: [
      { name: 'Life Cycle Emissions Model', icon: '📊', spec: 'IPCC GHG Scope 1, 2, 3 database' },
      { name: 'Kilowatt-Hour Smart Meter', icon: '⚡', spec: 'Home grid consumption tracker' },
      { name: 'Odometer Telemetry Logger', icon: '🚗', spec: 'Annual vehicle mileage recorder' },
      { name: 'Carbon Equivalent Ledger', icon: '📝', spec: 'Tons CO₂e personal ledger' }
    ],
    controls: [
      { id: 'carMiles', label: 'Annual Vehicle Mileage', unit: 'miles/yr', min: 0, max: 20000, step: 1000, defaultValue: 8000, description: 'Gasoline vehicle travel per year' },
      { id: 'homeKwh', label: 'Monthly Home Electricity', unit: 'kWh/mo', min: 200, max: 1500, step: 50, defaultValue: 650, description: 'Monthly residential power usage' },
      { id: 'dietChoice', label: 'Dietary Pattern', unit: '', min: 0, max: 2, step: 1, defaultValue: 1, description: '0: Plant-Based Vegan (1.5 t/yr), 1: Average Omnivore (2.5 t/yr), 2: Meat-Heavy (3.3 t/yr)' }
    ]
  },
  {
    id: 'renewable-energy',
    title: 'Renewable Microgrid Balance & Storage',
    category: 'environmental',
    subcategory: 'Energy & Climate',
    topic: 'Solar, Wind & Battery Storage',
    keywords: ['renewable energy', 'microgrid', 'solar', 'wind', 'battery', 'storage', 'clean power'],
    shortDescription: 'Balance fluctuating solar PV and wind generation with lithium battery storage to satisfy 24-hour electrical demand with 0% blackout.',
    learningObjective: 'Simulate load-following microgrids and quantify the role of battery storage in smoothing renewable intermittency.',
    scientificPrinciple: 'Power Balance: P_generation(t) = P_load(t) + P_battery(t) + P_curtailed(t). Battery storage buffers daytime solar surplus for evening peak load.',
    whyItWorks: 'Solar produces peak power at midday while residential demand peaks at sunset. Chemical storage bridges the temporal mismatch without fossil peaker plants.',
    observationGuide: 'Sizing battery storage to 80 kWh allows a community microgrid to achieve 100% clean power even through calm, overcast evenings.',
    conclusionTemplate: 'Renewable grid reliability confirmed: pairing wind, solar, and battery storage eliminates intermittency hurdles.',
    formula: 'E_stored(t+1) = E_stored(t) + η_charge·P_excess·Δt - (P_deficit·Δt)/η_discharge',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Configure an isolated microgrid simulation integrating a 100 kW solar photovoltaic array, a 50 kW wind turbine, and a battery storage bank.",
      "Load hourly meteorological datasets containing solar irradiance curves, ambient temperature, and wind speed profiles.",
      "Simulate diurnal electricity generation against a realistic community load profile with morning and evening demand peaks.",
      "Calculate battery state-of-charge (SOC), cycle depth, and backup diesel generator dispatch required during resource lulls.",
      "Determine the microgrid's renewable fraction and analyze energy storage curtailment during midday solar peaks."
],
    learningPoints: [
      "Solar and wind energy exhibit natural temporal complementarity: solar peaks at midday while wind frequently surges at night.",
      "Battery energy storage systems (BESS) decouple renewable generation from immediate consumer demand, bridging intermittency.",
      "Maximizing grid reliability with variable renewables requires diversified generation, demand response, and adequate storage reserves."
],
    simulationType: 'renewable-energy',
    equipment: [
      { name: 'Polycrystalline Solar PV Array', icon: '☀️', spec: '50 kW peak rated capacity' },
      { name: 'Horizontal Wind Turbine Hub', icon: '💨', spec: '30 kW rated variable pitch rotor' },
      { name: 'Lithium Iron Phosphate Battery', icon: '🔋', spec: '100 kWh storage bank' },
      { name: 'Bidirectional Grid Inverter', icon: '⚡', spec: 'Pure sine wave grid tie controller' }
    ],
    controls: [
      { id: 'solarCapacity', label: 'Solar Array Sizing', unit: 'kW', min: 10, max: 100, step: 10, defaultValue: 40, description: 'Installed peak photovoltaic capacity' },
      { id: 'windCapacity', label: 'Wind Turbine Sizing', unit: 'kW', min: 0, max: 60, step: 10, defaultValue: 20, description: 'Installed wind capacity' },
      { id: 'batteryStorage', label: 'Battery Capacity', unit: 'kWh', min: 20, max: 150, step: 10, defaultValue: 80, description: 'Installed chemical storage bank' }
    ]
  },
  {
    id: 'solar-energy',
    title: 'Solar Photovoltaic Energy & Tilt Angle',
    category: 'environmental',
    subcategory: 'Energy & Climate',
    topic: 'Solar Insolation & PV Efficiency',
    keywords: ['solar', 'photovoltaic', 'tilt angle', 'efficiency', 'irradiance', 'sunlight', 'kwh'],
    shortDescription: 'Adjust solar photovoltaic panel tilt angle, surface area, and cell efficiency across seasonal sun angles to maximize daily kWh.',
    learningObjective: 'Calculate solar electric power P = A × η × G × cos(θ) and optimize panel tilt angle to match geographic latitude.',
    scientificPrinciple: 'Solar Power P = A × η × G × cos(θ_incidence). Solar panels generate maximum power when light rays strike perpendicular to the surface (θ = 0).',
    whyItWorks: 'Photons with energy greater than the semiconductor bandgap (1.1 eV in silicon) excite valence electrons to produce continuous direct electric current.',
    observationGuide: 'Matching panel tilt angle to local latitude (approx 30°–35°) maximizes annual energy yield by optimizing average incident ray angles.',
    conclusionTemplate: 'Photovoltaic geometry verified: perpendicular orientation maximizes solar power capture across all insolation levels.',
    formula: 'P_solar = A · η · G · cos(θ_incidence)',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Mount a monocrystalline silicon photovoltaic test panel onto an adjustable solar tracking goniometer.",
      "Measure incident solar irradiance (W/m²) using a calibrated thermopile pyranometer aligned to the panel surface.",
      "Adjust panel tilt angle from 0° (horizontal) to 90° (vertical) and azimuth from east to west across morning, noon, and evening.",
      "Record panel open-circuit voltage (V_oc), short-circuit current (I_sc), and maximum power point (MPP) using a digital curve tracer.",
      "Calculate solar electrical conversion efficiency: η = P_max / (Irradiance × Area) and determine optimal fixed tilt for local latitude."
],
    learningPoints: [
      "Photovoltaic solar panels convert incident photon energy into direct current electricity via the semiconductor photoelectric effect.",
      "Power output is maximized when sunlight strikes perpendicular to the panel surface (cosine loss minimization: P ∝ cos θ_incident).",
      "As a rule of thumb, optimal year-round fixed solar tilt approximately matches the local geographic latitude of the installation."
],
    simulationType: 'solar-energy',
    equipment: [
      { name: 'Adjustable PV Test Bench', icon: '☀️', spec: '0° to 60° tilt goniometer' },
      { name: 'Solar Pyranometer Sensor', icon: '📊', spec: '0 – 1200 W/m² irradiance meter' },
      { name: 'Monocrystalline Silicon Cell', icon: '🟦', spec: '1.6 m² module area' },
      { name: 'True RMS Power Meter', icon: '⚡', spec: 'Digital wattmeter display' }
    ],
    controls: [
      { id: 'solarIrradiance', label: 'Solar Irradiance (G)', unit: 'W/m²', min: 200, max: 1000, step: 50, defaultValue: 800, description: 'Direct sunlight power density' },
      { id: 'panelTiltAngle', label: 'Panel Tilt Angle (θ)', unit: '°', min: 0, max: 60, step: 5, defaultValue: 30, description: 'Angle of PV surface to horizontal' },
      { id: 'panelEfficiency', label: 'Cell Efficiency (η)', unit: '%', min: 14, max: 24, step: 1, defaultValue: 20, description: 'Commercial module efficiency rating' }
    ]
  },
  {
    id: 'wind-energy',
    title: 'Wind Turbine Power & Betz Limit',
    category: 'environmental',
    subcategory: 'Energy & Climate',
    topic: 'Aerodynamic Wind Power & Velocity Cubed',
    keywords: ['wind', 'turbine', 'betz limit', 'wind speed', 'power', 'rotor', 'aerodynamics'],
    shortDescription: 'Rotate aerodynamic turbine blades across variable wind speeds to observe that electrical power output scales with wind speed cubed (v³).',
    learningObjective: 'Calculate kinetic wind power and verify that turbine power output scales with the cube of wind velocity up to the Betz limit (59.3%).',
    scientificPrinciple: 'P_wind = ½ ρ A C_p v³. Power scales with the cube of wind speed (v³). The Betz limit proves no turbine can capture more than 59.3% of wind kinetic energy.',
    whyItWorks: 'Air has mass density ρ (~1.225 kg/m³). Doubling wind velocity doubles both the volume of air passing through the rotor per second and quadruples its kinetic energy per particle.',
    observationGuide: 'Doubling wind speed from 5 m/s to 10 m/s increases generated power by a factor of eight (2³ = 8×).',
    conclusionTemplate: 'Cubic velocity scaling verified: wind energy sites require high average wind speeds to maximize electrical generation.',
    formula: 'P = ½ · ρ · A · C_p · v³,  Betz Maximum C_p = 0.593',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Position a model 3-blade horizontal-axis wind turbine in a calibrated aerodynamic wind tunnel.",
      "Measure freestream upstream wind velocity (v₁) and wake downstream velocity (v₂) using pitot tubes and anemometers.",
      "Vary tunnel wind speed from 2 m/s (cut-in) to 25 m/s (cut-out) while recording rotor RPM, aerodynamic torque, and electrical output.",
      "Adjust rotor blade pitch angle to evaluate lift-to-drag aerodynamic optimization.",
      "Calculate turbine power coefficient C_p = P_actual / (½ ρ A v³) and compare against the theoretical Betz limit (C_p,max = 16/27 ≈ 59.3%)."
],
    learningPoints: [
      "Wind turbine kinetic power scales with the cube of wind speed: P_available = ½ ρ A v³ (doubling wind speed multiplies power by 8×).",
      "The Betz Limit establishes the absolute physical upper bound: no turbine can capture more than 59.3% of the kinetic energy in wind.",
      "Modern utility wind turbines utilize active blade pitch control to maximize aerodynamic lift and prevent structural overspeed in storms."
],
    simulationType: 'wind-energy',
    equipment: [
      { name: 'Wind Tunnel Simulator', icon: '💨', spec: 'Calibrated laminar airflow chamber' },
      { name: '3-Blade Horizontal Rotor', icon: '🌀', spec: 'NACA 4412 aerodynamic airfoils' },
      { name: 'Permanent Magnet Generator', icon: '🎛️', spec: 'Direct drive brushless alternator' },
      { name: 'Torque & RPM Tachometer', icon: '⏱️', spec: 'Rotor angular velocity sensor' }
    ],
    controls: [
      { id: 'windVelocity', label: 'Wind Speed (v)', unit: 'm/s', min: 2.0, max: 18.0, step: 1.0, defaultValue: 8.0, description: 'Ambient air velocity' },
      { id: 'rotorDiameter', label: 'Rotor Diameter (D)', unit: 'm', min: 1.0, max: 5.0, step: 0.5, defaultValue: 2.5, description: 'Swept diameter of turbine blades' },
      { id: 'powerCoeff', label: 'Rotor Aerodynamic C_p', unit: '', min: 0.20, max: 0.48, step: 0.02, defaultValue: 0.40, description: 'Aerodynamic power extraction efficiency' }
    ]
  },
  {
    id: 'forest-ecosystem',
    title: 'Forest Ecosystem & Carbon Sequestration',
    category: 'environmental',
    subcategory: 'Terrestrial Ecosystems',
    topic: 'Biomass Carbon Sinks & Canopy',
    keywords: ['forest', 'carbon sequestration', 'trees', 'biomass', 'canopy', 'co2 storage', 'forestry'],
    shortDescription: 'Calculate carbon storage in temperate and tropical forest biomes across variable tree densities, stand maturity, and conservation protocols.',
    learningObjective: 'Quantify terrestrial carbon sinks and explain how mature forest stands permanently sequester atmospheric CO₂ into woody biomass.',
    scientificPrinciple: 'Photosynthetic wood accumulation converts 1 ton of dry biomass into ~1.83 tons of sequestered CO₂ (C_stored = Biomass × 0.50 × 44/12).',
    whyItWorks: 'Trees serve as biological carbon vaults. Cellulose and lignin synthesize solid structural tissue that locks carbon out of the active atmosphere for centuries.',
    observationGuide: 'Protecting 100 hectares of 50-year-old mixed hardwood forest sequesters over 850 metric tons of atmospheric CO₂ every year.',
    conclusionTemplate: 'Terrestrial carbon sequestration confirmed: forest conservation is an essential cornerstone of climate change mitigation.',
    formula: 'CO₂_sequestered = Area · TreeDensity · BiomassGrowth · (44/12)',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Delineate a 1-hectare representative forest sampling plot in a temperate mixed hardwood forest stand.",
      "Measure diameter at breast height (DBH at 1.3 m) for all mature trees using forestry calipers and diameter tapes.",
      "Apply species-specific allometric biomass regression equations to calculate individual aboveground tree dry mass.",
      "Sample soil cores at 0–30 cm depths to measure soil organic carbon (SOC) concentration via loss-on-ignition calorimetry.",
      "Calculate total ecosystem carbon stock (aboveground biomass + root biomass + deadwood + soil carbon) in metric tons CO₂e/ha."
],
    learningPoints: [
      "Forests are crucial terrestrial carbon sinks, sequestering atmospheric CO₂ into stable woody lignocellulose and rich organic soils.",
      "Approximately 50% of oven-dry tree wood biomass consists of elemental carbon captured through photosynthetic fixation.",
      "Old-growth forests accumulate immense carbon reservoirs in undisturbed soil organic matter and coarse woody debris."
],
    simulationType: 'forest-ecosystem',
    equipment: [
      { name: 'Canopy Densiometer', icon: '🌳', spec: 'Spherical overhead crown cover mirror' },
      { name: 'Tree Diameter Caliper', icon: '📏', spec: 'Diameter at Breast Height (DBH) tool' },
      { name: 'Soil Carbon Corer', icon: '🌱', spec: 'Humus depth organic matter sampler' },
      { name: 'Satellite Forest Biomass Ledger', icon: '🛰️', spec: 'LiDAR canopy height data model' }
    ],
    controls: [
      { id: 'forestHectares', label: 'Protected Forest Area', unit: 'hectares', min: 10, max: 500, step: 25, defaultValue: 100, description: 'Total conserved woodland area' },
      { id: 'standAgeYears', label: 'Average Tree Age', unit: 'years', min: 10, max: 100, step: 10, defaultValue: 45, description: 'Maturity stage of forest stand' },
      { id: 'treeDensityHa', label: 'Tree Density', unit: 'trees/ha', min: 200, max: 800, step: 50, defaultValue: 450, description: 'Number of living mature trees per hectare' }
    ]
  },
  {
    id: 'recycling',
    title: 'Recycling & Life Cycle Assessment (LCA)',
    category: 'environmental',
    subcategory: 'Circular Economy',
    topic: 'Embodied Energy & Material Recovery',
    keywords: ['recycling', 'aluminum', 'plastic', 'paper', 'energy savings', 'landfill', 'circular economy'],
    shortDescription: 'Model energy savings, greenhouse gas avoidance, and landfill conservation by recycling aluminum, plastics, paper, and glass.',
    learningObjective: 'Analyze Life Cycle Assessments (LCA) and quantify embodied energy conserved through circular closed-loop material recycling.',
    scientificPrinciple: 'Recycling aluminum saves 95% of the primary electrical energy needed to refine bauxite ore via the Hall-Héroult smelting process.',
    whyItWorks: 'Remelting post-consumer scrap metals and polymers operates at far lower thermal temperatures than extracting raw virgin ores and petrochemical feedstocks.',
    observationGuide: 'Recycling 1 metric ton of aluminum cans conserves ~14,000 kWh of electric power and avoids 9 metric tons of greenhouse gas emissions.',
    conclusionTemplate: 'Life cycle analysis confirmed: closed-loop recycling dramatically decreases industrial energy consumption and raw mineral extraction.',
    formula: 'Energy_saved = Σ (Mass_i · Factor_i),  CO₂_avoided = Energy_saved · GridIntensity',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Select equal 10.0 kg mass samples of post-consumer commodities: aluminum beverage cans, PET plastic bottles, and paper pulp.",
      "Conduct a Life Cycle Assessment (LCA) tracing energy consumption from virgin bauxite mining, petroleum refining, and timber logging.",
      "Compare virgin production energy against recycled secondary remelting and fiber reprocessing energy requirements.",
      "Calculate avoided greenhouse gas emissions (kg CO₂e/kg material) and avoided landfill volumetric displacement.",
      "Evaluate material recyclability limits: infinite metallurgical closed-loop recycling (aluminum) vs fiber downcycling (paper)."
],
    learningPoints: [
      "Recycling aluminum consumes 95% less energy than refining virgin aluminum from bauxite ore via the Hall-Héroult electrolytic process.",
      "Life Cycle Assessment (LCA) evaluates total environmental burdens across extraction, manufacturing, use, and end-of-life disposal.",
      "Closed-loop recycling preserves inherent material properties, whereas polymers and fibers gradually degrade through successive cycles."
],
    simulationType: 'recycling',
    equipment: [
      { name: 'Automated Materials Sorter', icon: '♻️', spec: 'Near-infrared optical stream separator' },
      { name: 'Industrial Compactor Bale Scale', icon: '⚖️', spec: 'High-density material weigh bridge' },
      { name: 'LCA Embodied Energy Ledger', icon: '📊', spec: 'Ecoinvent manufacturing database' },
      { name: 'Landfill Diversion Monitor', icon: '🗑️', spec: 'Cubic meter volume diversion tracker' }
    ],
    controls: [
      { id: 'aluminumRecovered', label: 'Aluminum Cans', unit: 'kg', min: 10, max: 500, step: 10, defaultValue: 100, description: 'Recovered beverage can mass' },
      { id: 'plasticRecovered', label: 'PET Plastics', unit: 'kg', min: 20, max: 1000, step: 20, defaultValue: 200, description: 'Recovered polymer bottles' },
      { id: 'paperRecovered', label: 'Cardboard & Paper', unit: 'kg', min: 50, max: 2000, step: 50, defaultValue: 500, description: 'Recovered fiber pulp' }
    ]
  },
  {
    id: 'climate-simulation',
    title: 'Planetary Climate & Ice-Albedo Feedback',
    category: 'environmental',
    subcategory: 'Atmospheric Science',
    topic: 'Albedo, Solar Radiative Balance & Warming',
    keywords: ['climate', 'albedo', 'ice feedback', 'radiative balance', 'temperature', 'greenhouse', 'polar'],
    shortDescription: 'Simulate planetary radiative equilibrium (1 - α)S/4 = εσT⁴ and observe destabilizing positive ice-albedo feedback loops.',
    learningObjective: 'Calculate planetary surface temperature from radiative balance and explain how melting ice lowers planetary albedo, amplifying warming.',
    scientificPrinciple: 'Stefan-Boltzmann: Flux = σ T⁴. When warming melts reflective sea ice (albedo ~0.8), dark open ocean (albedo ~0.06) absorbs more solar heat, driving further warming.',
    whyItWorks: 'Dark surfaces absorb incoming shortwave solar radiation and re-radiate longwave thermal infrared, creating a self-reinforcing positive feedback loop.',
    observationGuide: 'Dropping global albedo from 0.30 to 0.27 causes global equilibrium surface temperature to climb by over 2.4°C.',
    conclusionTemplate: 'Positive ice-albedo feedback loop demonstrated: polar cryosphere preservation is vital for global climate stability.',
    formula: 'T_eq = [((1 - α) · S₀) / (4 · ε · σ)]^(1/4)',
    difficulty: 'Advanced',
    duration: '20 min',
    xpReward: 80,
    procedure: [
      "Initialize an Earth Energy Balance Model with baseline planetary solar constant (S₀ = 1361 W/m²) and planetary albedo (α = 0.30).",
      "Set atmospheric greenhouse gas radiative forcing parameters (CO₂, CH₄, N₂O) to pre-industrial 280 ppm baseline.",
      "Simulate 150 years of industrial fossil fuel emissions, elevating atmospheric CO₂ toward 560 ppm (climate doubling).",
      "Activate positive feedback loops: polar ice-albedo loss (sea ice melting lowers albedo) and water vapor feedback (warmer air holds more vapor).",
      "Plot projected global mean surface temperature anomaly, sea level rise, and equilibrium climate sensitivity (ECS)."
],
    learningPoints: [
      "Planetary temperature is governed by the equilibrium between absorbed solar radiation (S₀/4 × (1 - α)) and outgoing thermal infrared radiation (εσT⁴).",
      "Radiative forcing from anthropogenic greenhouse gases restricts thermal infrared escape to space, creating positive planetary energy imbalance.",
      "Positive feedback loops, particularly polar ice albedo loss and water vapor amplification, amplify initial greenhouse warming substantially."
],
    simulationType: 'climate-simulation',
    equipment: [
      { name: 'Planetary Energy Balance Model', icon: '🌍', spec: 'Zero-dimensional climate simulator' },
      { name: 'Radiative Insolation Sensor', icon: '☀️', spec: 'Solar constant S₀ = 1361 W/m²' },
      { name: 'Cryospheric Sea Ice Sensor', icon: '🧊', spec: 'Polar ice coverage area monitor' },
      { name: 'Stefan-Boltzmann Radiometer', icon: '📊', spec: 'Longwave thermal emission tracker' }
    ],
    controls: [
      { id: 'planetaryAlbedo', label: 'Surface Albedo (α)', unit: '', min: 0.15, max: 0.45, step: 0.01, defaultValue: 0.30, description: 'Planetary reflectivity (0.30 Earth average)' },
      { id: 'greenhouseEmissivity', label: 'Atmospheric Emissivity (ε)', unit: '', min: 0.50, max: 0.85, step: 0.02, defaultValue: 0.62, description: 'Effective atmospheric longwave emissivity' }
    ]
  },
  {
    id: 'greenhouse-effect',
    title: 'Greenhouse Effect & Radiative Forcing',
    category: 'environmental',
    subcategory: 'Atmospheric Science',
    topic: 'CO₂, Methane & Thermal Infrared Trapping',
    keywords: ['greenhouse effect', 'co2', 'methane', 'radiative forcing', 'infrared', 'temperature anomaly'],
    shortDescription: 'Model atmospheric infrared absorption as CO₂ concentrations rise from pre-industrial 280 ppm to 600 ppm and compute warming.',
    learningObjective: 'Quantify greenhouse gas radiative forcing (ΔF = 5.35 ln(C/C₀)) and calculate transient global temperature anomalies.',
    scientificPrinciple: 'ΔF = 5.35 · ln(C / C₀) W/m² and ΔT = λ · ΔF. Heteronuclear polyatomic molecules (CO₂, CH₄, H₂O) absorb and re-emit outgoing thermal infrared.',
    whyItWorks: 'Triatomic CO₂ molecules vibrate with dipole moments resonant with 15 μm infrared photons, trapping heat that would otherwise escape to space.',
    observationGuide: 'Doubling CO₂ from 280 to 560 ppm produces ~3.7 W/m² of radiative forcing, yielding ~3.0°C of equilibrium climate warming.',
    conclusionTemplate: 'Greenhouse gas radiative forcing verified: logarithmic relationship explains persistent warming across rising emissions trajectories.',
    formula: 'ΔF = 5.35 · ln(C / C₀),  ΔT = λ · ΔF',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Construct dual sealed glass chambers: Chamber A filled with ambient air (400 ppm CO₂) and Chamber B enriched to 2000 ppm CO₂.",
      "Equip both chambers with high-precision digital thermal probes and surface blackbody infrared absorbing plates.",
      "Direct an identical incandescent/infrared heat lamp toward both chambers for 30 minutes, recording internal temperature rise.",
      "Extinguish the heat lamp and record thermal cooling curves to observe infrared radiation retention by greenhouse gases.",
      "Use a FTIR infrared spectrometer to identify specific absorption bands of CO₂ (4.3 μm and 15 μm) and methane (7.7 μm)."
],
    learningPoints: [
      "The natural greenhouse effect warms Earth's surface by approximately 33°C, rendering the biosphere habitable for liquid water and life.",
      "Greenhouse gases absorb outgoing longwave infrared radiation emitted by Earth, re-radiating thermal energy isotropically in all directions.",
      "Methane is a more potent greenhouse gas than CO₂ molecule-for-molecule due to strong infrared absorption within Earth's atmospheric window."
],
    simulationType: 'greenhouse-effect',
    equipment: [
      { name: 'Atmospheric Gas Absorption Chamber', icon: '🧪', spec: 'Infrared spectrometer pass cell' },
      { name: 'Infrared Thermal Imaging Camera', icon: '🌡️', spec: '8–14 μm longwave infrared sensor' },
      { name: 'CO₂ Precision Gas Diluter', icon: '💨', spec: '200 to 1000 ppm gas blending' },
      { name: 'Radiative Flux Radiometer', icon: '📊', spec: 'Downward thermal radiation sensor' }
    ],
    controls: [
      { id: 'co2Concentration', label: 'Atmospheric CO₂ Level', unit: 'ppm', min: 280, max: 800, step: 20, defaultValue: 420, description: 'Atmospheric carbon dioxide mixing ratio' },
      { id: 'climateSensitivity', label: 'Climate Sensitivity (λ)', unit: '°C/(W/m²)', min: 0.5, max: 1.2, step: 0.1, defaultValue: 0.8, description: 'Climate feedback multiplier' }
    ]
  },
  {
    id: 'ocean-pollution',
    title: 'Ocean Pollution & Marine Microplastics',
    category: 'environmental',
    subcategory: 'Marine Conservation',
    topic: 'Plastic Degradation & Marine Gyres',
    keywords: ['ocean', 'plastic', 'microplastics', 'pollution', 'marine', 'gyre', 'wildlife'],
    shortDescription: 'Track ocean plastic degradation through mechanical wave shearing and UV photodegradation to calculate microparticle counts per km².',
    learningObjective: 'Quantify plastic fragmentation timelines in oceanic gyres and assess ingestion risks to marine trophic webs.',
    scientificPrinciple: 'Macro-plastics do not biodegrade rapidly in seawater; UV photo-oxidation and wave turbulence fragment polymers into microplastics (<5 mm).',
    whyItWorks: 'Solar UV radiation cleaves carbon-carbon polymer chains, making plastic brittle. Wave action shears brittle polymers into billions of micro-fragments.',
    observationGuide: 'A single 500mL plastic water bottle can fragment into over 10,000 microscopic particles, which enter planktonic filter-feeder food webs.',
    conclusionTemplate: 'Plastic persistence documented: fragmented microplastics bioaccumulate across marine food webs, emphasizing prevention at source.',
    formula: 'Particle Count = N₀ · (t_years / t_half)^2.4',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Trawl a 333-micrometer manta net across simulated surface ocean waters to collect floating marine particulate matter.",
      "Transfer collected samples into a density-separation funnel filled with saturated sodium chloride brine (ρ = 1.20 g/cm³).",
      "Digest natural biogenic organic matter using 30% hydrogen peroxide solution to isolate non-biodegradable synthetic polymers.",
      "Filter remaining debris through a 0.45-micron glass fiber filter and examine under a fluorescence stereomicroscope with Nile Red stain.",
      "Count microplastic particles by category (fragments, pellets, fibers, microbeads) and compute particle abundance per cubic meter."
],
    learningPoints: [
      "Microplastics are synthetic polymer particles < 5 mm originating from primary microbeads and secondary fragmentation of macro-debris.",
      "Photodegradation by solar ultraviolet radiation and mechanical wave action brittles surface plastics into billions of microscopic particles.",
      "Microplastics bioaccumulate in marine food webs, adsorbing persistent organic pollutants (POPs) and entering human seafood supplies."
],
    simulationType: 'ocean-pollution',
    equipment: [
      { name: 'Manta Trawl Plankton Net', icon: '🕸️', spec: '333 μm mesh surface tow sampler' },
      { name: 'Fourier Transform IR (FTIR)', icon: '📊', spec: 'Polymer identification spectrometer' },
      { name: 'Wave Action Flume Tank', icon: '🌊', spec: 'Mechanical turbulence shear simulator' },
      { name: 'Stereo Fluorescent Dissecting Scope', icon: '🔬', spec: 'Microplastic particle counter' }
    ],
    controls: [
      { id: 'initialPlasticKg', label: 'Surface Plastic Density', unit: 'kg/km²', min: 10, max: 200, step: 10, defaultValue: 50, description: 'Mass of floating macro-plastics per km²' },
      { id: 'uvExposureYears', label: 'Ocean Weathering Time', unit: 'years', min: 1, max: 20, step: 1, defaultValue: 5, description: 'Years of UV and wave fragmentation' }
    ]
  },
  {
    id: 'biodiversity',
    title: 'Biodiversity & Shannon-Wiener Diversity Index',
    category: 'environmental',
    subcategory: 'Ecology & Conservation',
    topic: 'Shannon Index & Habitat Fragmentation',
    keywords: ['biodiversity', 'shannon index', 'species richness', 'evenness', 'conservation', 'habitat'],
    shortDescription: 'Sample species richness and relative abundance in pristine versus fragmented habitats to calculate the Shannon-Wiener Diversity Index (H\').',
    learningObjective: 'Calculate the Shannon-Wiener Diversity Index (H\') and distinguish between species richness and species evenness.',
    scientificPrinciple: 'H\' = -Σ (p_i × ln p_i). Higher H\' values indicate both high species richness (many species) and high evenness (balanced population proportions).',
    whyItWorks: 'Habitats dominated heavily by one opportunistic species exhibit low evenness and lower ecological resilience to disturbance than balanced ecosystems.',
    observationGuide: 'Pristine rainforest with 12 evenly distributed tree species scores H\' = 2.45, whereas a monoculture timber plantation scores H\' = 0.35.',
    conclusionTemplate: 'Shannon diversity indexing validates that high biodiversity provides greater ecosystem resilience and functional redundancy.',
    formula: "H' = -Σ p_i · ln(p_i),  Evenness J = H' / ln(S)",
    difficulty: 'Advanced',
    duration: '20 min',
    xpReward: 80,
    procedure: [
      "Establish a 100-meter line transect through two contrasting ecosystems: intact native rainforest vs monoculture eucalyptus plantation.",
      "Record the species identity (S) and abundance count (n_i) of all encountered avian and insect taxa in 10-meter quadrats.",
      "Calculate relative species abundance: p_i = n_i / N for each identified species.",
      "Compute the Shannon-Wiener Diversity Index: H = -Σ (p_i · ln p_i) and Simpson's Reciprocal Diversity Index.",
      "Calculate Species Evenness (E = H / ln S) to evaluate community balance and ecological ecosystem resilience against disturbance."
],
    learningPoints: [
      "Biodiversity encompasses both species richness (total number of distinct species) and species evenness (equitability of individual abundance).",
      "The Shannon-Wiener Index (H) increases with both higher richness and more equitable population distribution among species.",
      "High biodiversity buffers ecosystems against pest outbreaks, climate fluctuations, and pathogen invasions through functional redundancy."
],
    simulationType: 'biodiversity',
    equipment: [
      { name: 'Ecological Quadrat Sampler', icon: '📐', spec: '10m × 10m botanical survey grid' },
      { name: 'Species Abundance Matrix', icon: '📊', spec: 'Relative frequency calculator' },
      { name: 'Biodiversity Information System', icon: '💻', spec: 'Shannon-Simpson statistical engine' },
      { name: 'Habitat Boundary Mapper', icon: '🗺️', spec: 'Forest patch fragmentation GIS' }
    ],
    controls: [
      { id: 'speciesRichness', label: 'Species Richness (S)', unit: 'species', min: 3, max: 15, step: 1, defaultValue: 8, description: 'Distinct species observed in quadrat' },
      { id: 'evennessFactor', label: 'Species Evenness Degree', unit: '', min: 1, max: 3, step: 1, defaultValue: 2, description: '1: Heavily Dominated by 1 species, 2: Moderate, 3: Completely Balanced' }
    ]
  },
  {
    id: 'sustainable-city',
    title: 'Sustainable City Index & Urban Metabolism',
    category: 'environmental',
    subcategory: 'Urban Ecology',
    topic: 'Urban Sustainability & Eco-Metrics',
    keywords: ['sustainable city', 'urban ecology', 'public transit', 'green spaces', 'waste diversion', 'sustainability score'],
    shortDescription: 'Balance renewable energy, public transit modal share, water recycling, and green canopy to calculate an overall Urban Sustainability Score.',
    learningObjective: 'Design sustainable metropolitan urban ecosystems and optimize the composite Urban Sustainability Index (0–100).',
    scientificPrinciple: 'Urban Metabolism: Sustainable cities minimize linear resource throughput (energy, water, waste) and maximize circular internal reuse and carbon capture.',
    whyItWorks: 'Investing in electrified mass transit and protected bicycle corridors cuts transportation emissions while expanding urban tree canopy lowers the urban heat island effect.',
    observationGuide: 'Reaching 60% clean transit, 35% urban canopy, and 70% waste diversion drives the city score into the "Platinum Eco-City" tier (>85 pts).',
    conclusionTemplate: 'Urban sustainability modeled: integrated green infrastructure and circular resource stewardship transform cities into net-positive habitats.',
    formula: 'Score = 0.30·Energy + 0.25·Transit + 0.25·Water + 0.20·Waste',
    difficulty: 'Expert',
    duration: '20 min',
    xpReward: 120,
    procedure: [
      "Model a metropolitan urban region comprising 1,000,000 residents across transportation, energy, water, and waste infrastructure.",
      "Adjust urban planning policy levers: transit electrification fraction (10–90%), renewable grid share (10–100%), and urban green canopy (5–50%).",
      "Simulate municipal metabolism inputs (megawatt-hours electricity, megaliters potable water) and outputs (CO₂ emissions, solid waste, runoff).",
      "Calculate Urban Heat Island (UHI) temperature mitigation achieved by expanding reflective roofs and urban tree canopy.",
      "Compute the composite Sustainable Eco-City Index and track municipal greenhouse gas emissions per capita."
],
    learningPoints: [
      "Urban metabolism models the flows of materials, energy, and water through city ecosystems from resource input to waste disposal.",
      "Dense transit-oriented development dramatically reduces transportation energy and per-capita infrastructure material requirements.",
      "Urban green infrastructure (parks, bioswales, green roofs) mitigates the urban heat island effect, purifies stormwater, and enhances air quality."
],
    simulationType: 'sustainable-city',
    equipment: [
      { name: 'Urban Planning GIS Console', icon: '🏙️', spec: 'Metropolitan spatial decision engine' },
      { name: 'Public Transit Modal Tracker', icon: '🚆', spec: 'Fleet electrification & ridership gauge' },
      { name: 'Municipal Water Recycling Flow', icon: '💧', spec: 'Graywater reclamation monitor' },
      { name: 'Urban Heat Island Thermometer', icon: '🌡️', spec: 'Surface temperature difference index' }
    ],
    controls: [
      { id: 'cleanTransitPct', label: 'Electric Public Transit', unit: '%', min: 10, max: 90, step: 10, defaultValue: 50, description: 'Trips taken by electric transit/biking' },
      { id: 'renewableGridPct', label: 'Municipal Clean Energy', unit: '%', min: 10, max: 100, step: 10, defaultValue: 60, description: 'Fraction of city grid powered by renewables' },
      { id: 'greenSpacePct', label: 'Urban Canopy & Parks', unit: '%', min: 5, max: 50, step: 5, defaultValue: 25, description: 'City land area dedicated to green space' }
    ]
  },
  {
    id: 'waste-management',
    title: 'Solid Waste Management & Methane Avoidance',
    category: 'environmental',
    subcategory: 'Circular Economy',
    topic: 'Landfill Diversion & Anaerobic Composting',
    keywords: ['waste management', 'landfill', 'methane', 'composting', 'diversion', 'recycling', 'emissions'],
    shortDescription: 'Divert municipal organic waste from anaerobic landfills into composting and biodigesters to calculate avoided fugitive methane emissions.',
    learningObjective: 'Calculate greenhouse gas avoidance achieved by diverting organic food waste from anaerobic landfills to aerobic composting.',
    scientificPrinciple: 'Anaerobic landfill decomposition of organic waste generates methane (CH₄), which possesses a 20-year Global Warming Potential (GWP) of 84× CO₂.',
    whyItWorks: 'Aerobic composting oxidizes carbon into biogenic CO₂, preventing methanogenic archaebacteria from synthesizing potent greenhouse gas CH₄.',
    observationGuide: 'Diverting 500 tons of food waste per month from a municipal landfill prevents over 380 metric tons of atmospheric CO₂e methane equivalents.',
    conclusionTemplate: 'Waste diversion verified: organic composting eliminates fugitive landfill methane emissions, maximizing climate benefits.',
    formula: 'Avoided CH₄ = Mass_organic · DOC · DOC_f · F · (16/12) · GWP_CH4',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Sample and audit municipal solid waste streams to determine organic food waste, paper, recyclable packaging, and residual fractions.",
      "Simulate waste routing: traditional anaerobic landfill disposal versus controlled aerobic windrow composting and anaerobic biodigestion.",
      "Apply the First Order Decay (FOD) IPCC methodology to calculate fugitive methane generation (CH₄) inside anaerobic landfill cells.",
      "Calculate avoided methane emissions achieved by diverting organic matter into aerobic composting facilities.",
      "Convert avoided methane tonnage into 20-year and 100-year carbon dioxide equivalent offsets (CO₂e) using Global Warming Potential (GWP)."
],
    learningPoints: [
      "Organic food waste buried anaerobically in landfills produces methane (CH₄), a greenhouse gas with a 20-year GWP 84× greater than CO₂.",
      "Aerobic composting introduces atmospheric oxygen, allowing fungi and bacteria to convert organic carbon into biogenic CO₂, preventing methane synthesis.",
      "Diverting organic waste from municipal landfills is among the most cost-effective local actions for immediate climate mitigation."
],
    simulationType: 'waste-management',
    equipment: [
      { name: 'Municipal Waste Stream Scale', icon: '🚛', spec: 'Tonnage weigh-in bridge' },
      { name: 'Aerobic Compost Windrow Turner', icon: '🚜', spec: 'Thermophilic temperature aerator' },
      { name: 'Landfill Gas Extraction Well', icon: '🏭', spec: 'CH₄ flare & gas chromatograph' },
      { name: 'Emissions Avoidance Dashboard', icon: '📊', spec: 'Carbon credit equivalency ledger' }
    ],
    controls: [
      { id: 'monthlyWasteTons', label: 'Monthly Waste Generated', unit: 'tons', min: 100, max: 2000, step: 100, defaultValue: 800, description: 'Total municipal solid waste collected' },
      { id: 'diversionRatePct', label: 'Compost & Recycle Diversion', unit: '%', min: 10, max: 80, step: 10, defaultValue: 40, description: 'Percentage diverted from landfill' }
    ]
  }
];
