import React from 'react';
import { ExperimentDef } from '../types';
import { soundEngine } from '../utils/audio';

interface ExperimentDetailsProps {
  experiment: ExperimentDef;
  onStartExperiment: () => void;
  onBackToCatalog: () => void;
}

export const ExperimentDetailsPage: React.FC<ExperimentDetailsProps> = ({
  experiment,
  onStartExperiment,
  onBackToCatalog
}) => {
  return (
    <div className="max-w-4xl mx-auto py-8 space-y-8">
      {/* Breadcrumb / Back button */}
      <div>
        <button
          onClick={() => {
            soundEngine.click();
            onBackToCatalog();
          }}
          className="text-xs font-semibold text-[#080B4F] hover:text-[#A27F35] flex items-center gap-1 transition-colors"
        >
          <span>←</span>
          <span>Back to Laboratory Catalog</span>
        </button>
      </div>

      {/* Main Details Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-10 border border-[#080B4F]/15 shadow-xl space-y-8">
        {/* Header Block */}
        <div className="border-b border-slate-100 pb-6 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#A27F35]">
              {experiment.category} Laboratory · Module Guide
            </span>
            <div className="flex items-center gap-3 text-xs font-mono-data text-slate-500">
              <span>Difficulty: <strong className="text-[#080B4F]">{experiment.difficulty}</strong></span>
              <span>·</span>
              <span>Duration: <strong className="text-[#080B4F]">{experiment.duration}</strong></span>
              <span>·</span>
              <span className="text-[#A27F35] font-bold">+{experiment.xpReward} XP</span>
            </div>
          </div>

          <h1 className="font-serif-display text-3xl sm:text-4xl font-bold text-[#080B4F]">
            {experiment.title}
          </h1>

          <p className="text-base text-slate-700 leading-relaxed max-w-3xl">
            {experiment.shortDescription}
          </p>
        </div>

        {/* Section 1: Learning Objective */}
        <div className="p-4 rounded-2xl bg-[#FBF4E8] border border-[#080B4F]/10 space-y-1.5">
          <div className="text-xs font-bold uppercase tracking-wider text-[#080B4F] flex items-center gap-2">
            <span>🎯</span>
            <span>Learning Objective</span>
          </div>
          <p className="text-sm text-slate-800 leading-relaxed font-medium">
            {experiment.learningObjective}
          </p>
        </div>

        {/* Section 2: Scientific Principle */}
        <div className="space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-[#080B4F] flex items-center gap-2">
            <span>📐</span>
            <span>Scientific Principle & Governing Formula</span>
          </div>

          <div className="p-4 bg-[#080B4F] text-[#F4E5C8] rounded-2xl font-mono-data text-base font-bold shadow-inner">
            {experiment.formula}
          </div>

          <p className="text-sm text-slate-700 leading-relaxed">
            {experiment.scientificPrinciple}
          </p>

          <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-200/60 text-xs text-slate-700">
            <strong className="text-[#080B4F]">Why It Works: </strong>
            {experiment.whyItWorks}
          </div>
        </div>

        {/* Section 3: Experiment Procedure */}
        {experiment.procedure && experiment.procedure.length > 0 && (
          <div className="space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-[#080B4F] flex items-center gap-2">
              <span>📋</span>
              <span>Laboratory Procedure & Experimental Protocol</span>
            </div>

            <div className="space-y-2.5">
              {experiment.procedure.map((step, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-3 p-3.5 rounded-2xl bg-white border border-[#080B4F]/10 hover:border-[#8194C6]/50 transition-colors shadow-xs"
                >
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-[#080B4F] text-[#F4E5C8] font-mono-data text-xs font-bold flex items-center justify-center">
                    {idx + 1}
                  </span>
                  <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-normal pt-0.5">
                    {step}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Section 4: Key Learning Points */}
        {experiment.learningPoints && experiment.learningPoints.length > 0 && (
          <div className="space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-[#080B4F] flex items-center gap-2">
              <span>💡</span>
              <span>Key Scientific Learning Points</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {experiment.learningPoints.map((point, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-2xl bg-[#FBF4E8] border border-[#A27F35]/30 space-y-1.5"
                >
                  <div className="text-[11px] font-bold text-[#A27F35] uppercase tracking-wider flex items-center gap-1.5">
                    <span>✨</span>
                    <span>Core Insight #{idx + 1}</span>
                  </div>
                  <p className="text-xs text-slate-800 leading-relaxed">
                    {point}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Section 5: Experimental Variables & Controls */}
        <div className="space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-[#080B4F] flex items-center gap-2">
            <span>🎛️</span>
            <span>Independent & Controlled Variables</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {experiment.controls.map((ctrl) => (
              <div
                key={ctrl.id}
                className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1 shadow-xs"
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-[#080B4F]">{ctrl.label}</span>
                  <span className="font-mono-data text-[11px] text-[#A27F35] bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                    {ctrl.defaultValue} {ctrl.unit}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 font-mono-data">
                  Range: {ctrl.min} – {ctrl.max} {ctrl.unit} (Step: {ctrl.step})
                </div>
                <p className="text-[11px] text-slate-600 italic">
                  {ctrl.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Section 6: Required Virtual Equipment */}
        <div className="space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-[#080B4F] flex items-center gap-2">
            <span>🧰</span>
            <span>Required Virtual Equipment</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {experiment.equipment.map((eq, idx) => (
              <div
                key={idx}
                className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex items-center gap-3"
              >
                <span className="text-2xl">{eq.icon}</span>
                <div className="truncate">
                  <div className="font-semibold text-xs text-[#080B4F] truncate">{eq.name}</div>
                  <div className="text-[11px] text-slate-500 truncate">{eq.spec}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Launch Button */}
        <div className="pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-slate-500">
            Simulation will open in an interactive virtual workbench with live telemetry and data recording.
          </div>

          <button
            onClick={() => {
              soundEngine.click();
              onStartExperiment();
            }}
            className="w-full sm:w-auto px-8 py-4 rounded-2xl font-bold text-sm bg-[#080B4F] hover:bg-[#0e1363] text-[#F4E5C8] shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
          >
            <span>🔬</span>
            <span>START EXPERIMENT</span>
            <span>→</span>
          </button>
        </div>
      </div>
    </div>
  );
};
