import React, { useState } from 'react';
import { ChartDataPoint } from '../../types';

interface LiveChartProps {
  data: ChartDataPoint[];
  title?: string;
  xLabel?: string;
  yLabel?: string;
}

export const LiveChart: React.FC<LiveChartProps> = ({
  data,
  title = 'Simulation Data Telemetry',
  xLabel = 'X Axis',
  yLabel = 'Y Axis'
}) => {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  if (!data || data.length === 0) return null;

  const width = 500;
  const height = 200;
  const padding = { top: 25, right: 30, bottom: 40, left: 55 };

  const innerWidth = width - padding.left - padding.right;
  const innerHeight = height - padding.top - padding.bottom;

  const yValues = data.map((d) => d.y);
  const minY = Math.min(0, ...yValues);
  const maxY = Math.max(...yValues) * 1.15 || 10;

  // Scale functions
  const getX = (index: number) => {
    if (data.length <= 1) return padding.left + innerWidth / 2;
    return padding.left + (index / (data.length - 1)) * innerWidth;
  };

  const getY = (val: number) => {
    const range = maxY - minY || 1;
    return padding.top + innerHeight - ((val - minY) / range) * innerHeight;
  };

  // Build SVG path
  const pointsString = data
    .map((d, i) => `${getX(i)},${getY(d.y)}`)
    .join(' ');

  const areaString = `M ${getX(0)},${getY(minY)} ${data
    .map((d, i) => `L ${getX(i)},${getY(d.y)}`)
    .join(' ')} L ${getX(data.length - 1)},${getY(minY)} Z`;

  return (
    <div className="w-full bg-[#050736] rounded-2xl p-4 border border-[#8194C6]/30 shadow-md">
      <div className="flex items-center justify-between mb-2">
        <h5 className="font-serif-display font-semibold text-xs text-[#F4E5C8] tracking-wide flex items-center gap-2">
          <span>📈</span>
          <span>{title}</span>
        </h5>
        {hoverIndex !== null && (
          <span className="text-[11px] font-mono-data text-[#C9A95C] bg-[#080B4F] px-2 py-0.5 rounded border border-[#8194C6]/30">
            {xLabel}: {data[hoverIndex].x} · {yLabel}: {data[hoverIndex].y}
          </span>
        )}
      </div>

      <div className="relative w-full overflow-hidden">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto">
          <defs>
            <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#C9A95C" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#C9A95C" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grid lines */}
          {[0, 0.25, 0.5, 0.75, 1.0].map((frac, i) => {
            const y = padding.top + innerHeight * frac;
            const val = maxY - (maxY - minY) * frac;
            return (
              <g key={i}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={width - padding.right}
                  y2={y}
                  stroke="#8194C6"
                  strokeOpacity="0.15"
                  strokeDasharray="4 4"
                />
                <text
                  x={padding.left - 8}
                  y={y + 3}
                  textAnchor="end"
                  fill="#8194C6"
                  fontSize="9"
                  fontFamily="monospace"
                >
                  {val >= 1000 ? `${(val / 1000).toFixed(1)}k` : val.toFixed(1)}
                </text>
              </g>
            );
          })}

          {/* Fill Area under curve */}
          <path d={areaString} fill="url(#chartGradient)" />

          {/* Main Polyline Curve */}
          <polyline
            fill="none"
            stroke="#C9A95C"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            points={pointsString}
          />

          {/* Interactive Data Nodes */}
          {data.map((d, i) => {
            const cx = getX(i);
            const cy = getY(d.y);
            const isHovered = hoverIndex === i;

            return (
              <g
                key={i}
                onMouseEnter={() => setHoverIndex(i)}
                onMouseLeave={() => setHoverIndex(null)}
                className="cursor-pointer"
              >
                <circle
                  cx={cx}
                  cy={cy}
                  r={isHovered ? 5.5 : 3.5}
                  fill={isHovered ? '#FFFFFF' : '#C9A95C'}
                  stroke="#080B4F"
                  strokeWidth="2"
                  className="transition-all"
                />
              </g>
            );
          })}

          {/* X Axis Labels */}
          {data.map((d, i) => {
            if (data.length > 8 && i % Math.ceil(data.length / 6) !== 0 && i !== data.length - 1) {
              return null;
            }
            const cx = getX(i);
            return (
              <text
                key={i}
                x={cx}
                y={height - padding.bottom + 16}
                textAnchor="middle"
                fill="#8194C6"
                fontSize="9"
                fontFamily="monospace"
              >
                {String(d.x)}
              </text>
            );
          })}

          {/* Axis Labels */}
          <text
            x={padding.left + innerWidth / 2}
            y={height - 6}
            textAnchor="middle"
            fill="#D5DEEE"
            fontSize="10"
            fontWeight="bold"
          >
            {xLabel}
          </text>
          <text
            x={14}
            y={padding.top + innerHeight / 2}
            textAnchor="middle"
            fill="#D5DEEE"
            fontSize="10"
            fontWeight="bold"
            transform={`rotate(-90 14 ${padding.top + innerHeight / 2})`}
          >
            {yLabel}
          </text>
        </svg>
      </div>
    </div>
  );
};
