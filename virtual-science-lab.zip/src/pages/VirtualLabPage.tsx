import React, { useState } from 'react';
import { ExperimentDef, ExperimentResult } from '../types';
import { computeSimulation, buildExperimentResultRecord } from '../utils/simulationEngine';
import { InteractiveWorkbench } from '../components/lab/InteractiveWorkbench';
import { ControlPanel } from '../components/lab/ControlPanel';
import { soundEngine } from '../utils/audio';

interface VirtualLabPageProps {
  experiment: ExperimentDef;
  onFinishExperiment: (result: ExperimentResult) => void;
  onExitLab: () => void;
}

export const VirtualLabPage: React.FC<VirtualLabPageProps> = ({
  experiment,
  onFinishExperiment,
  onExitLab
}) => {
  // Controlled inputs initialized to experiment defaults
  const [inputs, setInputs] = useState<Record<string, number | string | boolean>>(() => {
    const init: Record<string, number | string | boolean> = {};
    experiment.controls.forEach((ctrl) => {
      init[ctrl.id] = ctrl.defaultValue;
    });
    return init;
  });

  const [isRunning, setIsRunning] = useState(true);
  const [circuitSwitchClosed, setCircuitSwitchClosed] = useState(true);
  const [learningModeOpen, setLearningModeOpen] = useState(false);
  const [procedureOpen, setProcedureOpen] = useState(false);
  const [completedSteps, setCompletedSteps] = useState<Record<number, boolean>>({});

  const toggleStepCompleted = (stepIdx: number) => {
    soundEngine.click();
    setCompletedSteps((prev) => ({
      ...prev,
      [stepIdx]: !prev[stepIdx]
    }));
  };

  // Dynamic simulation computation
  const simulation = computeSimulation(experiment, inputs);

  const handleInputChange = (key: string, val: number) => {
    soundEngine.click();
    setInputs((prev) => ({
      ...prev,
      [key]: val
    }));
  };

  const handleResetDefaults = () => {
    const init: Record<string, number | string | boolean> = {};
    experiment.controls.forEach((ctrl) => {
      init[ctrl.id] = ctrl.defaultValue;
    });
    setInputs(init);
    setCircuitSwitchClosed(true);
  };

  const handleRunToggle = () => {
    setIsRunning(!isRunning);
  };

  const handleToggleSwitch = () => {
    setCircuitSwitchClosed(!circuitSwitchClosed);
  };

  const handleExecuteAndFinish = () => {
    const finalRecord = buildExperimentResultRecord(experiment, inputs, simulation);
    onFinishExperiment(finalRecord);
  };

  return (
    <div className="space-y-6 py-6">
      {/* Top Breadcrumb & Action bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#080B4F]/15 pb-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              soundEngine.click();
              onExitLab();
            }}
            className="text-xs font-semibold text-[#080B4F] hover:text-[#A27F35] flex items-center gap-1 transition-colors"
          >
            <span>←</span>
            <span>Exit Lab</span>
          </button>
          <span className="text-slate-400">/</span>
          <span className="font-serif-display font-bold text-lg text-[#080B4F]">
            {experiment.title}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              soundEngine.click();
              setProcedureOpen(!procedureOpen);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              procedureOpen
                ? 'bg-[#080B4F] text-[#F4E5C8] shadow'
                : 'bg-white hover:bg-slate-50 text-[#080B4F] border border-[#080B4F]/20'
            }`}
          >
            <span>📋</span>
            <span>Protocol Steps ({Object.values(completedSteps).filter(Boolean).length}/{experiment.procedure?.length || 5})</span>
          </button>

          <button
            onClick={() => {
              soundEngine.click();
              setLearningModeOpen(!learningModeOpen);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              learningModeOpen
                ? 'bg-[#A27F35] text-white shadow'
                : 'bg-white hover:bg-slate-50 text-[#080B4F] border border-[#080B4F]/20'
            }`}
          >
            <span>🧠</span>
            <span>Learning Mode {learningModeOpen ? 'Active' : 'Guide'}</span>
          </button>
        </div>
      </div>

      {/* PROCEDURE PROTOCOL STEPS ACCORDION */}
      {procedureOpen && experiment.procedure && (
        <div className="bg-white rounded-2xl p-6 border-2 border-[#080B4F]/30 shadow-md space-y-4 animate-in fade-in duration-300">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-serif-display font-bold text-base text-[#080B4F] flex items-center gap-2">
              <span>📋</span>
              <span>Laboratory Experimental Procedure</span>
            </h3>
            <span className="text-xs font-mono-data text-slate-500">
              Click step to mark completed
            </span>
          </div>

          <div className="space-y-2.5">
            {experiment.procedure.map((step, idx) => {
              const isDone = Boolean(completedSteps[idx]);
              return (
                <div
                  key={idx}
                  onClick={() => toggleStepCompleted(idx)}
                  className={`flex items-start gap-3 p-3 rounded-xl border transition-all cursor-pointer ${
                    isDone
                      ? 'bg-emerald-50/70 border-emerald-300 text-slate-700'
                      : 'bg-slate-50 border-slate-200 text-slate-800 hover:border-[#8194C6]'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={isDone}
                    onChange={() => {}}
                    className="mt-1 w-4 h-4 rounded text-[#080B4F] accent-[#080B4F] cursor-pointer"
                  />
                  <div className="text-xs sm:text-sm leading-relaxed">
                    <span className="font-bold mr-1.5 font-mono-data text-[#080B4F]">Step {idx + 1}:</span>
                    <span className={isDone ? 'line-through text-slate-500' : ''}>{step}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* LEARNING MODE ACCORDION/PANEL */}
      {learningModeOpen && (
        <div className="bg-white rounded-2xl p-6 border-2 border-[#A27F35]/40 shadow-md space-y-4 animate-in fade-in duration-300">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-serif-display font-bold text-base text-[#080B4F] flex items-center gap-2">
              <span>🧠</span>
              <span>Learning Mode · Concept Guide</span>
            </h3>
            <button
              onClick={() => setLearningModeOpen(false)}
              className="text-xs text-slate-400 hover:text-slate-700"
            >
              ✕ Close Guide
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs text-slate-700">
            {/* What you will learn */}
            <div className="p-3 bg-amber-50/50 rounded-xl border border-amber-200/60 space-y-1">
              <div className="font-bold text-[#A27F35] uppercase tracking-wider">
                What You Will Learn
              </div>
              <p className="leading-relaxed">{experiment.learningObjective}</p>
            </div>

            {/* Why it works */}
            <div className="p-3 bg-blue-50/50 rounded-xl border border-blue-200/60 space-y-1">
              <div className="font-bold text-[#080B4F] uppercase tracking-wider">
                Why It Works
              </div>
              <p className="leading-relaxed">{experiment.whyItWorks}</p>
            </div>

            {/* Scientific Principle */}
            <div className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-200/60 space-y-1">
              <div className="font-bold text-emerald-800 uppercase tracking-wider">
                Scientific Principle
              </div>
              <div className="font-mono-data font-bold text-[#080B4F] mb-1">
                {experiment.formula}
              </div>
              <p className="leading-relaxed">{experiment.scientificPrinciple}</p>
            </div>
          </div>

          {/* Key Learning Points in Guide */}
          {experiment.learningPoints && experiment.learningPoints.length > 0 && (
            <div className="pt-2 border-t border-slate-100">
              <div className="text-[11px] font-bold uppercase tracking-wider text-[#A27F35] mb-2">
                Core Scientific Principles Mastered:
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                {experiment.learningPoints.map((point, i) => (
                  <div key={i} className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-700">
                    <span className="font-bold text-[#080B4F] font-mono-data mr-1">#{i + 1}</span>
                    {point}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TWO-ZONE SANDBOX LAYOUT */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Zone: Interactive Stage (65% on Desktop) */}
        <div className="lg:col-span-8 space-y-4">
          <InteractiveWorkbench
            experiment={experiment}
            inputs={inputs}
            simulation={simulation}
            isRunning={isRunning}
            onRunToggle={handleRunToggle}
            circuitSwitchClosed={circuitSwitchClosed}
            onToggleSwitch={handleToggleSwitch}
          />

          {/* Real-time Dynamic Observation Note Box */}
          <div className="bg-white rounded-2xl p-4 border border-[#080B4F]/15 shadow-sm space-y-1">
            <div className="text-[11px] font-bold uppercase tracking-wider text-[#A27F35] flex items-center gap-1.5">
              <span>👁️</span>
              <span>Live Observation & Calculation Analysis</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed font-mono-data">
              {simulation.observation}
            </p>
          </div>
        </div>

        {/* Right Zone: Control Deck & Equipment Specs (35% on Desktop) */}
        <div className="lg:col-span-4 space-y-6">
          <ControlPanel
            experiment={experiment}
            inputs={inputs}
            onChangeInput={handleInputChange}
            onResetDefaults={handleResetDefaults}
            onExecuteAndFinish={handleExecuteAndFinish}
          />
        </div>
      </div>
    </div>
  );
};
