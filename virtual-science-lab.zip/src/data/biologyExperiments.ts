import { ExperimentDef } from '../types';

export const BIOLOGY_EXPERIMENTS: ExperimentDef[] = [
  {
    id: 'plant-growth',
    title: 'Plant Growth & Environmental Factors',
    category: 'biology',
    subcategory: 'Botany & Plant Physiology',
    topic: 'Vegetative Growth & Limiting Factors',
    keywords: ['plant', 'growth', 'light', 'water', 'nutrients', 'temperature', 'botany'],
    shortDescription: 'Simulate vegetative elongation and biomass accumulation over multiple days by varying water, light, temperature, and nutrients.',
    learningObjective: 'Identify optimum environmental conditions for plant growth and quantify biomass expansion under resource constraints.',
    scientificPrinciple: 'Plant Biomass = f(Light PAR, Water, Temp, N-P-K Nutrients). Liebig\'s Law of the Minimum dictates that growth is dictated by the scarcest resource.',
    whyItWorks: 'Plants convert light, water, and atmospheric carbon into carbohydrates via photosynthesis, while roots absorb dissolved minerals to construct cellular proteins and membranes.',
    observationGuide: 'Optimal light and watering produces steady elongation (+4.5 mm/day). Extreme drought or severe shade stunts growth and triggers chlorosis.',
    conclusionTemplate: 'Liebig\'s Law of the Minimum confirmed: vegetative vigor is determined by the most limiting environmental resource.',
    formula: 'Growth = G_max · min(f_light, f_water, f_nutrients) · f_temp',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Place certified bean seeds in identical planting cells filled with standardized vermiculite-soil mix.",
      "Configure the automated growth chamber with adjustable photoperiod (4–20 hours/day) and full-spectrum LED PAR lighting.",
      "Regulate daily volumetric irrigation (10–100 mL/day) and chamber thermal climate (10–38°C).",
      "Track vegetative shoot elongation daily with digital vernier calipers and record leaf chlorophyll greenness index.",
      "Harvest representative seedlings at Day 14 to measure wet biomass, dry biomass, and root-to-shoot allocation ratios."
],
    learningPoints: [
      "Plant growth is co-limited by sunlight, water, carbon dioxide, temperature, and inorganic soil nutrients.",
      "Liebig's Law of the Minimum dictates that plant biomass accumulation is restricted by whichever resource is scarcest.",
      "Extreme excess water creates root hypoxia, while drought induces stomatal closure, suppressing photosynthetic carbon fixation."
],
    simulationType: 'plant-growth',
    equipment: [
      { name: 'Environmental Growth Chamber', icon: '🌱', spec: 'Climatically controlled incubator' },
      { name: 'Full-Spectrum LED Grow Array', icon: '💡', spec: '0 – 800 μmol/m²/s PAR' },
      { name: 'Soil Moisture Tensiometer', icon: '💧', spec: 'Volumetric water content sensor' },
      { name: 'Digital Height Caliper', icon: '📏', spec: 'Sub-millimeter stem ruler' }
    ],
    controls: [
      { id: 'waterLevel', label: 'Daily Watering', unit: 'mL/day', min: 10, max: 100, step: 10, defaultValue: 50, description: 'Irrigation volume applied per 24 hours' },
      { id: 'lightHours', label: 'Photoperiod (Light)', unit: 'hours', min: 4, max: 20, step: 2, defaultValue: 14, description: 'Daily hours of active illumination' },
      { id: 'tempBio', label: 'Ambient Temperature', unit: '°C', min: 10, max: 38, step: 2, defaultValue: 24, description: 'Chamber thermal temperature' }
    ]
  },
  {
    id: 'photosynthesis',
    title: 'Photosynthesis & Elodea Bubble Count',
    category: 'biology',
    subcategory: 'Cellular Energetics',
    topic: 'Photolysis & Light Intensity',
    keywords: ['photosynthesis', 'elodea', 'oxygen', 'bubbles', 'light intensity', 'carbon dioxide', 'chlorophyll'],
    shortDescription: 'Measure oxygen gas bubble emission from aquatic Elodea sprigs across variable light irradiance and dissolved CO₂ concentrations.',
    learningObjective: 'Measure photosynthetic rate as a function of light intensity and dissolved CO₂ buffer, and observe light saturation plateaus.',
    scientificPrinciple: '6CO₂ + 6H₂O + photons → C₆H₁₂O₆ + 6O₂. Light-dependent reactions split water molecules (photolysis), liberating gaseous O₂ bubbles.',
    whyItWorks: 'Photon absorption by photosystem II chlorophyll reaction centers drives electron transport to produce ATP and NADPH while releasing oxygen.',
    observationGuide: 'Increasing light irradiance from 20 to 120 W/m² multiplies oxygen bubble emission before leveling off as enzyme saturation is reached.',
    conclusionTemplate: 'Photosynthesis rate scales linearly with irradiance at low flux, transitioning to a light-saturated plateau.',
    formula: 'Rate = (R_max · I) / (K_m + I) · [CO₂]/(K_co2 + [CO₂])',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Select a vigorous fresh sprig of aquatic Elodea densa and trim the stem diagonally under water with a razor blade.",
      "Invert the sprig into a glass test tube filled with 0.5% sodium bicarbonate solution (providing dissolved CO₂ buffer).",
      "Position the photobioreactor in front of a variable-lux halogen lamp equipped with a heat-absorbing water filter.",
      "Adjust lamp distance to vary light irradiance from 10 W/m² to 200 W/m², allowing 3 minutes equilibration at each level.",
      "Count the rate of oxygen micro-bubbles evolved from the cut stem per minute using an automated optical counter."
],
    learningPoints: [
      "Photosynthesis converts water, carbon dioxide, and light photons into glucose carbohydrates and oxygen gas: 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂.",
      "The light-dependent reactions split water molecules (photolysis) at photosystem II, releasing molecular oxygen as a byproduct.",
      "Photosynthetic rate increases linearly with light irradiance at low levels before plateauing at a light-saturated maximum (V_max)."
],
    simulationType: 'photosynthesis',
    equipment: [
      { name: 'Aquatic Photobioreactor', icon: '🧪', spec: 'Inverted graduated collection tube' },
      { name: 'Fresh Elodea Densa Shoot', icon: '🌿', spec: 'Healthy aquatic angiosperm' },
      { name: 'Variable Lux Halogen Lamp', icon: '💡', spec: 'Heat-filtered light source' },
      { name: 'Sodium Bicarbonate Buffer', icon: '🫧', spec: 'Dissolved CO₂ donor solution' }
    ],
    controls: [
      { id: 'lightIntensity', label: 'Light Irradiance', unit: 'W/m²', min: 10, max: 200, step: 10, defaultValue: 100, description: 'Luminous photosynthetic flux' },
      { id: 'co2Level', label: 'CO₂ Buffer Conc', unit: 'ppm', min: 200, max: 1200, step: 100, defaultValue: 500, description: 'Dissolved carbon dioxide level' }
    ]
  },
  {
    id: 'osmosis',
    title: 'Osmosis & Cellular Turgor Pressure',
    category: 'biology',
    subcategory: 'Cell Biology',
    topic: 'Water Potential & Osmotic Gradients',
    keywords: ['osmosis', 'turgor', 'water potential', 'plasmolysis', 'hypertonic', 'hypotonic', 'cell wall'],
    shortDescription: 'Immerse plant and animal cells into hypotonic, isotonic, and hypertonic saline media to observe cell volume shifts and plasmolysis.',
    learningObjective: 'Differentiate plant cell turgor pressure from animal cell lysis and crenation along osmotic water potential gradients.',
    scientificPrinciple: 'Water potential Ψ = Ψ_s + Ψ_p. Water diffuses across semi-permeable membranes from regions of higher water potential (low solute) to lower water potential (high solute).',
    whyItWorks: 'Cell membranes contain aquaporin channels permeable to water but impermeable to hydrated ions. Osmotic pressure drives net water fluxes.',
    observationGuide: 'In hypotonic media, plant cell walls prevent bursting and maintain turgor. In 5% saline, onion cytoplasm shrinks away from walls (plasmolysis).',
    conclusionTemplate: 'Osmotic equilibrium verified: plant cell walls withstand hydrostatic turgor pressure without membrane rupture.',
    formula: 'Ψ = Ψ_s + Ψ_p,  ΔV ∝ -ΔC_saline',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Cut uniform cylinders of plant tissue (potato tuber) with a cork borer and trim to exactly 40.0 mm length on a cutting board.",
      "Weigh each potato cylinder on an analytical balance to determine initial fresh mass (m_initial).",
      "Place individual cylinders into beakers containing sodium chloride solutions ranging from 0.0% (hypotonic) to 3.0% (hypertonic).",
      "Allow osmotic water exchange across cellular semipermeable membranes to proceed for 60 minutes.",
      "Blot cylinders dry, re-weigh to compute percentage mass change, and identify the isotonic equilibrium concentration (zero change)."
],
    learningPoints: [
      "Osmosis is the net passive diffusion of water molecules across a semipermeable membrane down its water potential gradient.",
      "In hypotonic solutions (pure water), plant cells absorb water, building internal turgor pressure against the rigid cellulose cell wall.",
      "In hypertonic solutions (saline), water leaves the cytoplasm, causing cell membrane detachment from the wall (plasmolysis)."
],
    simulationType: 'osmosis',
    equipment: [
      { name: 'Compound Microscope', icon: '🔬', spec: '400x phase-contrast optics' },
      { name: 'Allium Cepa (Onion) Slide', icon: '🧫', spec: 'Epidermal monolayer tissue' },
      { name: 'Erythrocyte Blood Smear', icon: '🩸', spec: 'Human red blood cells' },
      { name: 'NaCl Perfusion Pipette', icon: '💧', spec: '0.0% – 5.0% saline solutions' }
    ],
    controls: [
      { id: 'cellModel', label: 'Cell Type', unit: '', min: 0, max: 1, step: 1, defaultValue: 0, description: '0: Plant Cell (Onion Wall), 1: Animal Cell (Red Blood Cell)' },
      { id: 'salineConc', label: 'Extracellular Saline (NaCl)', unit: '%', min: 0.0, max: 5.0, step: 0.3, defaultValue: 0.9, description: '0.0% Hypotonic, 0.9% Isotonic, >1.5% Hypertonic' }
    ]
  },
  {
    id: 'diffusion',
    title: 'Diffusion Rate & Fick\'s First Law',
    category: 'biology',
    subcategory: 'Cell Biology',
    topic: 'Molecular Diffusion & Temperature',
    keywords: ['diffusion', 'fick', 'concentration gradient', 'agar', 'molecular weight', 'temperature'],
    shortDescription: 'Track dye dispersion halos through aqueous agar gels across variable temperatures and molecular weights.',
    learningObjective: 'Measure diffusion rates and verify Fick\'s Law: diffusion velocity is inversely proportional to square root of molecular mass.',
    scientificPrinciple: 'Fick\'s Law: J = -D (dC/dx). Diffusion coefficient D = (k_B T) / (6 π η r). Rate increases with temperature and decreases with molecular size.',
    whyItWorks: 'Random thermal Brownian motion drives passive net dispersion of solute particles from regions of high concentration toward lower concentration.',
    observationGuide: 'Potassium permanganate (light molecule) diffuses noticeably faster than methylene blue (heavy molecule), especially in warm agar.',
    conclusionTemplate: 'Graham\'s and Fick\'s diffusion principles confirmed: smaller molecules at higher temperatures diffuse with maximum radial velocity.',
    formula: 'J = -D · (dC / dx),  D ∝ T / √M_w',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Fill a dialysis tubing bag with a mixture of starch macromolecule solution and glucose monosaccharide solution.",
      "Rinse the exterior thoroughly and suspend the sealed dialysis bag in a beaker of pure water containing iodine indicator (I₂KI).",
      "Observe iodine diffusion into the dialysis bag, turning internal starch dark blue-black due to starch-iodine complexation.",
      "Sample the external beaker water and test for glucose with Benedict's reducing sugar reagent after heating.",
      "Verify that small molecules (glucose, iodine) freely diffuse across pores while large macromolecules (starch) are retained."
],
    learningPoints: [
      "Diffusion is the passive net movement of particles from regions of higher concentration to regions of lower concentration.",
      "Fick's First Law indicates diffusion rate is proportional to concentration gradient, surface area, and membrane permeability.",
      "Semipermeable membranes establish size-selective barriers: micromolecules diffuse freely while polymers are physically excluded."
],
    simulationType: 'diffusion',
    equipment: [
      { name: 'Nutrient Agar Petri Dish', icon: '🧫', spec: '1.5% clear agar gel matrix' },
      { name: 'Core Well Puncher', icon: '⚪', spec: '5 mm central reservoir punch' },
      { name: 'Precision Vernier Caliper', icon: '📏', spec: 'Radial halo diameter measurement' },
      { name: 'Incubation Heating Plate', icon: '♨️', spec: '15°C – 45°C thermal bed' }
    ],
    controls: [
      { id: 'molecularWeight', label: 'Dye Molecular Mass', unit: 'g/mol', min: 100, max: 800, step: 50, defaultValue: 158, description: '158: KMnO₄ (Fast), 320: Methylene Blue, 700: Brilliant Blue' },
      { id: 'gelTemperature', label: 'Medium Temperature', unit: '°C', min: 15, max: 45, step: 5, defaultValue: 25, description: 'Agar gel thermal condition' },
      { id: 'diffusionTime', label: 'Elapsed Diffusion Time', unit: 'min', min: 10, max: 60, step: 10, defaultValue: 30, description: 'Duration of dispersion' }
    ]
  },
  {
    id: 'cell-observation',
    title: 'Cell Observation & Organelle Magnification',
    category: 'biology',
    subcategory: 'Cell Biology',
    topic: 'Microscopy & Cell Structure',
    keywords: ['cell', 'microscope', 'organelle', 'nucleus', 'membrane', 'cytoplasm', 'magnification'],
    shortDescription: 'Observe stained plant, animal, and bacterial specimens under 100x, 400x, and 1000x immersion oil microscope lenses.',
    learningObjective: 'Identify and compare essential cellular organelles: nucleus, cell wall, chloroplasts, and cell membranes.',
    scientificPrinciple: 'Cell Theory: All organisms are composed of cells, the basic unit of life. Plant cells possess rigid cellulose walls and chloroplasts absent in animal cells.',
    whyItWorks: 'Stains such as methylene blue and iodine bind selectively to nucleic acids and starch granules, generating optical contrast under transmission light.',
    observationGuide: 'At 400x magnification, onion cells display clear brick-like rectangular boundaries with distinct circular nuclei. Cheek cells appear rounded and irregular.',
    conclusionTemplate: 'Eukaryotic cellular architecture confirmed. Plant cells demonstrate rigid cell walls, large central vacuoles, and distinct chloroplast structures.',
    formula: 'Total Magnification = Ocular (10x) × Objective (10x/40x/100x)',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Peel a single-cell-thick epidermal layer from the concave surface of an onion bulb scale using fine forceps.",
      "Mount the transparent tissue flat on a glass slide with a drop of water and apply a coverslip without trapping air bubbles.",
      "Add a drop of Lugol's iodine or methylene blue stain at the coverslip edge and draw it under using filter paper.",
      "Examine the specimen under compound optical microscope, starting at 40× scanning power and progressing to 400× high power.",
      "Identify and sketch distinct cell boundaries, rigid cellulose cell walls, large central vacuoles, cytoplasm, and stained nuclei."
],
    learningPoints: [
      "The cell is the fundamental structural, functional, and biological unit of all known living organisms (Cell Theory).",
      "Plant cells are distinguished by rigid cellulose cell walls, large central turgor vacuoles, and plastids/chloroplasts.",
      "Optical staining enhances microscopic contrast by selectively binding to specific cellular macromolecules like nuclear DNA and starch."
],
    simulationType: 'cell-observation',
    equipment: [
      { name: 'Research Binocular Microscope', icon: '🔬', spec: '10x oculars with 10x, 40x, 100x oil lenses' },
      { name: 'Prepared Specimen Slides', icon: '🧫', spec: 'Onion Epidermis, Human Buccal Cheek, Elodea' },
      { name: 'Substage Abbe Condenser', icon: '💡', spec: 'Iris diaphragm with Kohler illumination' },
      { name: 'Staining Reagent Kit', icon: '🧪', spec: 'Methylene blue & Lugol\'s iodine' }
    ],
    controls: [
      { id: 'specimenChoice', label: 'Slide Specimen', unit: '', min: 0, max: 2, step: 1, defaultValue: 0, description: '0: Onion Epidermis (Plant), 1: Human Cheek (Animal), 2: Elodea Leaf (Chloroplasts)' },
      { id: 'magnificationPower', label: 'Objective Lens', unit: 'x', min: 100, max: 1000, step: 300, defaultValue: 400, description: '100x, 400x, or 1000x oil immersion' }
    ]
  },
  {
    id: 'mendelian-genetics',
    title: 'Mendelian Genetics & Punnett Crosses',
    category: 'biology',
    subcategory: 'Genetics & Heredity',
    topic: 'Monohybrid Crosses & Segregation',
    keywords: ['genetics', 'punnett square', 'mendel', 'alleles', 'phenotype', 'genotype', 'dominant', 'recessive'],
    shortDescription: 'Cross heterozygous and homozygous pea plants to calculate expected 3:1 phenotype and 1:2:1 genotype distributions.',
    learningObjective: 'Apply Mendel\'s Law of Segregation and compute theoretical versus simulated offspring distributions using Punnett squares.',
    scientificPrinciple: 'Law of Segregation: diploid parents pass one randomly selected allele to each gamete. Dominant alleles (P) mask recessive alleles (p) in heterozygotes.',
    whyItWorks: 'Meiosis separates homologous chromosomes into haploid gametes. Random union of sperm and egg generates predictable probability distributions.',
    observationGuide: 'Crossing two heterozygous purple parents (Pp × Pp) yields an average 75% purple-flowered and 25% white-flowered phenotype ratio.',
    conclusionTemplate: 'Mendel\'s monohybrid 3:1 ratio confirmed across simulated progeny sample populations.',
    formula: 'P(offspring) = P(gamete 1) × P(gamete 2),  Ratio = 3 Dominant : 1 Recessive',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Establish parental genotypes (P generation) for pea flower color: homozygous dominant PP (Purple) and homozygous recessive pp (White).",
      "Cross the true-breeding parental lines to simulate the F₁ hybrid generation, noting that 100% of progeny exhibit the dominant purple phenotype.",
      "Self-pollinate the heterozygous F₁ individuals (Pp × Pp) to produce the simulated F₂ generation of 200 pea plants.",
      "Construct a 2×2 Punnett square tracking allele segregation during gamete formation and random fertilization.",
      "Count phenotypic progeny (purple vs white) and perform a chi-square test (χ²) to verify adherence to Mendel's 3:1 phenotypic ratio."
],
    learningPoints: [
      "Mendel's Law of Segregation states that diploid individuals possess two alleles for each gene, which segregate during meiosis into haploid gametes.",
      "Dominant alleles mask the expression of recessive alleles in heterozygous individuals (Pp phenotype = Purple).",
      "Monohybrid crosses between heterozygotes yield a characteristic 1:2:1 genotypic ratio and a 3:1 phenotypic ratio."
],
    simulationType: 'mendelian-genetics',
    equipment: [
      { name: 'Monohybrid Punnett Matrix', icon: '🧬', spec: '2x2 genetic probability calculator' },
      { name: 'Pisum Sativum Seed Bank', icon: '🌱', spec: 'Purple (P) vs White (p) flower alleles' },
      { name: 'Automated Offspring Incubator', icon: '🧫', spec: 'Simulated 50–500 seedling growout' },
      { name: 'Statistical Chi-Square Engine', icon: '📊', spec: 'Goodness-of-fit hypothesis tester' }
    ],
    controls: [
      { id: 'parent1Genotype', label: 'Parent 1 Genotype', unit: '', min: 0, max: 2, step: 1, defaultValue: 1, description: '0: PP (Homozygous Dominant), 1: Pp (Heterozygous), 2: pp (Recessive)' },
      { id: 'parent2Genotype', label: 'Parent 2 Genotype', unit: '', min: 0, max: 2, step: 1, defaultValue: 1, description: '0: PP (Homozygous Dominant), 1: Pp (Heterozygous), 2: pp (Recessive)' },
      { id: 'sampleSize', label: 'Offspring Seed Count', unit: 'plants', min: 50, max: 500, step: 50, defaultValue: 200, description: 'Total progeny harvested' }
    ]
  },
  {
    id: 'enzyme-activity',
    title: 'Enzyme Activity: Catalase & Substrate Kinetics',
    category: 'biology',
    subcategory: 'Biochemistry',
    topic: 'Enzyme Kinetics & Denaturation',
    keywords: ['enzyme', 'catalase', 'h2o2', 'kinetics', 'substrate', 'temperature', 'ph', 'denaturation'],
    shortDescription: 'Decompose hydrogen peroxide with catalase enzyme across variable temperatures and pH to observe bell-shaped catalytic curves.',
    learningObjective: 'Measure catalytic reaction velocity, determine optimum temperature and pH, and demonstrate thermal protein denaturation.',
    scientificPrinciple: 'Enzymes lower activation energy. Catalase: 2H₂O₂ → 2H₂O + O₂↑. Activity increases with temperature up to optimum (~37°C), then crashes due to denaturation.',
    whyItWorks: 'Enzymes feature a flexible 3D tertiary active site complementary to the transition state. Excessive heat disrupts hydrogen and ionic bonds, unfolding the protein.',
    observationGuide: 'Oxygen foaming is explosive at 37°C and pH 7.0. Boiling the enzyme above 60°C permanently abolishes foaming due to irreversible denaturation.',
    conclusionTemplate: 'Enzyme specificity and thermal optimum validated: activity peaks at physiological 37°C before thermal denaturation destroys function.',
    formula: '2H₂O₂ —(catalase)→ 2H₂O + O₂,  V = (V_max [S]) / (K_m + [S])',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Extract biological catalase enzyme from bovine liver or potato homogenate into chilled phosphate buffer.",
      "Measure 5.0 mL of 3% hydrogen peroxide (H₂O₂) substrate into calibrated reaction tubes placed in thermal water baths (0°C to 80°C).",
      "Add 1.0 mL of catalase extract and immediately seal with a gas pressure sensor or collect foam column height over 60 seconds.",
      "Repeat the assay across pH buffers ranging from pH 2.0 to 11.0 and substrate concentrations from 0.5% to 6.0%.",
      "Plot enzyme reaction velocity to determine optimum temperature (~37°C), optimum pH (~7.0), and irreversible thermal denaturation (>60°C)."
],
    learningPoints: [
      "Enzymes are biological catalysts that dramatically accelerate biochemical reactions by lowering activation energy barriers.",
      "Catalase catalyzes the rapid decomposition of toxic hydrogen peroxide into water and oxygen: 2H₂O₂ → 2H₂O + O₂.",
      "Extreme temperature or non-optimal pH alters non-covalent tertiary protein folds, denaturing the active site and abolishing activity."
],
    simulationType: 'enzyme-activity',
    equipment: [
      { name: 'Catalase Enzyme Extract', icon: '🧪', spec: 'Bovine liver / potato homogenate' },
      { name: 'Graduated Gas Collection Tube', icon: '🍶', spec: 'Oxygen foam displacement column' },
      { name: 'Thermal Water Bath', icon: '♨️', spec: '0°C to 80°C incubation range' },
      { name: 'Phosphate Buffers', icon: '💧', spec: 'pH 3.0 to pH 11.0 test buffers' }
    ],
    controls: [
      { id: 'tempEnzyme', label: 'Reaction Temperature', unit: '°C', min: 10, max: 70, step: 5, defaultValue: 37, description: 'Incubation thermal condition' },
      { id: 'phEnzyme', label: 'Buffer pH Level', unit: '', min: 3.0, max: 11.0, step: 0.5, defaultValue: 7.0, description: 'Acid-base environment for enzyme' },
      { id: 'substrateConc', label: 'H₂O₂ Substrate Conc', unit: '%', min: 1.0, max: 6.0, step: 0.5, defaultValue: 3.0, description: 'Hydrogen peroxide concentration' }
    ]
  },
  {
    id: 'transpiration',
    title: 'Transpiration & Potometer Water Loss',
    category: 'biology',
    subcategory: 'Botany & Plant Physiology',
    topic: 'Stomatal Conductance & Xylem Pull',
    keywords: ['transpiration', 'potometer', 'xylem', 'stomata', 'humidity', 'wind', 'water loss'],
    shortDescription: 'Connect leafy twigs to a graduated bubble potometer under variable wind, light, and humidity to measure transpiration rate.',
    learningObjective: 'Measure plant water uptake and explain the transpiration pull mechanism driven by stomatal evaporation.',
    scientificPrinciple: 'Cohesion-Tension Theory: Evaporation of water from leaf mesophyll stomata generates negative hydrostatic pressure that pulls water up xylem vessels.',
    whyItWorks: 'Dry air and wind steepen the vapor concentration gradient between the saturated spongy mesophyll and ambient air, accelerating water loss.',
    observationGuide: 'Directing a fan onto the leaves quadruples air bubble transit speed through the potometer capillary.',
    conclusionTemplate: 'Transpiration rate scales directly with wind velocity and temperature, and inversely with atmospheric relative humidity.',
    formula: 'Transpiration Rate = (π · r² · Δx) / Δt',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Cut the leafy shoot of a woody plant underwater at a slant to prevent air embolism from entering vascular xylem vessels.",
      "Insert the cut stem into a water-filled Ganong potometer apparatus, sealing the rubber connection airtight with petroleum jelly.",
      "Introduce a single calibrated air bubble into the horizontal capillary tube by briefly lifting the reservoir tube.",
      "Measure the distance traversed by the air bubble per unit time to calculate volumetric water loss under baseline conditions.",
      "Subject the plant to environmental variations (electric fan wind, bright lamp heat, high humidity enclosure, or dark) and record bubble speed."
],
    learningPoints: [
      "Transpiration is the evaporative loss of water vapor from aerial plant surfaces, predominantly through microscopic leaf stomata.",
      "Water movement through xylem is driven by the Cohesion-Tension theory: evaporation creates negative xylem tension pulling water from roots.",
      "Transpiration rate increases with wind, temperature, and light, but drops precipitously in high relative humidity."
],
    simulationType: 'transpiration',
    equipment: [
      { name: 'Ganong Capillary Potometer', icon: '🌡️', spec: '1.0 mm bore with air bubble index' },
      { name: 'Fresh Woody Twig Specimen', icon: '🌿', spec: 'Coleus / Ligustrum with 20 leaves' },
      { name: 'Variable Electric Fan', icon: '💨', spec: '0 – 5 m/s localized breeze generator' },
      { name: 'Environmental Enclosure', icon: '🏠', spec: 'Humid chamber with hygrometer' }
    ],
    controls: [
      { id: 'windSpeed', label: 'Air Velocity (Wind)', unit: 'm/s', min: 0.0, max: 4.0, step: 0.5, defaultValue: 1.0, description: 'Airflow across leaf surfaces' },
      { id: 'relativeHumidity', label: 'Relative Humidity', unit: '%', min: 20, max: 90, step: 10, defaultValue: 50, description: 'Ambient air moisture saturation' },
      { id: 'leafCount', label: 'Active Leaf Count', unit: 'leaves', min: 5, max: 30, step: 5, defaultValue: 15, description: 'Total evaporating leaf surfaces' }
    ]
  },
  {
    id: 'cellular-respiration',
    title: 'Cellular Respiration in Germinating Seeds',
    category: 'biology',
    subcategory: 'Cellular Energetics',
    topic: 'Aerobic Respiration & CO₂ Production',
    keywords: ['cellular respiration', 'respirometer', 'germination', 'oxygen consumption', 'atp', 'metabolism'],
    shortDescription: 'Measure oxygen consumption rate of germinating versus dormant pea seeds in a respirometer using potassium hydroxide CO₂ traps.',
    learningObjective: 'Quantify aerobic metabolic respiration rates by measuring oxygen volume consumption per gram of tissue.',
    scientificPrinciple: 'C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + 36–38 ATP. KOH pellets absorb evolved CO₂ (2KOH + CO₂ → K₂CO₃ + H₂O), causing water fluid levels to advance.',
    whyItWorks: 'Germinating embryos undergo rapid mitosis, protein synthesis, and carbohydrate catabolism, requiring large quantities of ATP produced via oxidative phosphorylation.',
    observationGuide: 'Germinating seeds steadily draw the colored fluid droplet down the manometer tube, whereas dormant unsoaked seeds exhibit near-zero respiration.',
    conclusionTemplate: 'Aerobic respiration demonstrated: germinating seedlings consume O₂ at rates over 10× higher than dormant seeds.',
    formula: 'Respiration Rate = ΔV_O2 / (m_tissue · Δt)',
    difficulty: 'Advanced',
    duration: '20 min',
    xpReward: 80,
    procedure: [
      "Place 25 germinating pea seeds into an airtight respirometer chamber alongside non-germinating dormant seed controls.",
      "Insert a small absorbent cotton plug soaked in 15% potassium hydroxide (KOH) to absorb all evolved carbon dioxide (CO₂) gas.",
      "Seal the respirometer with a graduated manometer tube containing a tiny drop of colored indicator fluid.",
      "Submerge respirometers in a constant-temperature water bath and monitor indicator movement as oxygen is consumed.",
      "Compute respiration rate (mL O₂ consumed / gram / hour) and compare actively metabolizing germinating seeds to dormant controls."
],
    learningPoints: [
      "Cellular respiration oxidizes glucose fuel into carbon dioxide and water while synthesizing cellular ATP: C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + 32 ATP.",
      "Absorbing evolved CO₂ with KOH causes a net volume reduction equal strictly to the volume of oxygen gas consumed by mitochondrial respiration.",
      "Germinating seeds exhibit vastly higher metabolic respiration rates than dry dormant seeds to fuel cell division and radical emergence."
],
    simulationType: 'cellular-respiration',
    equipment: [
      { name: 'Micro-Respirometer Vials', icon: '🧪', spec: 'Sealed test tube with graduated capillary' },
      { name: 'KOH Pellets (CO₂ Scrubber)', icon: '⚪', spec: '15% Potassium Hydroxide absorbent' },
      { name: 'Germinating Pea Seeds', icon: '🌱', spec: 'Pisum sativum soaked 24 hours' },
      { name: 'Water Bath Temperature Stage', icon: '♨️', spec: 'Isothermal immersion tank' }
    ],
    controls: [
      { id: 'seedState', label: 'Physiological State', unit: '', min: 0, max: 1, step: 1, defaultValue: 1, description: '0: Dry Dormant Seeds, 1: Actively Germinating Seeds' },
      { id: 'respirationTemp', label: 'Incubation Temp', unit: '°C', min: 10, max: 35, step: 5, defaultValue: 25, description: 'Ambient temperature' },
      { id: 'seedMass', label: 'Seed Sample Mass', unit: 'g', min: 10, max: 50, step: 10, defaultValue: 25, description: 'Total mass of seeds in respirometer' }
    ]
  },
  {
    id: 'food-testing',
    title: 'Biochemical Food Nutrient Testing',
    category: 'biology',
    subcategory: 'Biochemistry',
    topic: 'Macromolecule Reagent Assays',
    keywords: ['food testing', 'benedict', 'iodine', 'biuret', 'sudan', 'starch', 'glucose', 'protein', 'lipids'],
    shortDescription: 'Perform qualitative biochemical reagent tests on food samples using Benedict\'s, Iodine, Biuret, and Sudan III solutions.',
    learningObjective: 'Identify reducing sugars, starch, proteins, and lipids in unknown dietary food homogenates.',
    scientificPrinciple: 'Benedict\'s tests reducing sugars (blue → brick red upon heating). Iodine tests starch (amber → blue-black). Biuret tests peptide bonds (blue → violet). Sudan tests lipids (red emulsion).',
    whyItWorks: 'Specific chemical chromophores form complexes with functional groups (e.g. Cu²⁺ reduces to Cu₂O in Benedict\'s; iodine inserts into amylose helical coils).',
    observationGuide: 'Milk tests positive for reducing sugar (Benedict\'s orange) and protein (Biuret violet). Bread tests strongly positive for starch (blue-black).',
    conclusionTemplate: 'Macromolecular composition characterized: dietary food matrices exhibit distinctive biochemical nutrient profiles.',
    formula: 'Qualitative Color Assay Matrix',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Prepare test tubes containing food samples: bread crumb, cooking oil, egg white, fruit juice, and distilled water negative control.",
      "Perform Benedict's Test: add reagent and heat in a 90°C water bath for 5 minutes (green/yellow/red indicates reducing monosaccharides).",
      "Perform Iodine Test: add 2 drops of Lugol's iodine solution (blue-black color change confirms presence of starch polysaccharides).",
      "Perform Biuret Test: add sodium hydroxide and copper sulfate (violet/purple color change indicates peptide bonds in proteins).",
      "Perform Ethanol Emulsion Test: dissolve sample in ethanol and pour into cold water (milky white emulsion indicates lipids)."
],
    learningPoints: [
      "Macromolecules in food encompass carbohydrates (monosaccharides and starches), proteins, and lipids.",
      "Benedict's reagent reduces copper(II) to cuprous oxide precipitate in the presence of free reducing aldehyde/ketone sugars.",
      "Biuret reagent coordinates copper(II) ions with unshared electron pairs on peptide nitrogen atoms, generating a signature purple complex."
],
    simulationType: 'food-testing',
    equipment: [
      { name: 'Test Tube Rack & 4 Tubes', icon: '🧫', spec: 'Borosilicate reaction tubes' },
      { name: 'Benedict\'s, Iodine, Biuret Reagents', icon: '🧪', spec: 'Analytical color reagents' },
      { name: 'Boiling Water Bath', icon: '♨️', spec: '95°C Benedict\'s development bath' },
      { name: 'Homogenized Food Samples', icon: '🍞', spec: 'Bread, Milk, Egg White, Potato, Oil' }
    ],
    controls: [
      { id: 'foodSample', label: 'Food Sample Tested', unit: '', min: 0, max: 4, step: 1, defaultValue: 0, description: '0: White Bread (Starch), 1: Milk (Sugars & Protein), 2: Egg Albumin (Protein), 3: Vegetable Oil (Lipids), 4: Pure Glucose Solution' },
      { id: 'reagentTest', label: 'Reagent Assay', unit: '', min: 0, max: 3, step: 1, defaultValue: 0, description: '0: Iodine (Starch), 1: Benedict\'s (Sugars), 2: Biuret (Protein), 3: Sudan III (Lipids)' }
    ]
  },
  {
    id: 'ecosystem-simulation',
    title: 'Ecosystem Simulation & Trophic Pyramids',
    category: 'biology',
    subcategory: 'Ecology & Population Dynamics',
    topic: 'Trophic Levels & 10% Energy Rule',
    keywords: ['ecosystem', 'trophic levels', 'food chain', 'producers', 'herbivores', 'carnivores', 'energy transfer'],
    shortDescription: 'Simulate ecological trophic cascades and calculate energy transfer efficiency across primary producers, herbivores, and apex carnivores.',
    learningObjective: 'Validate Lindeman\'s 10% Energy Transfer Law and observe how primary producer biomass constrains apex predator populations.',
    scientificPrinciple: 'Trophic Efficiency: Only ~10% of energy at any trophic level is transferred to the next level. ~90% is dissipated as metabolic respiration heat and unconsumed biomass.',
    whyItWorks: 'Thermodynamics limits food chain length: energy dissipates at each metabolic stage, making 4th and 5th trophic levels energetic dead ends.',
    observationGuide: 'A field with 10,000 kJ of grass supports only 1,000 kJ of rabbits, which in turn supports just 100 kJ of foxes.',
    conclusionTemplate: 'Lindeman\'s 10% rule confirmed: apex carnivores are strictly biomass-limited by primary photosynthetic productivity.',
    formula: 'E_(n+1) = E_n · 0.10,  Biomass Pyramid',
    difficulty: 'Advanced',
    duration: '20 min',
    xpReward: 80,
    procedure: [
      "Define initial trophic biomass levels in a closed ecological mesocosm: Producers (grasses), Primary Consumers (herbivores), and Apex Predators.",
      "Set solar insolation input and ecosystem carrying capacity (K) on the simulation parameter controls.",
      "Introduce environmental perturbations such as drought, pesticide influx, or predator removal.",
      "Run the continuous multi-year ecological simulation and track population oscillations across trophic levels.",
      "Construct Lindeman trophic pyramids to verify the 10% ecological energy transfer efficiency between sequential trophic levels."
],
    learningPoints: [
      "Ecosystem food webs are organized into progressive trophic feeding levels: primary producers, herbivores, carnivores, and apex predators.",
      "Due to second law of thermodynamics dissipation, approximately only 10% of energy transfers between successive trophic steps (10% Rule).",
      "Removing keystone predators triggers trophic cascades, leading to herbivore overgrazing and total collapse of vegetative producer biomass."
],
    simulationType: 'ecosystem-simulation',
    equipment: [
      { name: 'Ecological Biomass Simulator', icon: '🌲', spec: 'Trophic level energy engine' },
      { name: 'Solar Insolation Monitor', icon: '☀️', spec: 'Photosynthetic baseline input' },
      { name: 'Population Tally Grid', icon: '📊', spec: 'Species count & energy flow monitor' },
      { name: 'Predator-Prey Ratio Gauges', icon: '🦊', spec: 'Equilibrium balance tracker' }
    ],
    controls: [
      { id: 'producerEnergy', label: 'Primary Producer Base (Plants)', unit: 'kJ', min: 1000, max: 20000, step: 1000, defaultValue: 10000, description: 'Net Primary Productivity energy' },
      { id: 'trophicEfficiency', label: 'Trophic Transfer Rate', unit: '%', min: 5, max: 20, step: 1, defaultValue: 10, description: 'Percentage of energy passed to next tier' }
    ]
  },
  {
    id: 'natural-selection',
    title: 'Natural Selection & Peppered Moth Evolution',
    category: 'biology',
    subcategory: 'Evolutionary Biology',
    topic: 'Differential Survival & Allele Shift',
    keywords: ['natural selection', 'evolution', 'peppered moth', 'camouflage', 'predation', 'allele frequency'],
    shortDescription: 'Model differential bird predation on light vs dark peppered moths on lichen-covered vs soot-darkened tree trunks.',
    learningObjective: 'Demonstrate adaptive evolution by natural selection and track shifting allele frequencies across simulated generations.',
    scientificPrinciple: 'Natural selection operates when hereditary variation confers differential survival and reproductive success in a given environment.',
    whyItWorks: 'Visual predators preferentially consume conspicuous moths that contrast against tree bark, lowering their representation in the next generation\'s gene pool.',
    observationGuide: 'On soot-covered dark trees, melanic dark moths survive at 85% while light moths are heavily predated (25% survival), rapidly shifting the population.',
    conclusionTemplate: 'Industrial melanism demonstrated: natural selection changes population allele frequencies in response to environmental shifts.',
    formula: 'p + q = 1,  p² + 2pq + q² = 1 (Hardy-Weinberg shift)',
    difficulty: 'Advanced',
    duration: '20 min',
    xpReward: 80,
    procedure: [
      "Initialize a simulated population of 200 Peppered Moths (Biston betularia) with 90% light-colored morphs and 10% melanic dark morphs.",
      "Set the environmental background to clean lichen-covered birch forest (pre-industrial condition).",
      "Simulate 10 generations of avian visual predation, recording differential survival rates and resulting allele frequencies.",
      "Introduce industrial soot pollution, darkening tree bark and killing light-colored epiphytic lichens.",
      "Continue the simulation for 10 post-industrial generations to observe directional natural selection favoring the melanic morph."
],
    learningPoints: [
      "Natural selection occurs when heritable phenotypic variation leads to differential reproductive success under environmental selective pressures.",
      "Fitness is relative to ecological context: traits advantageous in one environment may prove deleterious when conditions alter.",
      "Industrial melanism in peppered moths represents a classic empirical demonstration of rapid directional evolutionary adaptation."
],
    simulationType: 'natural-selection',
    equipment: [
      { name: 'Simulated Forest Habitat', icon: '🌳', spec: 'Pristine Lichen vs Soot-Stained Bark' },
      { name: 'Avian Predation Engine', icon: '🦅', spec: 'Visual contrast foraging model' },
      { name: 'Gene Frequency Tracker', icon: '🧬', spec: 'Generational allele monitor' },
      { name: 'Population Morph Census', icon: '🦋', spec: 'Light (typica) vs Dark (carbonaria)' }
    ],
    controls: [
      { id: 'treePollutionLevel', label: 'Tree Bark Soot Level', unit: '%', min: 0, max: 100, step: 10, defaultValue: 70, description: '0%: Clean Lichen (Pale), 100%: Industrial Soot (Black)' },
      { id: 'generations', label: 'Simulated Generations', unit: 'gens', min: 1, max: 10, step: 1, defaultValue: 5, description: 'Breeding generational cycles' }
    ]
  },
  {
    id: 'population-growth',
    title: 'Population Growth & Carrying Capacity (K)',
    category: 'biology',
    subcategory: 'Ecology & Population Dynamics',
    topic: 'Logistic vs Exponential Growth',
    keywords: ['population', 'carrying capacity', 'logistic', 'exponential', 'growth rate', 'r-selected', 'k-selected'],
    shortDescription: 'Simulate logistic population growth (dN/dt = rN(1 - N/K)) and examine exponential booms and carrying capacity limits.',
    learningObjective: 'Differentiate exponential growth from density-dependent logistic growth and compute carrying capacity plateaus.',
    scientificPrinciple: 'dN/dt = r N (1 - N / K). Growth accelerates when N << K, then decelerates as resources become limiting, stabilizing at carrying capacity K.',
    whyItWorks: 'Density-dependent limiting factors (food, nesting space, waste accumulation, disease) reduce birth rates and elevate mortality as density increases.',
    observationGuide: 'The growth curve forms a classic sigmoid S-curve, leveling off smoothly as population approaches carrying capacity K.',
    conclusionTemplate: 'Logistic growth model validated: carrying capacity K establishes an upper ceiling on sustainable population size.',
    formula: 'dN/dt = r·N·(1 - N/K),  N(t) = K / (1 + [(K - N₀)/N₀]·e^(-rt))',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Inoculate a simulated culture flask with a small initial population of Paramecium aurelia (N₀ = 10 cells/mL).",
      "Set the intrinsic per capita growth rate (r = 0.5 day⁻¹) and environmental carrying capacity (K = 500 cells/mL).",
      "Track cell density daily over a 30-day simulation window, logging population size and per-capita growth increments.",
      "Plot population versus time to observe the classic sigmoidal (S-shaped) logistic growth curve.",
      "Introduce interspecific competitor Paramecium caudatum to observe Gause's Principle of Competitive Exclusion."
],
    learningPoints: [
      "Populations grow exponentially (dN/dt = rN) in unconstrained environments with abundant resources and space.",
      "As resource scarcity and waste accumulation manifest, density-dependent resistance slows growth toward carrying capacity K (Logistic Growth).",
      "Competitive Exclusion Principle states that two species competing for the exact same limiting resource cannot coexist indefinitely."
],
    simulationType: 'population-growth',
    equipment: [
      { name: 'Population Dynamics Engine', icon: '📊', spec: 'Continuous differential equation solver' },
      { name: 'Resource Habitat Reservoir', icon: '🌾', spec: 'Carrying capacity regulator' },
      { name: 'Generational Population Graph', icon: '📈', spec: 'Real-time sigmoid curve visualizer' },
      { name: 'Census Biomass Meter', icon: '👥', spec: 'Individual census tracker' }
    ],
    controls: [
      { id: 'growthRate', label: 'Intrinsic Rate of Increase (r)', unit: '1/yr', min: 0.1, max: 1.0, step: 0.05, defaultValue: 0.4, description: 'Per capita reproduction rate' },
      { id: 'carryingCapacity', label: 'Carrying Capacity (K)', unit: 'individuals', min: 200, max: 2000, step: 100, defaultValue: 1000, description: 'Maximum habitat support threshold' },
      { id: 'initialPop', label: 'Initial Population (N₀)', unit: 'individuals', min: 10, max: 200, step: 10, defaultValue: 50, description: 'Founding population size' }
    ]
  },
  {
    id: 'microorganism-growth',
    title: 'Microorganism Growth & Bacterial Growth Curve',
    category: 'biology',
    subcategory: 'Microbiology',
    topic: 'Bacterial Growth Phases & Doubling',
    keywords: ['bacteria', 'microbiology', 'growth curve', 'lag phase', 'log phase', 'stationary', 'death phase'],
    shortDescription: 'Culture Escherichia coli in nutrient broth and track the four classical growth phases: Lag, Exponential (Log), Stationary, and Death.',
    learningObjective: 'Plot bacterial growth curves, calculate doubling times (generation time), and identify nutrient exhaustion thresholds.',
    scientificPrinciple: 'N(t) = N₀ · 2^(t / g). In the exponential log phase, bacterial population doubles at constant generation intervals g until nutrients deplete.',
    whyItWorks: 'Binary fission causes exponential cell doubling. Eventually, toxic metabolic waste accumulation and nutrient depletion balance death and birth rates.',
    observationGuide: 'Following a short lag phase of enzyme adaptation, optical density rises exponentially before plateauing into the stationary phase.',
    conclusionTemplate: 'Microbial population dynamics validated across standard lag, log, stationary, and decline phases.',
    formula: 'N_t = N₀ · 2^(t/g),  Generation Time g = t / log₂(N_t / N₀)',
    difficulty: 'Expert',
    duration: '20 min',
    xpReward: 120,
    procedure: [
      "Inoculate 100 mL of sterile nutrient broth with Escherichia coli to achieve an initial optical density OD₆₀₀ of 0.05.",
      "Place the culture in a shaking incubator held at 37°C and 200 RPM for continuous aeration.",
      "Extract 1.0 mL aliquots every 30 minutes over an 8-hour incubation period.",
      "Measure spectrophotometric absorbance at 600 nm and perform serial dilutions plated on agar to count Colony Forming Units (CFU).",
      "Construct a semi-logarithmic growth curve to identify the four canonical phases: Lag, Log (Exponential), Stationary, and Death."
],
    learningPoints: [
      "Bacterial populations reproduce via binary fission, doubling cell numbers at regular intervals termed generation or doubling time.",
      "During exponential log phase, population size follows N_t = N₀ × 2^(t/g), exhibiting constant maximum specific growth rate μ_max.",
      "Nutrient exhaustion and secondary toxic metabolite buildup halt net cell division, initiating the stationary phase."
],
    simulationType: 'microorganism-growth',
    equipment: [
      { name: 'Shaking Incubator', icon: '🔄', spec: '37°C aerated 200 RPM shaker' },
      { name: 'Spectrophotometer (OD₆₀₀)', icon: '📊', spec: 'Optical density 600 nm turbidimeter' },
      { name: 'Luria-Bertani (LB) Broth', icon: '🧫', spec: 'Standard bacteriological nutrient medium' },
      { name: 'Automated Hemocytometer', icon: '🔬', spec: 'Live/dead fluorescent cell counter' }
    ],
    controls: [
      { id: 'generationTimeMin', label: 'Doubling Time (g)', unit: 'min', min: 15, max: 60, step: 5, defaultValue: 20, description: 'Time required for one complete binary fission' },
      { id: 'cultureTimeHours', label: 'Incubation Duration', unit: 'hours', min: 2, max: 16, step: 1, defaultValue: 8, description: 'Total incubation time elapsed' },
      { id: 'nutrientRichness', label: 'Nutrient Broth Index', unit: '', min: 1, max: 3, step: 1, defaultValue: 2, description: '1: Minimal Medium, 2: Standard LB, 3: Enriched SuperBroth' }
    ]
  },
  {
    id: 'human-body-systems',
    title: 'Human Body Systems & Cardiovascular Response',
    category: 'biology',
    subcategory: 'Human Physiology',
    topic: 'Cardiac Output & Exercise Physiology',
    keywords: ['cardiovascular', 'heart rate', 'cardiac output', 'stroke volume', 'oxygen uptake', 'exercise', 'physiology'],
    shortDescription: 'Simulate human cardiovascular hemodynamics during rest, moderate exercise, and maximum athletic exertion.',
    learningObjective: 'Calculate Cardiac Output (Q = Heart Rate × Stroke Volume) and evaluate how the body satisfies elevated cellular oxygen demand.',
    scientificPrinciple: 'Cardiac Output Q = HR × SV (L/min). During exercise, sympathetic activation increases heart rate and contractility, multiplying blood and oxygen delivery.',
    whyItWorks: 'Exercising skeletal muscles consume ATP and oxygen up to 20× faster than at rest. The autonomic nervous system dilates muscle arterioles and elevates cardiac output.',
    observationGuide: 'Transitioning from rest (60 bpm) to vigorous sprint (160 bpm) boosts cardiac output from 5.0 L/min to over 20.0 L/min.',
    conclusionTemplate: 'Cardiovascular compensatory mechanisms confirmed: cardiac output scales proportionally with metabolic exertion to maintain tissue homeostasis.',
    formula: 'Q = HR · SV,  VO₂ = Q · (C_aO₂ - C_vO₂)',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Equip a virtual subject with wireless 12-lead ECG, pulse oximeter, and metabolic cart breath analyzer.",
      "Record baseline resting cardiovascular telemetry: Heart Rate (HR), Stroke Volume (SV), Blood Pressure, and Cardiac Output (Q = HR × SV).",
      "Initiate a graded exercise test on a cycle ergometer, stepping mechanical resistance from 50 Watts to 250 Watts.",
      "Record dynamic physiological compensation: sympathetic tachycardia, peripheral vasodilation, and elevated pulmonary minute ventilation.",
      "Calculate whole-body oxygen consumption (VO₂ = Q × (C_aO₂ - C_vO₂)) and identify anaerobic lactate inflection thresholds."
],
    learningPoints: [
      "Cardiac Output (Q = Heart Rate × Stroke Volume) represents the volume of blood ejected by the heart per minute (typically 5 L/min at rest).",
      "During heavy muscular exertion, cardiac output can increase more than fourfold to exceed 20 L/min to satisfy cellular ATP oxygen demands.",
      "The autonomic nervous system coordinates sympathetic vasoconstriction to viscera and profound vasodilation to active skeletal muscles."
],
    simulationType: 'human-body-systems',
    equipment: [
      { name: 'Computerized Cycle Ergometer', icon: '🚴', spec: 'Calibrated metabolic exercise bike' },
      { name: '12-Lead ECG & Heart Rate Telemetry', icon: '💓', spec: 'Continuous cardiac rate monitor' },
      { name: 'Metabolic Cart Spirometer', icon: '🫁', spec: 'Breath-by-breath O₂ & CO₂ gas analyzer' },
      { name: 'Arterial Blood Pressure Cuff', icon: '🩺', spec: 'Automated systolic/diastolic monitor' }
    ],
    controls: [
      { id: 'workloadWatts', label: 'Exercise Workload', unit: 'Watts', min: 0, max: 300, step: 25, defaultValue: 100, description: '0W: Resting, 100W: Moderate Jogging, 250W: Sprinting' },
      { id: 'athleteCondition', label: 'Fitness Level', unit: '', min: 0, max: 2, step: 1, defaultValue: 1, description: '0: Sedentary, 1: Recreationally Active, 2: Elite Endurance Athlete' }
    ]
  }
];
