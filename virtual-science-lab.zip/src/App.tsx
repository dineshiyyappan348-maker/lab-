/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  NavigationPage,
  UserProfile,
  ExperimentResult,
  ScienceCategory,
  Achievement
} from './types';
import {
  getStoredUserProfile,
  saveUserProfile,
  getStoredHistory,
  saveHistory,
  getStoredAchievements,
  saveAchievements,
  recordNewExperimentRun,
  resetApplicationData
} from './utils/storage';
import { EXPERIMENTS_DATA } from './data/experiments';
import { soundEngine } from './utils/audio';

// Components & Layout
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';

// Pages
import { Login } from './pages/Login';
import { Dashboard } from './pages/Dashboard';
import { CategoriesPage } from './pages/CategoriesPage';
import { ExperimentDetailsPage } from './pages/ExperimentDetailsPage';
import { VirtualLabPage } from './pages/VirtualLabPage';
import { ExperimentResultPage } from './pages/ExperimentResultPage';
import { HistoryPage } from './pages/HistoryPage';
import { AchievementsPage } from './pages/AchievementsPage';
import { ProfilePage } from './pages/ProfilePage';
import { SettingsPage } from './pages/SettingsPage';

export default function App() {
  const [user, setUser] = useState<UserProfile>(() => getStoredUserProfile());
  const [history, setHistory] = useState<ExperimentResult[]>(() => getStoredHistory());
  const [achievements, setAchievements] = useState<Achievement[]>(() => getStoredAchievements());

  // Session state: allow user to start in dashboard with demo data, or visit login page
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);
  const [currentPage, setCurrentPage] = useState<NavigationPage>('dashboard');

  // Active selections
  const [selectedCategory, setSelectedCategory] = useState<ScienceCategory | 'all'>('all');
  const [selectedExperimentId, setSelectedExperimentId] = useState<string>('ohm-law');
  const [activeResult, setActiveResult] = useState<ExperimentResult | null>(() => {
    const list = getStoredHistory();
    return list.length > 0 ? list[0] : null;
  });

  // Achievement unlock toast banner
  const [unlockToast, setUnlockToast] = useState<Achievement | null>(null);

  // Sync sound setting
  useEffect(() => {
    soundEngine.enabled = user.settings?.soundEnabled ?? true;
  }, [user.settings?.soundEnabled]);

  const handleLoginSuccess = (loginData: Partial<UserProfile>) => {
    const updatedUser = {
      ...user,
      ...loginData
    };
    setUser(updatedUser);
    saveUserProfile(updatedUser);
    setIsLoggedIn(true);
    setCurrentPage('dashboard');
  };

  const handleLogout = () => {
    soundEngine.click();
    setIsLoggedIn(false);
    setCurrentPage('login');
  };

  const handleNavigate = (page: NavigationPage) => {
    soundEngine.click();
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectCategory = (cat: ScienceCategory) => {
    setSelectedCategory(cat);
    setCurrentPage('categories');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectExperiment = (expId: string) => {
    setSelectedExperimentId(expId);
    setCurrentPage('experiment_details');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleStartExperiment = () => {
    setCurrentPage('virtual_lab');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleFinishExperiment = (newResult: ExperimentResult) => {
    const { profile: updatedProfile, newAchievementsUnlocked } = recordNewExperimentRun(newResult);
    setUser(updatedProfile);
    setHistory(getStoredHistory());
    setAchievements(getStoredAchievements());
    setActiveResult(newResult);
    setCurrentPage('experiment_result');
    window.scrollTo({ top: 0, behavior: 'smooth' });

    if (newAchievementsUnlocked.length > 0) {
      setUnlockToast(newAchievementsUnlocked[0]);
      setTimeout(() => setUnlockToast(null), 5000);
    }
  };

  const handleSelectResultFromHistory = (result: ExperimentResult) => {
    setActiveResult(result);
    setCurrentPage('experiment_result');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleResetAllData = () => {
    resetApplicationData();
    const freshUser = getStoredUserProfile();
    const freshHistory = getStoredHistory();
    const freshAchievements = getStoredAchievements();
    setUser(freshUser);
    setHistory(freshHistory);
    setAchievements(freshAchievements);
    setActiveResult(freshHistory[0] || null);
    setCurrentPage('dashboard');
  };

  // Find the selected experiment object
  const currentExperiment =
    EXPERIMENTS_DATA.find((e) => e.id === selectedExperimentId) || EXPERIMENTS_DATA[0];

  // List of completed experiment IDs for badges/catalog
  const completedIds = history.map((h) => h.experimentId);

  // If not logged in, render the Login / Welcome page
  if (!isLoggedIn || currentPage === 'login') {
    return <Login onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-[#F4E5C8] text-[#080B4F] flex flex-col font-sans selection:bg-[#8194C6]/40 selection:text-[#080B4F]">
      {/* Top Navbar */}
      <Navbar
        currentPage={currentPage}
        onNavigate={handleNavigate}
        user={user}
        onLogout={handleLogout}
      />

      {/* Achievement Unlock Toast Notification */}
      {unlockToast && (
        <div className="fixed top-20 right-4 z-50 bg-[#080B4F] text-[#F4E5C8] border-2 border-[#A27F35] rounded-2xl p-4 shadow-2xl flex items-center gap-4 animate-in slide-in-from-top duration-300">
          <div className="text-3xl">{unlockToast.icon}</div>
          <div>
            <div className="text-[10px] font-mono-data uppercase tracking-wider text-[#C9A95C]">
              New Achievement Unlocked!
            </div>
            <div className="font-serif-display font-bold text-sm text-white">
              {unlockToast.title}
            </div>
            <div className="text-xs text-[#D5DEEE]">
              +{unlockToast.xpBonus} Science XP Bonus
            </div>
          </div>
          <button
            onClick={() => setUnlockToast(null)}
            className="text-xs text-slate-400 hover:text-white ml-2"
          >
            ✕
          </button>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        {currentPage === 'dashboard' && (
          <Dashboard
            user={user}
            onSelectCategory={handleSelectCategory}
            onSelectExperiment={handleSelectExperiment}
            onNavigateHistory={() => handleNavigate('history')}
          />
        )}

        {currentPage === 'categories' && (
          <CategoriesPage
            initialCategory={selectedCategory}
            onSelectExperiment={handleSelectExperiment}
            completedExperimentIds={completedIds}
          />
        )}

        {currentPage === 'experiment_details' && (
          <ExperimentDetailsPage
            experiment={currentExperiment}
            onStartExperiment={handleStartExperiment}
            onBackToCatalog={() => handleNavigate('categories')}
          />
        )}

        {currentPage === 'virtual_lab' && (
          <VirtualLabPage
            experiment={currentExperiment}
            onFinishExperiment={handleFinishExperiment}
            onExitLab={() => handleNavigate('experiment_details')}
          />
        )}

        {currentPage === 'experiment_result' && activeResult && (
          <ExperimentResultPage
            result={activeResult}
            user={user}
            onTryAgain={() => {
              setSelectedExperimentId(activeResult.experimentId);
              setCurrentPage('virtual_lab');
            }}
            onBackToDashboard={() => handleNavigate('dashboard')}
            onViewInHistory={() => handleNavigate('history')}
          />
        )}

        {currentPage === 'history' && (
          <HistoryPage
            history={history}
            studentName={user.name}
            onSelectResult={handleSelectResultFromHistory}
          />
        )}

        {currentPage === 'achievements' && (
          <AchievementsPage
            achievements={achievements}
            user={user}
          />
        )}

        {currentPage === 'profile' && (
          <ProfilePage
            user={user}
            achievements={achievements}
          />
        )}

        {currentPage === 'settings' && (
          <SettingsPage
            user={user}
            onUpdateUser={(updated) => {
              const nu = { ...user, ...updated };
              setUser(nu);
              saveUserProfile(nu);
            }}
            onResetAllData={handleResetAllData}
          />
        )}
      </main>

      {/* Academic Footer */}
      <Footer />
    </div>
  );
}
