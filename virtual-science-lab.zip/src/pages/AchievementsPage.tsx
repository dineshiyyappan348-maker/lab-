import React from 'react';
import { Achievement, UserProfile } from '../types';

interface AchievementsPageProps {
  achievements: Achievement[];
  user: UserProfile;
}

export const AchievementsPage: React.FC<AchievementsPageProps> = ({
  achievements,
  user
}) => {
  const unlockedCount = achievements.filter((a) => a.unlockedAt).length;

  return (
    <div className="space-y-8 py-6">
      {/* Header */}
      <div className="border-b border-[#080B4F]/15 pb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-serif-display text-3xl sm:text-4xl font-bold text-[#080B4F]">
            Laboratory Achievements & Badges
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Unlock distinguished scientific honors by completing experiments across all laboratory branches
          </p>
        </div>

        {/* Tally Card */}
        <div className="bg-white rounded-2xl px-5 py-3 border border-[#080B4F]/15 shadow-sm flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-[#A27F35] text-white flex items-center justify-center text-xl">
            🏆
          </div>
          <div>
            <div className="text-xs text-slate-500 font-medium">Badges Unlocked</div>
            <div className="font-mono-data text-xl font-bold text-[#080B4F]">
              {unlockedCount} / {achievements.length}
            </div>
          </div>
        </div>
      </div>

      {/* Achievements Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {achievements.map((ach) => {
          const isUnlocked = Boolean(ach.unlockedAt);

          return (
            <div
              key={ach.id}
              className={`rounded-2xl p-6 border transition-all flex flex-col justify-between ${
                isUnlocked
                  ? 'bg-white border-[#A27F35]/40 shadow-sm'
                  : 'bg-slate-100/70 border-slate-200 opacity-60'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-sm ${
                      isUnlocked
                        ? 'bg-[#080B4F] text-white'
                        : 'bg-slate-200 text-slate-400'
                    }`}
                  >
                    {ach.icon}
                  </div>

                  <span
                    className={`text-xs font-mono-data font-bold px-2.5 py-1 rounded ${
                      isUnlocked
                        ? 'bg-amber-50 text-[#A27F35] border border-amber-200'
                        : 'bg-slate-200 text-slate-500'
                    }`}
                  >
                    +{ach.xpBonus} XP
                  </span>
                </div>

                <div>
                  <h3 className="font-serif-display font-bold text-lg text-[#080B4F]">
                    {ach.title}
                  </h3>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    {ach.description}
                  </p>
                </div>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                {isUnlocked ? (
                  <span className="font-semibold text-emerald-700 flex items-center gap-1.5">
                    <span>✓</span>
                    <span>Unlocked</span>
                  </span>
                ) : (
                  <span className="text-slate-400 font-mono-data">
                    🔒 Locked · Requires {ach.requiredCount} experiments
                  </span>
                )}

                {isUnlocked && (
                  <span className="text-[11px] font-mono-data text-slate-400">
                    Earned
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
