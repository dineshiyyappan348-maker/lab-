import React, { useState } from 'react';
import { UserProfile } from '../types';
import { resetApplicationData } from '../utils/storage';
import { soundEngine } from '../utils/audio';

interface SettingsPageProps {
  user: UserProfile;
  onUpdateUser: (updated: Partial<UserProfile>) => void;
  onResetAllData: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  user,
  onUpdateUser,
  onResetAllData
}) => {
  const [name, setName] = useState(user.name);
  const [grade, setGrade] = useState(user.settings.gradeLevel);
  const [soundEnabled, setSoundEnabled] = useState(user.settings.soundEnabled);
  const [savedMsg, setSavedMsg] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    soundEngine.click();
    soundEngine.enabled = soundEnabled;
    onUpdateUser({
      name,
      settings: {
        ...user.settings,
        gradeLevel: grade,
        soundEnabled
      }
    });
    setSavedMsg(true);
    setTimeout(() => setSavedMsg(false), 2500);
  };

  const handleExportData = () => {
    soundEngine.click();
    const data = {
      profile: user,
      timestamp: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `virtual_science_lab_${user.name.toLowerCase().replace(/\s+/g, '_')}_data.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleResetData = () => {
    if (window.confirm('Reset all laboratory progress, experiment logs, and revert back to demo state?')) {
      resetApplicationData();
      onResetAllData();
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-8 space-y-8">
      {/* Header */}
      <div className="border-b border-[#080B4F]/15 pb-6">
        <h1 className="font-serif-display text-3xl font-bold text-[#080B4F]">
          Laboratory Settings
        </h1>
        <p className="text-sm text-slate-600 mt-1">
          Customize laboratory audio feedback, profile information, and simulation storage preferences
        </p>
      </div>

      {/* Profile Form */}
      <form
        onSubmit={handleSaveProfile}
        className="bg-white rounded-3xl p-6 sm:p-8 border border-[#080B4F]/15 shadow-sm space-y-6"
      >
        <h2 className="font-serif-display text-xl font-bold text-[#080B4F]">
          Student Profile Details
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Student Full Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#080B4F]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Curricular Grade / Level
            </label>
            <input
              type="text"
              value={grade}
              onChange={(e) => setGrade(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#080B4F]"
            />
          </div>
        </div>

        {/* Audio feedback toggle */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
          <div>
            <div className="text-sm font-semibold text-[#080B4F]">
              Synthesizer Laboratory Audio Effects
            </div>
            <p className="text-xs text-slate-500">
              Plays subtle Web Audio clicks, meter beeps, circuit switch toggles, and reaction bubbling
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              const next = !soundEnabled;
              setSoundEnabled(next);
              soundEngine.enabled = next;
              if (next) soundEngine.measurementBeep();
            }}
            className={`w-12 h-6 rounded-full transition-colors relative ${
              soundEnabled ? 'bg-[#080B4F]' : 'bg-slate-300'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                soundEnabled ? 'right-1' : 'left-1'
              }`}
            />
          </button>
        </div>

        {/* Save button */}
        <div className="pt-4 flex items-center justify-between">
          {savedMsg && (
            <span className="text-xs text-emerald-700 font-semibold">
              ✓ Preferences saved successfully!
            </span>
          )}
          <button
            type="submit"
            className="ml-auto px-6 py-2.5 rounded-xl text-xs font-bold bg-[#080B4F] hover:bg-[#0e1363] text-[#F4E5C8] shadow-sm transition-all"
          >
            Save Changes
          </button>
        </div>
      </form>

      {/* Data Management Section */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#080B4F]/15 shadow-sm space-y-6">
        <h2 className="font-serif-display text-xl font-bold text-[#080B4F]">
          Data Management & LocalStorage
        </h2>

        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-200">
            <div>
              <div className="text-xs font-bold text-[#080B4F]">
                Export Laboratory History & Progress
              </div>
              <p className="text-xs text-slate-500">
                Download all saved simulation telemetry, variables, and completed reports as JSON
              </p>
            </div>
            <button
              type="button"
              onClick={handleExportData}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-white hover:bg-slate-100 text-[#080B4F] border border-[#080B4F]/20 whitespace-nowrap"
            >
              Export JSON File
            </button>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-rose-50/60 rounded-2xl border border-rose-200/80">
            <div>
              <div className="text-xs font-bold text-rose-900">
                Reset Demo Laboratory Data
              </div>
              <p className="text-xs text-rose-700/80">
                Clears all stored experiments, re-initializes seed data, and resets student state
              </p>
            </div>
            <button
              type="button"
              onClick={handleResetData}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-700 hover:bg-rose-800 text-white whitespace-nowrap shadow-sm"
            >
              Reset All Data
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
