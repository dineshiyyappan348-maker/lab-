import React, { useState } from 'react';
import { ExperimentResult, UserProfile } from '../types';
import { ReportModal } from '../components/lab/ReportModal';
import { soundEngine } from '../utils/audio';

interface ExperimentResultPageProps {
  result: ExperimentResult;
  user: UserProfile;
  onTryAgain: () => void;
  onBackToDashboard: () => void;
  onViewInHistory: () => void;
}

export const ExperimentResultPage: React.FC<ExperimentResultPageProps> = ({
  result,
  user,
  onTryAgain,
  onBackToDashboard,
  onViewInHistory
}) => {
  const [showReportModal, setShowReportModal] = useState(false);
  const [savedNotification, setSavedNotification] = useState(true);

  // Level progress percentage
  const levelProgress = Math.min(100, Math.round((user.xp / user.xpForNextLevel) * 100));

  return (
    <div className="max-w-3xl mx-auto py-8 space-y-8">
      {/* Celebration Header */}
      <div className="bg-[#080B4F] text-[#F4E5C8] rounded-3xl p-6 sm:p-10 shadow-xl border border-[#8194C6]/30 text-center space-y-3 relative overflow-hidden">
        <div className="w-16 h-16 rounded-full bg-[#A27F35] text-white flex items-center justify-center text-3xl mx-auto shadow-md">
          🎉
        </div>

        <h1 className="font-serif-display text-3xl sm:text-4xl font-bold tracking-tight text-white">
          EXPERIMENT COMPLETED
        </h1>

        <p className="text-sm text-[#D5DEEE] max-w-md mx-auto">
          Your telemetry data has been calculated, validated, and logged to your permanent student record.
        </p>

        {/* XP Award Pill */}
        <div className="pt-2 flex justify-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 border border-[#C9A95C]/40 text-[#C9A95C] font-mono-data font-bold text-sm">
            <span>🏆</span>
            <span>+{result.xpEarned} Science XP Awarded</span>
          </div>
        </div>
      </div>

      {/* Main Results Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#080B4F]/15 shadow-md space-y-6">
        <div>
          <span className="text-xs font-mono-data uppercase tracking-wider text-slate-500">
            {result.category} Laboratory · Verification Report
          </span>
          <h2 className="font-serif-display text-2xl font-bold text-[#080B4F] mt-1">
            {result.experimentTitle}
          </h2>
        </div>

        {/* Dynamic Result Summary Table */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wide text-[#080B4F]">
            Result Summary
          </h3>
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <div className="bg-slate-50 px-4 py-2.5 border-b border-slate-200 text-xs font-semibold text-slate-600 flex justify-between">
              <span>Input Parameters</span>
              <span>Values</span>
            </div>
            <div className="divide-y divide-slate-100 p-2 text-xs">
              {Object.entries(result.inputs).map(([k, v]) => (
                <div key={k} className="flex justify-between py-1.5 px-2">
                  <span className="text-slate-600 capitalize">{k}</span>
                  <span className="font-mono-data font-semibold text-[#080B4F]">{String(v)}</span>
                </div>
              ))}
            </div>

            <div className="bg-slate-50 px-4 py-2.5 border-t border-b border-slate-200 text-xs font-semibold text-slate-600 flex justify-between">
              <span>Calculated Outputs</span>
              <span>Measured Values</span>
            </div>
            <div className="divide-y divide-slate-100 p-2 text-xs">
              {Object.entries(result.calculatedOutputs).map(([k, v]) => (
                <div key={k} className="flex justify-between py-1.5 px-2">
                  <span className="text-slate-600">{k}</span>
                  <span className="font-mono-data font-semibold text-[#A27F35]">
                    {String(v)} {result.outputUnits[k] || ''}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Observation Block */}
        <div className="p-4 bg-amber-50/70 border border-amber-200/80 rounded-2xl space-y-1">
          <div className="text-xs font-bold uppercase tracking-wider text-[#A27F35] flex items-center gap-1.5">
            <span>👁️</span>
            <span>Experimental Observation</span>
          </div>
          <p className="text-xs sm:text-sm text-slate-800 leading-relaxed italic">
            "{result.observation}"
          </p>
        </div>

        {/* Scientific Conclusion Block */}
        {result.conclusion && (
          <div className="p-4 bg-emerald-50/70 border border-emerald-200/80 rounded-2xl space-y-1">
            <div className="text-xs font-bold uppercase tracking-wider text-emerald-800 flex items-center gap-1.5">
              <span>🎯</span>
              <span>Scientific Conclusion</span>
            </div>
            <p className="text-xs sm:text-sm text-emerald-950 font-medium leading-relaxed">
              {result.conclusion}
            </p>
          </div>
        )}

        {/* Learning Result Block */}
        <div className="p-4 bg-blue-50/70 border border-blue-200/80 rounded-2xl space-y-1">
          <div className="text-xs font-bold uppercase tracking-wider text-[#080B4F] flex items-center gap-1.5">
            <span>💡</span>
            <span>Educational Takeaway & Concept Mastery</span>
          </div>
          <p className="text-xs sm:text-sm text-slate-800 leading-relaxed">
            {result.learningResult}
          </p>
        </div>

        {/* Badge & Level Progress Bar */}
        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-[#080B4F]">
              Level {user.level} {user.title} Progress
            </span>
            <span className="font-mono-data font-bold text-[#A27F35]">
              {user.xp} / {user.xpForNextLevel} XP ({levelProgress}%)
            </span>
          </div>

          <div className="w-full h-3 bg-slate-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-[#080B4F] rounded-full transition-all duration-700"
              style={{ width: `${levelProgress}%` }}
            />
          </div>
        </div>

        {/* Action Buttons Row */}
        <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={() => {
              soundEngine.click();
              setShowReportModal(true);
            }}
            className="px-5 py-2.5 rounded-xl text-xs font-bold bg-[#080B4F] hover:bg-[#0e1363] text-[#F4E5C8] shadow-sm transition-all flex items-center gap-2"
          >
            <span>📋</span>
            <span>VIEW REPORT</span>
          </button>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => {
                soundEngine.click();
                onViewInHistory();
              }}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
            >
              VIEW IN HISTORY
            </button>

            <button
              onClick={() => {
                soundEngine.click();
                onTryAgain();
              }}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold bg-white hover:bg-slate-50 text-[#080B4F] border border-[#080B4F]/30 transition-colors"
            >
              TRY AGAIN
            </button>

            <button
              onClick={() => {
                soundEngine.click();
                onBackToDashboard();
              }}
              className="px-5 py-2.5 rounded-xl text-xs font-bold bg-[#A27F35] hover:bg-[#8e6f2c] text-white shadow-sm transition-all"
            >
              BACK TO DASHBOARD
            </button>
          </div>
        </div>
      </div>

      {/* Report Modal */}
      {showReportModal && (
        <ReportModal
          result={result}
          studentName={user.name}
          onClose={() => setShowReportModal(false)}
        />
      )}
    </div>
  );
};
