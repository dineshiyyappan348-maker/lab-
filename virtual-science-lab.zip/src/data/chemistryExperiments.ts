import { ExperimentDef } from '../types';

export const CHEMISTRY_EXPERIMENTS: ExperimentDef[] = [
  {
    id: 'acids-bases',
    title: 'Acids and Bases Classification',
    category: 'chemistry',
    subcategory: 'Acid-Base Chemistry',
    topic: 'Ionization & Arrhenius/Bronsted Models',
    keywords: ['acid', 'base', 'ions', 'h+', 'oh-', 'arrhenius', 'bronsted'],
    shortDescription: 'Classify acids and bases according to proton donation, dissociation constants, and hydroxide/hydronium ion concentrations.',
    learningObjective: 'Differentiate between strong and weak acids/bases by comparing ionization degree and hydronium [H₃O⁺] concentrations.',
    scientificPrinciple: 'Acids donate H⁺ ions (Arrhenius) or protons (Brønsted-Lowry); bases donate OH⁻ or accept protons. Strong electrolytes dissociate ~100%, weak electrolytes establish equilibrium Ka/Kb.',
    whyItWorks: 'Electronegativity differences and bond polarities dictate how readily water dipoles cleave polar covalent bonds to liberate hydrated hydronium or hydroxide ions.',
    observationGuide: 'Strong acid (HCl) exhibits high conductivity and maximum [H⁺], whereas weak acetic acid establishes a modest dissociation equilibrium.',
    conclusionTemplate: 'Electrolyte strength is governed by dissociation equilibrium Ka, confirming proton transfer theory.',
    formula: 'HA + H₂O ⇌ H₃O⁺ + A⁻,  K_a = [H₃O⁺][A⁻]/[HA]',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Calibrate the digital ion-conductivity probe and glass pH electrode using standard buffer solutions (pH 4.0 and 7.0).",
      "Dispense 50 mL of test solution (0.1 M HCl, 0.1 M CH₃COOH, 0.1 M NaOH, or 0.1 M NH₃) into clean reaction beakers.",
      "Lower the conductivity electrodes into each solution to measure ionic current and observe electrolyte conductivity.",
      "Measure the equilibrium hydronium concentration [H₃O⁺] and compute the acid/base dissociation constant (Ka/Kb).",
      "Compare strong electrolytes (100% dissociation) against weak electrolytes to verify partial equilibrium behavior."
],
    learningPoints: [
      "Strong acids (HCl) and strong bases (NaOH) dissociate completely in aqueous solution, yielding high conductivity.",
      "Weak electrolytes (CH₃COOH, NH₃) establish a dynamic equilibrium with only a small fraction dissociated into ions.",
      "Brønsted-Lowry theory defines acids as proton (H⁺) donors and bases as proton acceptors."
],
    simulationType: 'acids-bases',
    equipment: [
      { name: 'Micro-Conductivity Probe', icon: '📊', spec: 'Digital ionic conductivity meter' },
      { name: 'Electrolyte Sample Vials', icon: '🧫', spec: 'HCl, CH₃COOH, NaOH, NH₃ solutions' },
      { name: 'pH Sensor Electrode', icon: '🧪', spec: 'Glass bulb ion-selective electrode' },
      { name: 'Deionized Water Bottle', icon: '🧴', spec: 'Ultra-pure solvent (>18 MΩ·cm)' }
    ],
    controls: [
      { id: 'substanceType', label: 'Chemical Solute', unit: '', min: 0, max: 3, step: 1, defaultValue: 0, description: '0: HCl (Strong Acid), 1: Acetic Acid (Weak Acid), 2: NaOH (Strong Base), 3: Ammonia (Weak Base)' },
      { id: 'solutionMolarity', label: 'Initial Concentration', unit: 'M', min: 0.01, max: 1.0, step: 0.05, defaultValue: 0.1, description: 'Molar analytical concentration of solute' }
    ]
  },
  {
    id: 'ph-measurement',
    title: 'pH Measurement & Everyday Solutions',
    category: 'chemistry',
    subcategory: 'Acid-Base Chemistry',
    topic: 'Logarithmic pH Scale',
    keywords: ['ph', 'acidity', 'basicity', 'logarithmic', 'hydrogen ion', 'household'],
    shortDescription: 'Measure the logarithmic pH of common everyday liquids ranging from gastric juices and lemons to pure water and bleach.',
    learningObjective: 'Master the logarithmic nature of the pH scale and compute precise molar concentrations of H⁺ and OH⁻ ions.',
    scientificPrinciple: 'pH = -log₁₀[H⁺] and [H⁺][OH⁻] = 1.0 × 10⁻¹⁴ M² at 25°C. Each 1.0 unit drop on the pH scale represents a tenfold multiplication of acidity.',
    whyItWorks: 'Auto-ionization of water sets the neutral baseline at pH 7.0. Adding acidic solutes shifts the dynamic equilibrium toward excess hydronium.',
    observationGuide: 'Lemon juice measures ~2.2 (deep red), pure water measures 7.0 (neutral green), and household bleach registers ~12.6 (rich violet).',
    conclusionTemplate: 'The pH scale is confirmed to be logarithmic: lemon juice is 100,000 times more acidic than pure water.',
    formula: 'pH = -log[H⁺],  pOH = 14 - pH',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Clean the micro-pH electrode with deionized water and blot dry with lint-free laboratory wipe.",
      "Prepare spot plates containing samples of everyday liquids (lemon juice, vinegar, coffee, pure water, bleach).",
      "Dip universal pH indicator test strips into each sample well and match the developed color to the colorimetric reference chart.",
      "Immerse the calibrated digital pH glass electrode to obtain high-precision logarithmic pH readings (±0.01 pH).",
      "Perform serial tenfold water dilutions on lemon juice and vinegar to observe how pH increases by exactly 1.0 unit per dilution fold."
],
    learningPoints: [
      "The pH scale is logarithmic: each one-unit decrease represents a tenfold increase in hydronium [H⁺] concentration.",
      "Pure neutral water at 25°C has a pH of 7.00, where [H⁺] = [OH⁻] = 1.0 × 10⁻⁷ M.",
      "Everyday household liquids span the entire spectrum: from citrus acids (pH 2–3) to alkaline cleaning bleaches (pH 12–13)."
],
    simulationType: 'ph-measurement',
    equipment: [
      { name: 'Calibrated pH Meter', icon: '📊', spec: 'Precision digital meter (±0.01 pH)' },
      { name: 'Universal Indicator Chart', icon: '🎨', spec: 'Full range spectrum color wheel' },
      { name: 'Spot Testing Well Plate', icon: '🧫', spec: 'Ceramic 12-well cavity tray' },
      { name: 'Solution Dispenser Droppers', icon: '💧', spec: 'Precision Pasteur pipettes' }
    ],
    controls: [
      { id: 'liquidSelection', label: 'Test Solution', unit: '', min: 0, max: 6, step: 1, defaultValue: 0, description: '0: Lemon Juice, 1: Vinegar, 2: Black Coffee, 3: Pure Water, 4: Baking Soda, 5: Ammonia, 6: Bleach' },
      { id: 'waterDilution', label: 'Water Dilution Fold', unit: 'x', min: 1, max: 10, step: 1, defaultValue: 1, description: 'Fold dilution with neutral water' }
    ]
  },
  {
    id: 'neutralization',
    title: 'Neutralization & Titration Curve',
    category: 'chemistry',
    subcategory: 'Acid-Base Chemistry',
    topic: 'Stoichiometric Neutralization',
    keywords: ['neutralization', 'titration', 'burette', 'phenolphthalein', 'equivalence point', 'salt', 'water'],
    shortDescription: 'Dispense sodium hydroxide from a graduated burette into hydrochloric acid to map the sigmoidal titration curve.',
    learningObjective: 'Determine the stoichiometric equivalence point of strong acid-strong base neutralization and observe phenolphthalein indicator color change.',
    scientificPrinciple: 'H⁺(aq) + OH⁻(aq) → H₂O(l). At the stoichiometric equivalence point, moles of H⁺ equal moles of OH⁻, yielding neutral salt solution pH 7.0 at 25°C.',
    whyItWorks: 'When all excess hydronium ions are consumed by added hydroxide, a single microscopic excess drop swings the pH dramatically from acidic to alkaline.',
    observationGuide: 'The solution remains clear until approaching equivalence, where faint pink flashes appear. At equivalence point, permanent vibrant pink persists.',
    conclusionTemplate: 'Neutralization reaction completed: M₁V₁ = M₂V₂, confirming quantitative equivalence at pH 7.0.',
    formula: 'M₁V₁ = M₂V₂,  H⁺ + OH⁻ → H₂O',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Fill a 50.0 mL precision glass burette with standardized 0.10 M Sodium Hydroxide (NaOH) titrant.",
      "Pipette 25.0 mL of unknown Hydrochloric Acid (HCl) into an Erlenmeyer flask and add 3 drops of phenolphthalein indicator.",
      "Position the flask on a magnetic stirrer underneath the burette tip with continuous moderate swirling.",
      "Titrate dropwise while recording solution pH at 1.0 mL titrant increments to plot the sigmoidal titration curve.",
      "Identify the equivalence point where a single drop creates a persistent faint pink blush lasting >30 seconds (pH 7.0)."
],
    learningPoints: [
      "Acid-base neutralization produces water and an ionic salt: HCl + NaOH → NaCl + H₂O.",
      "At the equivalence point, the stoichiometric moles of H⁺ from the acid equal the moles of OH⁻ added from the titrant.",
      "The pH titration curve exhibits a steep vertical inflection near the equivalence point due to logarithmic concentration scaling."
],
    simulationType: 'neutralization',
    equipment: [
      { name: '50mL Precision Burette', icon: '🧪', spec: 'PTFE stopcock 0.1mL graduations' },
      { name: 'Erlenmeyer Flask', icon: '🍶', spec: '250 mL wide-neck borosilicate flask' },
      { name: 'Digital pH Electrode', icon: '📊', spec: 'Continuous data logger probe' },
      { name: 'Magnetic Stir Plate', icon: '🔄', spec: 'Variable speed spinning magnetic bar' }
    ],
    controls: [
      { id: 'acidVolume', label: 'Analyte Volume (HCl)', unit: 'mL', min: 10, max: 50, step: 5, defaultValue: 25, description: 'Initial acid solution in flask' },
      { id: 'acidMolarity', label: 'Acid Concentration', unit: 'M', min: 0.05, max: 0.5, step: 0.05, defaultValue: 0.1, description: 'Molarity of hydrochloric acid' },
      { id: 'baseAdded', label: '0.1M NaOH Dispensed', unit: 'mL', min: 0, max: 50, step: 1, defaultValue: 25, description: 'Volume of titrant added from burette' }
    ]
  },
  {
    id: 'concentration-dilution',
    title: 'Concentration & Dilution (M₁V₁ = M₂V₂)',
    category: 'chemistry',
    subcategory: 'Solutions & Solubility',
    topic: 'Molarity & Volumetric Dilution',
    keywords: ['concentration', 'dilution', 'molarity', 'solvent', 'solute', 'm1v1=m2v2'],
    shortDescription: 'Dilute concentrated stock solutions with pure water to verify conservation of solute moles across volumetric expansions.',
    learningObjective: 'Calculate final solution molarity following volumetric dilution using the fundamental relationship M₁V₁ = M₂V₂.',
    scientificPrinciple: 'M₁ V₁ = M₂ V₂ = moles of solute (n = constant). Dilution increases solvent volume without altering the absolute number of dissolved solute moles.',
    whyItWorks: 'Adding solvent molecules disperses existing solute particles over a greater spatial volume, proportionally reducing the number of particles per liter.',
    observationGuide: 'As water is added to the deep blue copper sulfate stock, solution absorbance and color intensity decrease in exact linear proportion to dilution factor.',
    conclusionTemplate: 'Conservation of solute mass confirmed: M₁V₁ = M₂V₂ holds across all dilution ratios.',
    formula: 'M₂ = (M₁ · V₁) / V₂,  n = M · V',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Measure 20.0 mL of concentrated stock solution (M₁ = 2.0 M Copper Sulfate) using a calibrated volumetric pipette.",
      "Transfer the aliquot into a 100.0 mL volumetric flask containing ~50 mL of distilled water to prevent exothermic splashing.",
      "Carefully add distilled water until the bottom of the meniscus touches the 100.0 mL calibration ring on the flask neck.",
      "Invert the stoppered flask ten times to ensure complete homogeneous mixing of the diluted solution (M₂).",
      "Calculate theoretical dilution using M₁V₁ = M₂V₂ and measure light absorbance on a spectrophotometer to verify concentration."
],
    learningPoints: [
      "Diluting a solution adds solvent without altering the total moles of dissolved solute: n_solute = M₁V₁ = M₂V₂.",
      "Final solution concentration is inversely proportional to final volume for a constant solute quantity.",
      "Spectrophotometric absorbance follows Beer-Lambert's Law, scaling linearly with molar solution concentration."
],
    simulationType: 'concentration-dilution',
    equipment: [
      { name: 'Volumetric Pipette', icon: '💧', spec: 'Class A 10 mL bulb pipette' },
      { name: 'Volumetric Flask', icon: '🍶', spec: '100 mL calibration mark flask' },
      { name: 'Spectrophotometer Cell', icon: '📊', spec: 'Optical absorbance cuvette' },
      { name: 'Stock Solution Bottle', icon: '🧪', spec: '1.0 M Copper Sulfate stock' }
    ],
    controls: [
      { id: 'initialMolarity', label: 'Stock Concentration (M₁)', unit: 'M', min: 0.5, max: 2.0, step: 0.1, defaultValue: 1.0, description: 'Molar concentration of initial stock' },
      { id: 'initialVolume', label: 'Stock Pipetted (V₁)', unit: 'mL', min: 5, max: 50, step: 5, defaultValue: 20, description: 'Volume of stock solution taken' },
      { id: 'finalVolume', label: 'Total Diluted Volume (V₂)', unit: 'mL', min: 50, max: 250, step: 25, defaultValue: 100, description: 'Total volume after adding deionized water' }
    ]
  },
  {
    id: 'solubility',
    title: 'Solubility & Temperature Curves',
    category: 'chemistry',
    subcategory: 'Solutions & Solubility',
    topic: 'Saturation & Thermal Solubility',
    keywords: ['solubility', 'saturation', 'temperature', 'precipitate', 'crystallization', 'solute'],
    shortDescription: 'Dissolve salt solutes at temperatures from 10°C to 90°C to generate empirical solubility curves and observe crystallization.',
    learningObjective: 'Construct thermal solubility curves and identify unsaturated, saturated, and supersaturated solution states.',
    scientificPrinciple: 'Solubility S = f(T). For most solid solutes, dissolution is endothermic (ΔH_soln > 0), so heating increases equilibrium solubility capacity.',
    whyItWorks: 'Higher thermal kinetic energy disrupts ionic lattice bonds more effectively and increases entropy, allowing solvent cages to hydrate more ions.',
    observationGuide: 'Solute that precipitates at 20°C completely redissolves upon heating the beaker to 70°C, producing a clear saturated solution.',
    conclusionTemplate: 'Le Chatelier\'s principle validated: thermal energy shifts dissolution equilibrium toward dissolved ionic species.',
    formula: 'S_max = f(T),  Precipitate = max(0, m_added - S_max)',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Add 100 g of distilled water into an insulated jacketed beaker equipped with a magnetic stir bar and digital thermometer.",
      "Set the water bath to an initial temperature of 20°C and gradually add measured 5 g increments of potassium nitrate (KNO₃).",
      "Stir continuously until no additional solid dissolves and solid solute crystals remain visible at the bottom (saturation).",
      "Heat the mixture in 10°C increments up to 80°C, recording the additional mass of solute that completely dissolves at each plateau.",
      "Plot solubility (g solute / 100 g H₂O) versus temperature to construct the empirical thermal solubility curve."
],
    learningPoints: [
      "Solubility is the maximum amount of solute that dissolves in a given solvent volume at dynamic thermodynamic equilibrium.",
      "For most solid ionic salts, dissolving is an endothermic process (ΔH_sol > 0), causing solubility to increase markedly with temperature.",
      "Cooling a hot saturated solution below its solubility threshold creates an unstable supersaturated state that precipitates crystals."
],
    simulationType: 'solubility',
    equipment: [
      { name: 'Jacketed Beaker', icon: '🍶', spec: '250 mL thermal borosilicate glass' },
      { name: 'Hot Plate & Thermocouple', icon: '♨️', spec: 'Digitally regulated heating stage' },
      { name: 'Analytical Balance', icon: '⚖️', spec: '0.01 g precision weighing pan' },
      { name: 'Pure Salt Crystals', icon: '💎', spec: 'Potassium Nitrate (KNO₃) reagent' }
    ],
    controls: [
      { id: 'temperature', label: 'Solvent Temperature', unit: '°C', min: 10, max: 90, step: 5, defaultValue: 30, description: 'Water bath temperature' },
      { id: 'soluteAdded', label: 'Solute Mass Added', unit: 'g', min: 10, max: 120, step: 5, defaultValue: 45, description: 'Mass of solid salt introduced into 100g water' }
    ]
  },
  {
    id: 'reaction-rate',
    title: 'Reaction Rate & Surface Area',
    category: 'chemistry',
    subcategory: 'Chemical Kinetics',
    topic: 'Collision Theory & Reaction Rates',
    keywords: ['reaction rate', 'kinetics', 'surface area', 'collision theory', 'gas evolution'],
    shortDescription: 'React calcium carbonate marble chips of varying particle size with acid to demonstrate collision theory and gas production.',
    learningObjective: 'Quantify how particle surface area and solid division state accelerate chemical reaction rate.',
    scientificPrinciple: 'Reaction Rate = Δ[Product] / Δt. In heterogeneous solid-liquid reactions, reaction rate is directly proportional to accessible surface contact area.',
    whyItWorks: 'Subdividing large solid lumps into fine powder exposes exponentially more surface atoms to reactant molecules, multiplying collision frequency per second.',
    observationGuide: 'Fine powder reacts vigorously within 10 seconds, while large lumps effervesce sluggishly over minutes.',
    conclusionTemplate: 'Collision frequency confirmed as fundamental driver of reaction velocity: powder reacts ~4× faster than monolithic chunks.',
    formula: 'Rate ∝ Surface Area × [Reactant],  CaCO₃ + 2HCl → CO₂↑',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Weigh out two identical 5.00 g samples of calcium carbonate (CaCO₃): one as a solid marble chip, the other finely pulverized.",
      "Measure 50 mL of 1.0 M hydrochloric acid into a reaction flask connected via tubing to an inverted gas collection burette.",
      "Add the solid marble chip, seal the stopper instantly, and record the volume of evolved CO₂ gas every 15 seconds.",
      "Clean and dry the apparatus, then repeat the experiment using the identical mass of pulverized calcium carbonate powder.",
      "Compare initial reaction rates (mL CO₂/s) to quantify how microscopic surface area accelerates collision frequency."
],
    learningPoints: [
      "Heterogeneous chemical reactions occur exclusively at the interface between solid reactant surfaces and fluid molecules.",
      "Grinding a solid into fine powder exponentially increases its specific surface area, multiplying effective collision frequency.",
      "Collision Theory dictates that reaction rate is directly proportional to the number of effective collisions per second."
],
    simulationType: 'reaction-rate',
    equipment: [
      { name: 'Side-Arm Reaction Flask', icon: '🍶', spec: '150 mL conical Buchner flask' },
      { name: 'Graduated Gas Syringe', icon: '💉', spec: '100 mL low-friction piston collector' },
      { name: 'Stopwatch Digital Timer', icon: '⏱️', spec: 'Centisecond reaction timer' },
      { name: 'Marble Chips (CaCO₃)', icon: '⚪', spec: 'Classified: Chunk, Granule, Powder' }
    ],
    controls: [
      { id: 'surfaceType', label: 'Solid Particle Size', unit: '', min: 1, max: 3, step: 1, defaultValue: 2, description: '1: Single Large Chunk, 2: Granular Chips, 3: Ultra-Fine Powder' },
      { id: 'acidMolarity', label: 'HCl Acid Concentration', unit: 'M', min: 0.5, max: 3.0, step: 0.5, defaultValue: 1.5, description: 'Molar concentration of acid' }
    ]
  },
  {
    id: 'temp-reaction-rate',
    title: 'Temperature vs Reaction Rate (Arrhenius)',
    category: 'chemistry',
    subcategory: 'Chemical Kinetics',
    topic: 'Activation Energy & Arrhenius Equation',
    keywords: ['temperature', 'arrhenius', 'activation energy', 'kinetics', 'boltzmann', 'rate constant'],
    shortDescription: 'Heat reaction mixtures across 10°C intervals to verify the Arrhenius rate doubling rule and calculate activation energy.',
    learningObjective: 'Demonstrate that chemical reaction rates approximately double for every 10°C temperature elevation.',
    scientificPrinciple: 'k = A e^(-E_a / RT). Raising temperature exponentially increases the fraction of molecular collisions exceeding activation energy E_a.',
    whyItWorks: 'According to the Maxwell-Boltzmann distribution, even modest temperature rises dramatically expand the population of energetic particles in the high-energy kinetic tail.',
    observationGuide: 'A reaction requiring 120 seconds at 20°C concludes in just 15 seconds at 50°C, verifying exponential kinetic acceleration.',
    conclusionTemplate: 'Arrhenius relationship validated: thermal energy multiplies effective collision probability over activation barriers.',
    formula: 'k = A·e^(-E_a / RT),  ln(k₂/k₁) = -(E_a/R)(1/T₂ - 1/T₁)',
    difficulty: 'Advanced',
    duration: '20 min',
    xpReward: 80,
    procedure: [
      "Prepare four identical pairs of reagent tubes containing sodium thiosulfate (Na₂S₂O₃) and hydrochloric acid (HCl).",
      "Place test tubes into temperature-controlled water baths set at 10°C, 25°C, 40°C, and 60°C for 10 minutes to equilibrate.",
      "Place a reaction flask over a printed black cross card and rapidly mix the thiosulfate and acid solutions.",
      "Start the digital stopwatch and record the exact seconds elapsed until colloidal sulfur precipitates and obscures the cross.",
      "Plot 1/time (relative rate) versus temperature to verify the rule of thumb that reaction rates roughly double per 10°C rise."
],
    learningPoints: [
      "Elevating temperature increases the average kinetic energy of reactant particles, shifting the Maxwell-Boltzmann distribution.",
      "The fraction of molecules with kinetic energy exceeding the activation energy (E_a) multiplies exponentially according to Arrhenius' Law.",
      "Higher thermal velocities also marginally increase collision frequency, but the dominant factor is overcome activation energy barrier."
],
    simulationType: 'temp-reaction-rate',
    equipment: [
      { name: 'Constant Temp Water Bath', icon: '♨️', spec: 'PID controlled 10°C – 80°C circulator' },
      { name: 'Thiosulfate Reaction Vessel', icon: '🍶', spec: 'Cross mark disappearance vessel' },
      { name: 'Photometric Turbidity Probe', icon: '📊', spec: 'Optical transmission sensor' },
      { name: 'Digital Reaction Clock', icon: '⏱️', spec: 'Automated endpoint detector' }
    ],
    controls: [
      { id: 'reactionTemp', label: 'Reaction Temperature', unit: '°C', min: 15, max: 65, step: 5, defaultValue: 25, description: 'Bath temperature for reactants' },
      { id: 'activationEnergy', label: 'Activation Energy (E_a)', unit: 'kJ/mol', min: 30, max: 80, step: 10, defaultValue: 50, description: 'Energy barrier of test reaction' }
    ]
  },
  {
    id: 'liquid-density',
    title: 'Density of Liquids & Immiscible Layering',
    category: 'chemistry',
    subcategory: 'Matter & Solutions',
    topic: 'Liquid Densities & Immiscibility',
    keywords: ['density', 'liquids', 'immiscible', 'density column', 'mass', 'volume', 'layering'],
    shortDescription: 'Layer honey, dish soap, water, vegetable oil, and alcohol in a graduated cylinder to build a multi-liquid density tower.',
    learningObjective: 'Calculate liquid densities ρ = m/V and observe spontaneous thermodynamic density stratification of immiscible fluids.',
    scientificPrinciple: 'ρ = m / V. Less dense fluids float on more dense fluids unless miscibility and hydrogen bonding drive spontaneous mixing.',
    whyItWorks: 'Gravitational body force pulls denser fluids with higher mass per unit volume to the base of the cylinder, creating stable hydrostatic equilibrium.',
    observationGuide: 'Dropping a plastic bead settles at the exact boundary where its material density matches surrounding fluid density.',
    conclusionTemplate: 'Hydrostatic density stratification confirmed. Fluid layers arrange in strict descending order of volumetric density.',
    formula: 'ρ = m / V,  P_hydro = Σ ρ_i · g · h_i',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Determine the tare mass of a dry 100 mL graduated cylinder on a high-precision analytical balance.",
      "Pipette exactly 25.0 mL of test liquids (honey, dish soap, water, vegetable oil, rubbing alcohol) and record mass for each.",
      "Compute density for each liquid: ρ = mass / volume (g/mL).",
      "Carefully pour liquids down the inside wall of a tall clear cylinder in order of descending density, adding food coloring to distinguish.",
      "Drop solid objects (copper coin, plastic dice, cork stopper) into the column to observe buoyant equilibrium at density interfaces."
],
    learningPoints: [
      "Immiscible liquids naturally stratify according to density, with the densest fluid settling at the bottom of the vessel.",
      "Intermolecular polarity dictates miscibility: polar liquids (water, alcohol) mix, while non-polar oils form distinct phases.",
      "Solid objects sink through layers less dense than themselves and float stably atop layers denser than their average density."
],
    simulationType: 'liquid-density',
    equipment: [
      { name: '100mL Graduated Cylinder', icon: '📏', spec: 'Tall borosilicate column 1mL divisions' },
      { name: 'Density Liquids Set', icon: '🧪', spec: 'Honey (1.42), Water (1.00), Oil (0.92), Ethanol (0.79)' },
      { name: 'Electronic Balance', icon: '⚖️', spec: 'Tare function 0.01g resolution' },
      { name: 'Indicator Test Beads', icon: '⚪', spec: 'Calibrated density float spheres' }
    ],
    controls: [
      { id: 'liquidLayerCount', label: 'Number of Fluid Layers', unit: 'layers', min: 2, max: 5, step: 1, defaultValue: 4, description: '2 to 5 layered fluids' },
      { id: 'testBeadDensity', label: 'Marker Bead Density', unit: 'g/cm³', min: 0.75, max: 1.45, step: 0.05, defaultValue: 0.95, description: 'Density of suspended indicator bead' }
    ]
  },
  {
    id: 'separation-mixtures',
    title: 'Separation of Mixtures & Paper Chromatography',
    category: 'chemistry',
    subcategory: 'Separation Science',
    topic: 'Chromatography & Rf Factors',
    keywords: ['separation', 'chromatography', 'rf value', 'mixtures', 'solvent', 'filtration', 'pigments'],
    shortDescription: 'Separate ink and plant pigments using paper chromatography and calculate retention factors (Rf) for distinct dye components.',
    learningObjective: 'Separate homogeneous chemical mixtures by exploiting differential partition affinities between stationary and mobile phases.',
    scientificPrinciple: 'R_f = (Distance traveled by compound) / (Distance traveled by solvent front). Components with higher mobile phase affinity migrate farther.',
    whyItWorks: 'Capillary action draws solvent up cellulose fibers. Compounds partition between adsorbing onto cellulose OH-groups versus dissolving in migrating solvent.',
    observationGuide: 'Black ink spot resolves into yellow, cyan, and magenta bands migrating at characteristic constant R_f ratios.',
    conclusionTemplate: 'Mixture components successfully resolved. Individual pigments identified by characteristic R_f values.',
    formula: 'R_f = d_solute / d_solvent',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Cut a strip of Whatman No. 1 chromatography paper (2 cm × 15 cm) and draw a light graphite origin line 1.5 cm from the base.",
      "Spot a concentrated micro-droplet of water-soluble black marker or plant chlorophyll extract onto the origin line.",
      "Allow the spot to dry thoroughly, then suspend the paper vertically in a chromatography chamber containing 1 cm of solvent.",
      "Seal the chamber to saturate vapor space and allow capillary action to advance the solvent front up the paper strip.",
      "Remove paper when solvent reaches 1 cm from the top, mark the solvent front, and calculate Retention Factor Rf for each pigment."
],
    learningPoints: [
      "Chromatography separates mixture components based on differential partitioning between a stationary phase and a mobile solvent phase.",
      "Components with strong affinity for the solvent migrate rapidly, while components adhering strongly to cellulose paper lag behind.",
      "The Retention Factor (Rf = distance traveled by solute / distance traveled by solvent) is a characteristic qualitative constant."
],
    simulationType: 'separation-mixtures',
    equipment: [
      { name: 'Chromatography Chamber', icon: '🍶', spec: 'Sealed glass vapor-saturated vessel' },
      { name: 'Whatman #1 Filter Strip', icon: '📄', spec: 'Pure cellulose chromatography paper' },
      { name: 'Micro-Capillary Spotter', icon: '💧', spec: 'Microliter sample applicator' },
      { name: 'Developing Solvent', icon: '🧪', spec: 'Water-Ethanol eluent mixture' }
    ],
    controls: [
      { id: 'solventFrontDist', label: 'Solvent Migration (d_solv)', unit: 'cm', min: 5, max: 15, step: 1, defaultValue: 10, description: 'Total distance traversed by solvent front' },
      { id: 'solventPolarity', label: 'Solvent Polarity Mix', unit: '', min: 0, max: 2, step: 1, defaultValue: 1, description: '0: Nonpolar, 1: Moderate Polar, 2: Highly Polar' }
    ]
  },
  {
    id: 'chemical-equilibrium',
    title: "Chemical Equilibrium & Le Chatelier's Principle",
    category: 'chemistry',
    subcategory: 'Chemical Thermodynamics',
    topic: 'Dynamic Equilibrium & Stress Response',
    keywords: ['equilibrium', 'le chatelier', 'reversible', 'stress', 'temperature', 'pressure', 'haber'],
    shortDescription: 'Perturb the reversible cobalt complex [Co(H₂O)₆]²⁺ ⇌ [CoCl₄]²⁻ equilibrium with heat and chloride to observe color shifts.',
    learningObjective: 'Predict equilibrium position shifts in response to changes in temperature and concentration using Le Chatelier\'s Principle.',
    scientificPrinciple: 'When a chemical system at equilibrium experiences a disturbance, the system adjusts to counteract that disturbance and re-establish equilibrium.',
    whyItWorks: 'Disturbing concentration or thermal energy changes the reaction quotient Q relative to equilibrium constant K_eq, driving net forward or reverse reaction.',
    observationGuide: 'Heating the pink hydrated cobalt solution shifts equilibrium toward the endothermic blue tetrachloro complex.',
    conclusionTemplate: 'Le Chatelier\'s principle validated: endothermic reactions shift forward upon heating, and adding reactant shifts forward.',
    formula: 'K_eq = [Products]^p / [Reactants]^r,  Q vs K_eq',
    difficulty: 'Expert',
    duration: '20 min',
    xpReward: 120,
    procedure: [
      "Prepare an aqueous equilibrium mixture of iron(III) nitrate and potassium thiocyanate: Fe³⁺ + SCN⁻ ⇌ [Fe(SCN)]²⁺ (blood-red complex).",
      "Distribute equal volumes of the red solution into four matched colorimetric comparison tubes.",
      "Tube 1 serves as control; add excess iron(III) ions to Tube 2 to disturb equilibrium and observe intensified red color.",
      "Add silver nitrate (AgNO₃) to Tube 3 to precipitate thiocyanate as AgSCN and observe rapid color discharge to pale amber.",
      "Place Tube 4 alternately in hot and ice water baths to determine whether the forward complexation is exothermic or endothermic."
],
    learningPoints: [
      "Le Chatelier's Principle states that when a dynamic equilibrium is subjected to stress, the system shifts to relieve that stress.",
      "Adding reactant shifts the equilibrium toward product synthesis; removing reactant shifts the equilibrium backward.",
      "Temperature shifts depend on reaction enthalpy: exothermic reactions shift toward reactants when heated, dissipating thermal load."
],
    simulationType: 'chemical-equilibrium',
    equipment: [
      { name: 'Spectroscopic Colorimeter', icon: '📊', spec: 'Dual wavelength 510nm / 660nm' },
      { name: 'Controlled Water Bath', icon: '♨️', spec: 'Ice bath (0°C) to boiling bath (100°C)' },
      { name: 'Cobalt Solution Cuvette', icon: '🧪', spec: 'Co²⁺ in aqueous acetone matrix' },
      { name: 'Concentrated HCl Dropper', icon: '💧', spec: '12 M chloride stress reagent' }
    ],
    controls: [
      { id: 'temperatureEq', label: 'System Temperature', unit: '°C', min: 0, max: 80, step: 10, defaultValue: 25, description: 'Thermal state of equilibrium flask' },
      { id: 'chlorideConc', label: 'Chloride Ion Stress [Cl⁻]', unit: 'M', min: 0.5, max: 5.0, step: 0.5, defaultValue: 2.0, description: 'Concentration of added stress reactant' }
    ]
  },
  {
    id: 'indicators',
    title: 'Chemical Indicators & Transition Ranges',
    category: 'chemistry',
    subcategory: 'Acid-Base Chemistry',
    topic: 'Halochromic Color Shifts',
    keywords: ['indicators', 'phenolphthalein', 'bromothymol', 'methyl orange', 'ph transition', 'color'],
    shortDescription: 'Examine halochromic color changes of phenolphthalein, bromothymol blue, and methyl orange across the full 1–14 pH spectrum.',
    learningObjective: 'Identify the specific pH transition intervals (pKa ± 1) of synthetic and natural chemical indicators.',
    scientificPrinciple: 'HIn(aq) + H₂O ⇌ H₃O⁺ + In⁻(aq). Weak acid indicator form HIn exhibits a different conjugated absorption spectrum than its deprotonated base form In⁻.',
    whyItWorks: 'Deprotonation alters molecular electronic orbital delocalization, shifting optical light absorption and altering reflected color.',
    observationGuide: 'Bromothymol blue transitions crisply from yellow at pH 6.0 through green at 7.0 to deep blue at pH 7.6.',
    conclusionTemplate: 'Indicator color transitions reflect shifting ratios of protonated and deprotonated dye chromophores.',
    formula: 'pH = pK_a + log([In⁻] / [HIn])',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Arrange a 12-well microplate filled with standardized buffer solutions spanning pH 1.0 through 12.0 in unit steps.",
      "Add two drops of methyl orange indicator to row A, bromothymol blue to row B, and phenolphthalein to row C.",
      "Observe and record the color progression across the pH gradient for each individual chemical dye indicator.",
      "Identify the transition interval (pKa ± 1.0) for each indicator where the conjugate acid and base forms coexist equally.",
      "Formulate a broad-spectrum Universal Indicator mixture by blending indicators to cover the entire pH 1 to 14 range."
],
    learningPoints: [
      "Chemical indicators are weak organic acids (HIn) whose protonated acid form exhibits a distinctly different color than its deprotonated base (In⁻).",
      "The Henderson-Hasselbalch equation indicates the visible color change occurs within approximately 1 pH unit on either side of the indicator's pKa.",
      "Universal indicator combines multiple complementary dyes to provide distinct spectral hues across the entire 0–14 pH scale."
],
    simulationType: 'indicators',
    equipment: [
      { name: 'Multi-Cell Comparison Tray', icon: '🧫', spec: 'Clear optical row wells' },
      { name: 'Standard Buffer Solutions', icon: '🧪', spec: 'Calibrated pH 2, 4, 7, 9, 12 buffers' },
      { name: 'Indicator Dropper Bottles', icon: '💧', spec: 'Phenolphthalein, Bromothymol, Methyl Orange' },
      { name: 'Optical Color Analyzer', icon: '📊', spec: 'CIE color space digitizer' }
    ],
    controls: [
      { id: 'chosenIndicator', label: 'Active Indicator Dye', unit: '', min: 0, max: 2, step: 1, defaultValue: 1, description: '0: Methyl Orange (3.1-4.4), 1: Bromothymol Blue (6.0-7.6), 2: Phenolphthalein (8.2-10.0)' },
      { id: 'targetSolutionPh', label: 'Solution pH Level', unit: '', min: 1.0, max: 14.0, step: 0.5, defaultValue: 7.0, description: 'Regulated solution pH buffer' }
    ]
  },
  {
    id: 'gas-formation',
    title: 'Gas Formation & Stoichiometry (PV = nRT)',
    category: 'chemistry',
    subcategory: 'Chemical Reactions',
    topic: 'Molar Gas Volume & Gas Laws',
    keywords: ['gas formation', 'ideal gas', 'pv=nrt', 'moles', 'stoichiometry', 'co2', 'pressure'],
    shortDescription: 'Evolve carbon dioxide gas from carbonate-acid stoichiometry and compute gas volume using the Ideal Gas Law PV = nRT.',
    learningObjective: 'Calculate theoretical gas yields from chemical stoichiometry and verify that 1 mole of ideal gas occupies 24.5 L at 25°C and 1 atm.',
    scientificPrinciple: 'PV = nRT and n = m / M_w. At Standard Ambient Temperature and Pressure (SATP, 298K, 1 atm), V_molar = 24.47 L/mol.',
    whyItWorks: 'Ideal gas molecules occupy negligible volume compared to their container and exert pressure through elastic kinetic collisions against syringe walls.',
    observationGuide: 'Dissolving 0.20g of sodium bicarbonate produces ~58 mL of CO₂ gas at room temperature, aligning with stoichiometric mole predictions.',
    conclusionTemplate: 'Stoichiometric mole ratios validated: gas volume produced scales directly with limiting reactant moles.',
    formula: 'V = (n·R·T) / P,  n_gas = n_limiting',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Assemble a gas collection apparatus using an airtight reaction flask connected to an inverted water-filled graduated cylinder.",
      "Weigh out a measured mass of magnesium ribbon (Mg) and polish with sandpaper to strip oxide coating.",
      "Measure 20 mL of 2.0 M hydrochloric acid into the flask and lower the magnesium ribbon inside before clamping the stopper.",
      "Collect the evolved hydrogen gas by water displacement and record final gas volume, ambient temperature, and barometric pressure.",
      "Apply the Ideal Gas Law (PV = nRT) with vapor pressure correction for water to calculate experimental molar volume of hydrogen gas."
],
    learningPoints: [
      "Stoichiometric metal-acid reactions produce quantitative molar ratios of gas: Mg(s) + 2HCl(aq) → MgCl₂(aq) + H₂(g).",
      "Gases collected over water contain water vapor, requiring Dalton's Law of Partial Pressures: P_gas = P_total - P_water_vapor.",
      "At standard temperature and pressure (STP: 0°C, 1 atm), one mole of an ideal gas occupies approximately 22.4 liters."
],
    simulationType: 'gas-formation',
    equipment: [
      { name: 'Sealed Reaction Flask', icon: '🍶', spec: 'Gastight septa seal sidearm' },
      { name: 'Teflon Gas Syringe', icon: '💉', spec: 'Precision 100 mL gas displacement' },
      { name: 'Analytical Balance', icon: '⚖️', spec: '0.001 g mass sensitivity' },
      { name: 'Digital Barometer & Temp', icon: '📊', spec: 'Atmospheric pressure & temperature' }
    ],
    controls: [
      { id: 'carbonateMass', label: 'NaHCO₃ Reactant Mass', unit: 'g', min: 0.1, max: 0.5, step: 0.05, defaultValue: 0.25, description: 'Mass of solid baking soda added' },
      { id: 'ambientTemp', label: 'Lab Temperature', unit: '°C', min: 10, max: 40, step: 5, defaultValue: 25, description: 'Room temperature of gas' }
    ]
  },
  {
    id: 'conservation-mass',
    title: 'Conservation of Mass: Closed vs Open Systems',
    category: 'chemistry',
    subcategory: 'Chemical Reactions',
    topic: 'Law of Conservation of Mass',
    keywords: ['conservation of mass', 'lavoisier', 'closed system', 'open system', 'precipitation', 'mass'],
    shortDescription: 'Perform chemical reactions in sealed closed flasks versus open beakers to prove matter is neither created nor destroyed.',
    learningObjective: 'Verify Antoine Lavoisier\'s Law of Conservation of Mass in closed systems and account for apparent mass losses in open gas systems.',
    scientificPrinciple: 'Total Mass of Reactants = Total Mass of Products (Σ m_initial = Σ m_final). Apparent mass loss in open systems is caused by escaping gas.',
    whyItWorks: 'Chemical reactions rearrange chemical bonds between existing atoms; they do not alter atomic nucleus counts or create/destroy elementary nucleons.',
    observationGuide: 'In a sealed flask, vigorous effervescence produces zero change on the balance (0.00g delta). In an open beaker, mass decreases as CO₂ vents into air.',
    conclusionTemplate: 'Conservation of mass demonstrated: total system mass remains exactly invariant in closed reaction vessels.',
    formula: 'Σ m_reactants = Σ m_products',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Place 25 mL of 0.5 M lead(II) nitrate solution into a 100 mL conical flask.",
      "Fill a small test tube with 10 mL of 0.5 M potassium iodide solution and lower it carefully upright inside the flask without tipping.",
      "Seal the flask tightly with a rubber stopper and place the entire assembly on a precision balance to record total initial mass (m₁).",
      "Invert the flask to mix the two clear solutions, observing the immediate formation of a brilliant yellow lead iodide precipitate (PbI₂).",
      "Return the closed flask to the balance to verify that total post-reaction mass (m₂) is identical within balance tolerance (±0.001 g)."
],
    learningPoints: [
      "The Law of Conservation of Mass states that in a closed chemical system, mass is neither created nor destroyed during chemical reaction.",
      "Atoms are rearranged into new chemical bonds and physical precipitate lattices, but the total number and types of atoms remain invariant.",
      "In open systems where gas escapes into the atmosphere, apparent mass loss occurs unless evolved gases are trapped and weighed."
],
    simulationType: 'conservation-mass',
    equipment: [
      { name: 'Digital Top-Loading Balance', icon: '⚖️', spec: '0.001 g dual range balance' },
      { name: 'Hermetically Sealed Vessel', icon: '🧪', spec: 'Threaded O-ring pressure vial' },
      { name: 'Open Reaction Crucible', icon: '🍶', spec: 'Uncovered atmospheric beaker' },
      { name: 'Precipitation Reagents', icon: '💧', spec: 'BaCl₂ and Na₂SO₄ solutions' }
    ],
    controls: [
      { id: 'systemType', label: 'Vessel Containment', unit: '', min: 0, max: 1, step: 1, defaultValue: 0, description: '0: Closed Sealed Flask, 1: Open Vented Beaker' },
      { id: 'reagentMassTotal', label: 'Initial Reagent Mass', unit: 'g', min: 50, max: 200, step: 25, defaultValue: 100, description: 'Initial combined reactant weight' }
    ]
  },
  {
    id: 'crystallization',
    title: 'Crystallization & Crystal Growth Rate',
    category: 'chemistry',
    subcategory: 'Solutions & Solubility',
    topic: 'Nucleation & Crystal Morphology',
    keywords: ['crystallization', 'crystals', 'nucleation', 'growth rate', 'cooling rate', 'solute'],
    shortDescription: 'Cool hot saturated copper sulfate and alum solutions at slow versus rapid rates to control nucleation and crystal geometry.',
    learningObjective: 'Investigate how cooling rate governs crystal nucleation density, individual crystal dimensions, and crystal purity.',
    scientificPrinciple: 'Crystal Growth = f(Supersaturation, Cooling Rate). Slow cooling promotes fewer nucleation sites and large, highly ordered crystalline lattices.',
    whyItWorks: 'Slow cooling gives solute ions sufficient thermodynamic time to diffuse to energetically favorable lattice sites, minimizing structural dislocations.',
    observationGuide: 'Slow benchtop cooling produces large, flawless rhombic crystals. Rapid ice quenching yields a fine, powdery mass of microscopic crystal needles.',
    conclusionTemplate: 'Nucleation kinetics confirmed: slow cooling yields large single crystals, whereas rapid cooling triggers excessive nucleation.',
    formula: 'Nucleation Rate J = A·exp(-ΔG* / kT)',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Dissolve copper(II) sulfate pentahydrate in 100 mL of boiling distilled water until a saturated dark blue solution forms.",
      "Filter the hot solution through fluted filter paper into clean crystallization dishes to remove undissolved dust particles.",
      "Subject Dish 1 to rapid quenching in an ice-water bath while Dish 2 cools slowly at room temperature inside an insulated container.",
      "Suspend a tiny seed crystal on a nylon filament in Dish 2 to direct monocrystalline lattice growth.",
      "Examine crystal morphology under a stereomicroscope after 24 hours, measuring crystal size, geometry, and faceted habit."
],
    learningPoints: [
      "Crystallization is a separation technique that purifies solids as solute molecules pack into highly ordered three-dimensional lattices.",
      "Rapid cooling promotes extensive nucleation resulting in numerous tiny crystals, whereas slow cooling favors large, well-faceted monocrystals.",
      "Impurities do not fit into the repeating crystalline lattice and remain dissolved in the surrounding mother liquor."
],
    simulationType: 'crystallization',
    equipment: [
      { name: 'Insulated Crystallizing Dish', icon: '🧫', spec: 'Flat bottom thermal crystallization dish' },
      { name: 'Thermal Water Jacket', icon: '♨️', spec: 'Controlled cooling rate programmer' },
      { name: 'Optical Stereomicroscope', icon: '🔬', spec: '20x crystal morphology viewer' },
      { name: 'Seed Crystal Suspension', icon: '💎', spec: 'Monocrystalline seed tether' }
    ],
    controls: [
      { id: 'coolingRate', label: 'Cooling Program', unit: '', min: 0, max: 2, step: 1, defaultValue: 0, description: '0: Slow Ambient Cooling (0.5°C/min), 1: Moderate (2°C/min), 2: Rapid Ice Bath Quench (10°C/min)' },
      { id: 'initialSaturationTemp', label: 'Initial Solution Temp', unit: '°C', min: 50, max: 85, step: 5, defaultValue: 70, description: 'Hot saturated solution starting temperature' }
    ]
  },
  {
    id: 'solution-conductivity',
    title: 'Conductivity of Solutions & Ion Dissociation',
    category: 'chemistry',
    subcategory: 'Matter & Solutions',
    topic: 'Electrolytes & Ionic Conduction',
    keywords: ['conductivity', 'electrolytes', 'ions', 'dissociation', 'strong electrolyte', 'bulb', 'conduction'],
    shortDescription: 'Immerse electrode probes into pure water, sugar, vinegar, table salt, and acid to compare electrical conduction.',
    learningObjective: 'Differentiate strong electrolytes, weak electrolytes, and non-electrolytes by measuring electrical conductivity and bulb brightness.',
    scientificPrinciple: 'Conductivity κ = Σ (c_i × z_i × u_i × F). Aqueous conduction requires mobile charged ions to transport electric current between electrodes.',
    whyItWorks: 'Solid ionic lattices dissolve into mobile aqueous cations and anions that migrate toward oppositely charged electrodes under an electric field.',
    observationGuide: 'Distilled water and sucrose show 0.0 μS/cm (bulb unlit). Saline solution lights the bulb brilliantly at >15,000 μS/cm.',
    conclusionTemplate: 'Electrolytic conduction requires free dissociated ions. Neutral covalent molecules (sucrose) cannot carry electric current.',
    formula: 'κ = G · (l / A),  I ∝ [Ions] · Valence',
    difficulty: 'Advanced',
    duration: '20 min',
    xpReward: 80,
    procedure: [
      "Set up a conductivity apparatus with two platinized electrode plates wired in series with a 12 V DC power source and incandescent bulb.",
      "Immerse the clean electrodes into ultra-pure deionized water and record current flow (0.0 μS/cm, bulb dark).",
      "Add solid sucrose (table sugar) and stir until dissolved, observing that the solution remains entirely non-conductive.",
      "Rinse electrodes and immerse in 0.1 M acetic acid (weak electrolyte), observing a faint glow in the filament and moderate current.",
      "Add sodium chloride (NaCl) or hydrochloric acid (strong electrolytes), observing brilliant bulb illumination and high ionic current."
],
    learningPoints: [
      "Electrical conduction in aqueous solutions requires mobile charged ions capable of migrating toward oppositely charged electrodes.",
      "Non-electrolytes (covalent molecules like sucrose) dissolve as neutral uncharged molecules that cannot transport electric current.",
      "Conductivity depends on ion concentration, ionic charge valence, and intrinsic mobility of the species in aqueous solvent."
],
    simulationType: 'solution-conductivity',
    equipment: [
      { name: 'Dual Platinum Electrode Cell', icon: '🔌', spec: 'Platinized 1.0 cm² electrode plates' },
      { name: 'Incandescent Indicator Lamp', icon: '💡', spec: 'Direct current brightness monitor' },
      { name: 'Digital Conductivity Meter', icon: '📊', spec: 'Range: 0.1 μS/cm to 200 mS/cm' },
      { name: 'Regulated DC Power Unit', icon: '🔋', spec: '12 V AC/DC testing voltage' }
    ],
    controls: [
      { id: 'solutionSample', label: 'Tested Substance', unit: '', min: 0, max: 4, step: 1, defaultValue: 2, description: '0: Pure Water, 1: Sucrose (Sugar), 2: Acetic Acid (Vinegar), 3: Table Salt (NaCl), 4: Concentrated HCl' },
      { id: 'saltConcentration', label: 'Solute Concentration', unit: 'g/L', min: 1, max: 50, step: 5, defaultValue: 15, description: 'Solute mass dissolved in test beaker' }
    ]
  }
];
