import React, { useEffect, useState } from 'react';
import { ExperimentDef } from '../../types';
import { SimulationState } from '../../utils/simulationEngine';
import { soundEngine } from '../../utils/audio';
import { LiveChart } from './LiveChart';
import { DynamicApparatusStage } from './DynamicApparatusStage';

interface WorkbenchProps {
  experiment: ExperimentDef;
  inputs: Record<string, number | string | boolean>;
  simulation: SimulationState;
  isRunning: boolean;
  onRunToggle: () => void;
  circuitSwitchClosed?: boolean;
  onToggleSwitch?: () => void;
}

export const InteractiveWorkbench: React.FC<WorkbenchProps> = ({
  experiment,
  inputs,
  simulation,
  isRunning,
  onRunToggle,
  circuitSwitchClosed = true,
  onToggleSwitch
}) => {
  // Motion / timer state for interactive animations
  const [animProgress, setAnimProgress] = useState(0);

  useEffect(() => {
    let frameId: number;
    let startTime: number | null = null;

    if (isRunning) {
      const step = (timestamp: number) => {
        if (!startTime) startTime = timestamp;
        const elapsed = (timestamp - startTime) / 1000;
        setAnimProgress(elapsed);
        frameId = requestAnimationFrame(step);
      };
      frameId = requestAnimationFrame(step);
    } else {
      setAnimProgress(0);
    }

    return () => {
      if (frameId) cancelAnimationFrame(frameId);
    };
  }, [isRunning]);

  // Audio effect triggers when running
  useEffect(() => {
    if (isRunning) {
      if (experiment.category === 'chemistry') {
        soundEngine.bubbleSound();
      } else if (experiment.category === 'physics') {
        soundEngine.measurementBeep();
      }
    }
  }, [isRunning, experiment.category]);

  const v = simulation.dynamicVisuals;

  return (
    <div className="w-full bg-[#080B4F] text-[#F4E5C8] rounded-2xl p-4 sm:p-6 shadow-xl border border-[#8194C6]/30 flex flex-col justify-between relative overflow-hidden min-h-[420px]">
      {/* Laboratory Workbench Background Texture */}
      <div
        className="absolute inset-0 opacity-5 pointer-events-none"
        style={{
          backgroundImage:
            'radial-gradient(#F4E5C8 1px, transparent 1px), radial-gradient(#F4E5C8 1px, #080B4F 1px)',
          backgroundSize: '24px 24px',
          backgroundPosition: '0 0, 12px 12px'
        }}
      />

      {/* Top Banner: Apparatus Name & Active Status Indicator */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 border-b border-[#8194C6]/30 pb-3">
        <div className="flex items-center gap-3">
          <span className="w-3 h-3 rounded-full bg-[#C9A95C] animate-pulse" />
          <h3 className="font-serif-display font-semibold text-lg text-[#F4E5C8] tracking-wide">
            {experiment.title} · Interactive Stage
          </h3>
        </div>

        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#0b1063] border border-[#8194C6]/30 text-[#D5DEEE]">
            <span className="text-[10px] uppercase tracking-wider text-[#C9A95C]">Mode</span>
            <span className="font-semibold">{isRunning ? 'Running Simulation' : 'Ready / Calibrated'}</span>
          </div>
          {onToggleSwitch && (
            <button
              onClick={() => {
                soundEngine.toggleSwitch();
                onToggleSwitch();
              }}
              className={`px-3 py-1 rounded font-medium transition-all ${
                circuitSwitchClosed
                  ? 'bg-emerald-700/80 hover:bg-emerald-600 text-white border border-emerald-500/50'
                  : 'bg-rose-900/80 hover:bg-rose-800 text-rose-200 border border-rose-500/50'
              }`}
            >
              Switch: {circuitSwitchClosed ? 'CLOSED (ON)' : 'OPEN (OFF)'}
            </button>
          )}
        </div>
      </div>

      {/* Core Simulation Canvas / Visual Stage */}
      <div className="relative z-10 my-4 flex-1 flex items-center justify-center min-h-[300px]">
        {/* Render domain-specific interactive visualizers */}
        {experiment.id === 'ohm-law' && (
          <OhmLawVisualizer
            voltage={Number(inputs.voltage || 10)}
            resistance={Number(inputs.resistance || 5)}
            current={Number(v.current || 2)}
            brightness={circuitSwitchClosed ? Number(v.bulbBrightness || 50) : 0}
            power={Number(v.power || 20)}
            isRunning={isRunning && circuitSwitchClosed}
            electronSpeed={Number(v.electronSpeed || 1)}
            switchClosed={circuitSwitchClosed}
          />
        )}

        {experiment.id === 'series-circuit' && (
          <SeriesCircuitVisualizer
            voltage={Number(inputs.sourceVoltage || 12)}
            r1={Number(inputs.resistor1 || 4)}
            r2={Number(inputs.resistor2 || 6)}
            current={Number(simulation.outputs['Loop Current'] || 1.2)}
            b1Brightness={Number(v.bulb1Brightness || 40)}
            b2Brightness={Number(v.bulb2Brightness || 60)}
            switchClosed={circuitSwitchClosed}
          />
        )}

        {experiment.id === 'parallel-circuit' && (
          <ParallelCircuitVisualizer
            voltage={Number(inputs.sourceVoltage || 12)}
            r1={Number(inputs.resistor1 || 4)}
            r2={Number(inputs.resistor2 || 6)}
            i1={Number(simulation.outputs['Branch 1 Current (I₁)'] || 3)}
            i2={Number(simulation.outputs['Branch 2 Current (I₂)'] || 2)}
            iTotal={Number(simulation.outputs['Total Supply Current'] || 5)}
            b1Brightness={Number(v.bulb1Brightness || 80)}
            b2Brightness={Number(v.bulb2Brightness || 60)}
          />
        )}

        {experiment.id === 'projectile-motion' && (
          <ProjectileVisualizer
            v0={Number(inputs.initialVelocity || 20)}
            angle={Number(inputs.launchAngle || 45)}
            g={Number(inputs.gravity || 9.8)}
            range={Number(simulation.outputs['Horizontal Range'] || 40)}
            maxHeight={Number(simulation.outputs['Maximum Altitude'] || 10)}
            time={Number(simulation.outputs['Flight Duration'] || 2.8)}
            isRunning={isRunning}
            chartData={simulation.chartData}
          />
        )}

        {experiment.id === 'simple-pendulum' && (
          <PendulumVisualizer
            length={Number(inputs.pendulumLength || 1.0)}
            period={Number(simulation.outputs['Period'] || 2.0)}
            frequency={Number(simulation.outputs['Frequency'] || 0.5)}
            isRunning={isRunning}
            animProgress={animProgress}
          />
        )}

        {experiment.id === 'hookes-law' && (
          <HookesLawVisualizer
            k={Number(inputs.springConstant || 50)}
            force={Number(inputs.appliedForce || 5)}
            extensionCm={Number(simulation.outputs['Extension (Δx)'] || 10)}
            pe={Number(simulation.outputs['Stored Elastic Energy'] || 0.25)}
            chartData={simulation.chartData}
          />
        )}

        {experiment.id === 'refraction-light' && (
          <RefractionVisualizer
            theta1={Number(inputs.incidentAngle || 40)}
            theta2={Number(simulation.outputs['Refraction Angle (θ₂)'] || 25.4)}
            n2={Number(simulation.outputs['Index of Medium (n₂)'] || 1.5)}
            crit={Number(simulation.outputs['Critical Angle (θ_c)'] || 41.8)}
          />
        )}

        {experiment.id === 'simple-motion' && (
          <SimpleMotionVisualizer
            rampAngle={Number(inputs.rampAngle || 20)}
            trackLength={Number(inputs.trackLength || 2.0)}
            friction={Number(inputs.frictionCoeff || 0.04)}
            acceleration={Number(simulation.outputs['Acceleration'] || 2.5)}
            finalVelocity={Number(simulation.outputs['Final Velocity'] || 3.1)}
            transitTime={Number(simulation.outputs['Transit Time'] || 1.2)}
            isRunning={isRunning}
            animProgress={animProgress}
          />
        )}

        {(experiment.id === 'acid-base' || experiment.id === 'neutralization') && (
          <AcidBaseVisualizer
            acidVol={Number(inputs.acidVol || inputs.acidVolume || 25)}
            baseAdded={Number(inputs.baseAdded || 25)}
            ph={Number(simulation.outputs['Current pH'] || simulation.outputs['Solution pH'] || 7.0)}
            indicatorColor={String(v.indicatorColor || (Number(simulation.outputs['Current pH'] || simulation.outputs['Solution pH'] || 7.0) >= 8.2 ? '#EC4899' : '#FDFBF7'))}
            isRunning={isRunning}
            eqVolume={Number(simulation.outputs['Equivalence Volume'] || 25)}
          />
        )}

        {(experiment.id === 'ph-scale' || experiment.id === 'ph-measurement') && (
          <PhScaleVisualizer
            solutionIndex={Number(inputs.solutionIndex ?? inputs.liquidSelection ?? 0)}
            measuredPh={Number(simulation.outputs['Measured pH'] || simulation.outputs['Calibrated pH'] || 7.0)}
            hConc={String(simulation.outputs['[H⁺] Concentration'] || simulation.outputs['[H⁺] Hydronium'] || '1e-7')}
            liquidName={String(simulation.outputs['Analyte Tested'] || 'Pure Water')}
            color={String(v.stripColor || v.color || '#10B981')}
          />
        )}

        {experiment.id === 'solution-concentration' && (
          <SolutionConcentrationVisualizer
            mass={Number(inputs.soluteMass || 40)}
            volume={Number(inputs.solventVolume || 250)}
            temp={Number(inputs.temperature || 25)}
            molarity={Number(simulation.outputs['Molar Concentration'] || 0.64)}
            precipitate={Number(simulation.outputs['Precipitate Crystals'] || 0)}
            isSaturated={Boolean(v.isSaturated)}
          />
        )}

        {experiment.id === 'chemical-reaction' && (
          <ChemicalReactionVisualizer
            molarity={Number(inputs.acidMolarity || 1.5)}
            temp={Number(inputs.tempReaction || 25)}
            gasVolume={Number(simulation.outputs['CO₂ Gas Volume'] || 45)}
            rateIndex={Number(simulation.outputs['Reaction Rate Index'] || 2.5)}
            isRunning={isRunning}
          />
        )}

        {experiment.id === 'plant-growth' && (
          <PlantGrowthVisualizer
            light={Number(inputs.lightIntensity || inputs.lightHours || 100)}
            co2={Number(inputs.co2Level || 450)}
            bubbleRate={Number(simulation.outputs['O₂ Bubble Rate'] || 45)}
            growthMm={Number(simulation.outputs['Vegetative Growth'] || simulation.outputs['Daily Elongation'] || 2.8)}
            isRunning={isRunning}
          />
        )}

        {(experiment.id === 'cell-osmosis' || experiment.id === 'osmosis') && (
          <CellOsmosisVisualizer
            isAnimal={Number(inputs.cellType ?? inputs.cellModel ?? 0) === 1}
            saline={Number(inputs.salineConcentration ?? inputs.salineConc ?? 0.9)}
            magnification={Number(inputs.magnification || 400)}
            volumePct={Number(simulation.outputs['Cytoplasm Volume'] || 100)}
            tonicity={String(simulation.outputs['Osmotic Tonicity'] || simulation.outputs['Tonicity State'] || 'Isotonic')}
          />
        )}

        {(experiment.id === 'basic-genetics' || experiment.id === 'mendelian-genetics') && (
          <GeneticsVisualizer
            p1={Number(inputs.parent1Genotype || 1)}
            p2={Number(inputs.parent2Genotype || 1)}
            purpleCount={Number(simulation.outputs['Purple Progeny (Dominant)'] || simulation.outputs['Purple Offspring (Dominant)'] || 150)}
            whiteCount={Number(simulation.outputs['White Progeny (Recessive)'] || simulation.outputs['White Offspring (Recessive)'] || 50)}
            ratio={String(simulation.outputs['Phenotype Ratio'] || '3 Purple : 1 White')}
          />
        )}

        {experiment.id === 'water-quality' && (
          <WaterQualityVisualizer
            doVal={Number(inputs.dissolvedOxygen || 8.5)}
            turbidity={Number(inputs.turbidity || 12)}
            nitrates={Number(inputs.nitrates || 2.0)}
            wqi={Number(simulation.outputs['Water Quality Index (WQI)'] || simulation.outputs['Water Quality Index'] || 84)}
            status={String(simulation.outputs['Ecological Status'] || simulation.outputs['Ecological Health'] || 'Good')}
          />
        )}

        {(experiment.id === 'renewable-energy' || experiment.id === 'solar-energy' || experiment.id === 'wind-energy') && (
          <RenewableEnergyVisualizer
            irradiance={Number(inputs.solarIrradiance || 750)}
            panelAngle={Number(inputs.panelAngle || inputs.panelTiltAngle || 30)}
            windSpeed={Number(inputs.windSpeed || inputs.windVelocity || 7.5)}
            solarPower={Number(simulation.outputs['Solar PV Power'] || simulation.outputs['Photovoltaic Output'] || 180)}
            windPower={Number(simulation.outputs['Wind Turbine Power'] || simulation.outputs['Turbine Electric Power'] || 120)}
            totalPower={Number(simulation.outputs['Combined Generation'] || simulation.outputs['Daily Clean Generation'] || 300)}
            isRunning={isRunning}
          />
        )}

        {experiment.id === 'forest-carbon' && (
          <ForestCarbonVisualizer
            hectares={Number(inputs.forestHectares || 100)}
            age={Number(inputs.standAge || 45)}
            density={Number(inputs.treeDensity || 450)}
            tonsCO2={Number(simulation.outputs['Annual CO₂ Sequestration'] || 990)}
          />
        )}

        {(experiment.id === 'recycling-impact' || experiment.id === 'recycling') && (
          <RecyclingVisualizer
            alKg={Number(inputs.aluminumKg || inputs.aluminumRecovered || 80)}
            plasticKg={Number(inputs.plasticKg || inputs.plasticRecovered || 150)}
            paperKg={Number(inputs.paperKg || inputs.paperRecovered || 400)}
            energyKwh={Number(simulation.outputs['Total Energy Conserved'] || simulation.outputs['Energy Conserved'] || 3590)}
            co2Kg={Number(simulation.outputs['Embodied GHG Avoided'] || simulation.outputs['GHG Emissions Avoided'] || 2944)}
          />
        )}

        {/* Scalable Universal Apparatus Visualizer for all remaining experiments */}
        {![
          'ohm-law',
          'series-circuit',
          'parallel-circuit',
          'projectile-motion',
          'simple-pendulum',
          'hookes-law',
          'refraction-light',
          'simple-motion',
          'acid-base',
          'neutralization',
          'ph-scale',
          'ph-measurement',
          'solution-concentration',
          'chemical-reaction',
          'plant-growth',
          'cell-osmosis',
          'osmosis',
          'basic-genetics',
          'mendelian-genetics',
          'water-quality',
          'renewable-energy',
          'solar-energy',
          'wind-energy',
          'forest-carbon',
          'recycling-impact',
          'recycling'
        ].includes(experiment.id) && (
          <UniversalApparatusVisualizer
            experiment={experiment}
            inputs={inputs}
            simulation={simulation}
            isRunning={isRunning}
          />
        )}
      </div>

      {/* Bottom Workbench Telemetry / Live Readout strip */}
      <div className="relative z-10 pt-3 border-t border-[#8194C6]/30 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-4">
          {Object.entries(simulation.outputs).slice(0, 3).map(([key, val]) => (
            <div key={key} className="flex items-center gap-1.5 font-mono-data">
              <span className="text-[#8194C6]">{key}:</span>
              <span className="font-semibold text-[#F4E5C8]">
                {val} {simulation.units[key] || ''}
              </span>
            </div>
          ))}
        </div>

        <button
          onClick={() => {
            soundEngine.click();
            onRunToggle();
          }}
          className={`px-4 py-2 rounded-lg font-semibold text-xs tracking-wider uppercase transition-all shadow-md ${
            isRunning
              ? 'bg-[#A27F35] text-white hover:bg-[#8e6f2c]'
              : 'bg-[#8194C6] hover:bg-[#6e82b5] text-[#080B4F]'
          }`}
        >
          {isRunning ? '⏹ Pause Simulation' : '▶ Run Live Experiment'}
        </button>
      </div>
    </div>
  );
};

// =========================================================================
// SPECIALIZED INDIVIDUAL STAGE VISUALIZERS
// =========================================================================

interface OhmLawProps {
  voltage: number;
  resistance: number;
  current: number;
  brightness: number;
  power: number;
  isRunning: boolean;
  electronSpeed: number;
  switchClosed: boolean;
}

const OhmLawVisualizer: React.FC<OhmLawProps> = ({
  voltage,
  resistance,
  current,
  brightness,
  power,
  isRunning,
  switchClosed
}) => {
  // Meter needle rotations (-45 deg to +45 deg)
  const vAngle = -45 + (voltage / 24) * 90;
  const aAngle = switchClosed ? -45 + Math.min(1, current / 10) * 90 : -45;

  return (
    <div className="w-full max-w-2xl flex flex-col items-center justify-center p-4">
      {/* Schematic SVG with live glowing bulb and animated electron flow */}
      <div className="w-full relative bg-[#050736] rounded-xl p-4 border border-[#8194C6]/40 shadow-inner">
        <svg viewBox="0 0 500 240" className="w-full h-auto">
          {/* Circuit Wire Loop */}
          <rect
            x="50"
            y="40"
            width="400"
            height="160"
            rx="12"
            fill="none"
            stroke="#8194C6"
            strokeWidth="4"
          />

          {/* Animated electron dashes along the wire */}
          {isRunning && switchClosed && (
            <rect
              x="50"
              y="40"
              width="400"
              height="160"
              rx="12"
              fill="none"
              stroke="#F4E5C8"
              strokeWidth="4"
              strokeDasharray="8 16"
              className="animate-pulse"
              style={{
                animation: 'dashMove 1s linear infinite'
              }}
            />
          )}

          {/* Left: DC Power Supply */}
          <g transform="translate(40, 95)">
            <rect x="0" y="0" width="20" height="50" fill="#080B4F" stroke="#C9A95C" strokeWidth="2" rx="4" />
            <text x="10" y="28" fill="#F4E5C8" fontSize="11" fontWeight="bold" textAnchor="middle">
              {voltage}V
            </text>
            <text x="10" y="-8" fill="#C9A95C" fontSize="12" fontWeight="bold" textAnchor="middle">
              +
            </text>
            <text x="10" y="65" fill="#8194C6" fontSize="12" fontWeight="bold" textAnchor="middle">
              -
            </text>
          </g>

          {/* Top: Switch */}
          <g transform="translate(160, 30)">
            <circle cx="0" cy="10" r="4" fill="#C9A95C" />
            <circle cx="50" cy="10" r="4" fill="#C9A95C" />
            <line
              x1="0"
              y1="10"
              x2={switchClosed ? "50" : "40"}
              y2={switchClosed ? "10" : "-10"}
              stroke="#C9A95C"
              strokeWidth="4"
              strokeLinecap="round"
            />
            <text x="25" y="-12" fill="#D5DEEE" fontSize="10" textAnchor="middle">
              {switchClosed ? 'Closed' : 'Open'}
            </text>
          </g>

          {/* Top-Right: Resistor */}
          <g transform="translate(290, 30)">
            <rect x="0" y="2" width="60" height="16" fill="#A27F35" stroke="#F4E5C8" strokeWidth="1.5" rx="3" />
            <line x1="15" y1="2" x2="15" y2="18" stroke="#080B4F" strokeWidth="2" />
            <line x1="30" y1="2" x2="30" y2="18" stroke="#C9A95C" strokeWidth="2" />
            <line x1="45" y1="2" x2="45" y2="18" stroke="#8194C6" strokeWidth="2" />
            <text x="30" y="-6" fill="#F4E5C8" fontSize="11" fontWeight="bold" textAnchor="middle">
              R = {resistance} Ω
            </text>
          </g>

          {/* Right: Incandescent Bulb */}
          <g transform="translate(450, 120)">
            {/* Bulb glow aura */}
            {brightness > 0 && (
              <circle
                cx="0"
                cy="0"
                r={20 + (brightness / 100) * 45}
                fill="#FDE047"
                opacity={0.15 + (brightness / 100) * 0.45}
                filter="blur(8px)"
              />
            )}
            {/* Glass bulb shell */}
            <circle
              cx="0"
              cy="0"
              r="24"
              fill={brightness > 10 ? `rgba(254, 240, 138, ${brightness / 120})` : 'rgba(255, 255, 255, 0.05)'}
              stroke="#D5DEEE"
              strokeWidth="2"
            />
            {/* Filament */}
            <path
              d="M -8 10 L -4 -6 L 0 6 L 4 -6 L 8 10"
              fill="none"
              stroke={brightness > 0 ? (brightness > 70 ? '#FFFFFF' : '#F59E0B') : '#6B7280'}
              strokeWidth="2.5"
            />
            <rect x="-8" y="18" width="16" height="8" fill="#4B5563" rx="2" />
            <text x="0" y="38" fill="#F4E5C8" fontSize="10" textAnchor="middle">
              {power} W
            </text>
          </g>

          {/* Bottom: In-line Ammeter */}
          <g transform="translate(250, 200)">
            <circle cx="0" cy="0" r="22" fill="#080B4F" stroke="#8194C6" strokeWidth="2" />
            <text x="0" y="6" fill="#C9A95C" fontSize="16" fontWeight="bold" textAnchor="middle">
              A
            </text>
            <text x="0" y="34" fill="#D5DEEE" fontSize="10" textAnchor="middle">
              Ammeter
            </text>
          </g>
        </svg>

        {/* Meters Dock: Analog Voltmeter & Ammeter Displays */}
        <div className="grid grid-cols-2 gap-4 mt-3 pt-3 border-t border-[#8194C6]/20">
          {/* Voltmeter Gauge */}
          <div className="bg-[#080B4F] rounded-lg p-3 border border-[#8194C6]/30 flex flex-col items-center">
            <div className="text-[11px] text-[#8194C6] font-medium uppercase tracking-wider mb-1">
              DC Voltmeter
            </div>
            <div className="w-24 h-12 relative overflow-hidden flex items-end justify-center">
              <div className="w-20 h-20 rounded-full border-4 border-[#8194C6]/40 absolute top-0" />
              <div
                className="w-1 h-12 bg-rose-500 origin-bottom transition-transform duration-300 absolute"
                style={{ transform: `rotate(${vAngle}deg)` }}
              />
              <div className="w-3 h-3 rounded-full bg-[#C9A95C] z-10" />
            </div>
            <div className="font-mono-data text-base font-bold text-[#F4E5C8] mt-1">
              {voltage.toFixed(1)} V
            </div>
          </div>

          {/* Ammeter Gauge */}
          <div className="bg-[#080B4F] rounded-lg p-3 border border-[#8194C6]/30 flex flex-col items-center">
            <div className="text-[11px] text-[#8194C6] font-medium uppercase tracking-wider mb-1">
              DC Ammeter
            </div>
            <div className="w-24 h-12 relative overflow-hidden flex items-end justify-center">
              <div className="w-20 h-20 rounded-full border-4 border-[#8194C6]/40 absolute top-0" />
              <div
                className="w-1 h-12 bg-amber-400 origin-bottom transition-transform duration-300 absolute"
                style={{ transform: `rotate(${aAngle}deg)` }}
              />
              <div className="w-3 h-3 rounded-full bg-[#C9A95C] z-10" />
            </div>
            <div className="font-mono-data text-base font-bold text-[#C9A95C] mt-1">
              {switchClosed ? current.toFixed(2) : '0.00'} A
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// SERIES CIRCUIT VISUALIZER
// =========================================================================
interface SeriesProps {
  voltage: number;
  r1: number;
  r2: number;
  current: number;
  b1Brightness: number;
  b2Brightness: number;
  switchClosed: boolean;
}

const SeriesCircuitVisualizer: React.FC<SeriesProps> = ({
  voltage,
  r1,
  r2,
  current,
  b1Brightness,
  b2Brightness,
  switchClosed
}) => {
  return (
    <div className="w-full max-w-xl bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40">
      <div className="text-center text-xs text-[#8194C6] mb-2 font-mono-data">
        Single Loop Series Configuration: R_total = {r1 + r2} Ω · Current = {switchClosed ? current : 0} A
      </div>
      <div className="grid grid-cols-2 gap-4 my-4">
        {/* Bulb 1 */}
        <div className="bg-[#080B4F] p-4 rounded-lg border border-[#8194C6]/30 flex flex-col items-center">
          <div className="text-xs text-[#C9A95C] font-semibold mb-2">Bulb 1 (R₁ = {r1} Ω)</div>
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center transition-all duration-300"
            style={{
              backgroundColor: switchClosed ? `rgba(254, 240, 138, ${b1Brightness / 100})` : 'rgba(255,255,255,0.05)',
              boxShadow: switchClosed && b1Brightness > 10 ? `0 0 24px rgba(254, 240, 138, ${b1Brightness / 100})` : 'none',
              border: '2px solid #8194C6'
            }}
          >
            <span className="text-2xl">💡</span>
          </div>
          <div className="mt-2 text-xs font-mono-data text-[#D5DEEE]">
            V₁ = {(current * r1).toFixed(1)} V
          </div>
        </div>

        {/* Bulb 2 */}
        <div className="bg-[#080B4F] p-4 rounded-lg border border-[#8194C6]/30 flex flex-col items-center">
          <div className="text-xs text-[#C9A95C] font-semibold mb-2">Bulb 2 (R₂ = {r2} Ω)</div>
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center transition-all duration-300"
            style={{
              backgroundColor: switchClosed ? `rgba(254, 240, 138, ${b2Brightness / 100})` : 'rgba(255,255,255,0.05)',
              boxShadow: switchClosed && b2Brightness > 10 ? `0 0 24px rgba(254, 240, 138, ${b2Brightness / 100})` : 'none',
              border: '2px solid #8194C6'
            }}
          >
            <span className="text-2xl">💡</span>
          </div>
          <div className="mt-2 text-xs font-mono-data text-[#D5DEEE]">
            V₂ = {(current * r2).toFixed(1)} V
          </div>
        </div>
      </div>
      <div className="text-center text-xs text-[#F4E5C8]/80 font-mono-data">
        Supply V: {voltage} V = V₁ ({(current * r1).toFixed(1)}V) + V₂ ({(current * r2).toFixed(1)}V)
      </div>
    </div>
  );
};

// =========================================================================
// PARALLEL CIRCUIT VISUALIZER
// =========================================================================
interface ParallelProps {
  voltage: number;
  r1: number;
  r2: number;
  i1: number;
  i2: number;
  iTotal: number;
  b1Brightness: number;
  b2Brightness: number;
}

const ParallelCircuitVisualizer: React.FC<ParallelProps> = ({
  voltage,
  r1,
  r2,
  i1,
  i2,
  iTotal,
  b1Brightness,
  b2Brightness
}) => {
  return (
    <div className="w-full max-w-xl bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40">
      <div className="text-center text-xs text-[#8194C6] mb-3 font-mono-data">
        Parallel Branches · Common Supply: {voltage} V · I_total: {iTotal} A
      </div>
      <div className="space-y-3">
        {/* Branch 1 */}
        <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center"
              style={{
                backgroundColor: `rgba(254, 240, 138, ${b1Brightness / 100})`,
                boxShadow: `0 0 16px rgba(254, 240, 138, ${b1Brightness / 100})`,
                border: '1px solid #8194C6'
              }}
            >
              <span className="text-lg">💡</span>
            </div>
            <div>
              <div className="text-xs font-semibold text-[#F4E5C8]">Branch 1 (R₁ = {r1} Ω)</div>
              <div className="text-[11px] text-[#8194C6]">Full Voltage: {voltage} V</div>
            </div>
          </div>
          <div className="text-right font-mono-data text-xs text-[#C9A95C]">
            I₁ = {i1} A
          </div>
        </div>

        {/* Branch 2 */}
        <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center"
              style={{
                backgroundColor: `rgba(254, 240, 138, ${b2Brightness / 100})`,
                boxShadow: `0 0 16px rgba(254, 240, 138, ${b2Brightness / 100})`,
                border: '1px solid #8194C6'
              }}
            >
              <span className="text-lg">💡</span>
            </div>
            <div>
              <div className="text-xs font-semibold text-[#F4E5C8]">Branch 2 (R₂ = {r2} Ω)</div>
              <div className="text-[11px] text-[#8194C6]">Full Voltage: {voltage} V</div>
            </div>
          </div>
          <div className="text-right font-mono-data text-xs text-[#C9A95C]">
            I₂ = {i2} A
          </div>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// SIMPLE MOTION VISUALIZER
// =========================================================================
interface MotionProps {
  rampAngle: number;
  trackLength: number;
  friction: number;
  acceleration: number;
  finalVelocity: number;
  transitTime: number;
  isRunning: boolean;
  animProgress: number;
}

const SimpleMotionVisualizer: React.FC<MotionProps> = ({
  rampAngle,
  trackLength,
  acceleration,
  finalVelocity,
  transitTime,
  isRunning,
  animProgress
}) => {
  // Normalize cart position along ramp (0 to 1)
  const cartRatio = isRunning && transitTime > 0 ? Math.min(1, animProgress / transitTime) : 0;
  const cartX = 60 + cartRatio * 320;
  const cartY = 60 + Math.tan((rampAngle * Math.PI) / 180) * cartRatio * 80;

  return (
    <div className="w-full max-w-xl bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40">
      <svg viewBox="0 0 440 200" className="w-full h-auto">
        {/* Inclined Track Ramp */}
        <polygon
          points={`40,160 400,160 40,${160 - Math.tan((rampAngle * Math.PI) / 180) * 280}`}
          fill="#080B4F"
          stroke="#8194C6"
          strokeWidth="3"
        />

        {/* Dynamics Cart on ramp */}
        <g transform={`translate(${cartX}, ${145 - Math.tan((rampAngle * Math.PI) / 180) * (380 - cartX)}) rotate(${rampAngle})`}>
          <rect x="-16" y="-12" width="32" height="14" fill="#C9A95C" stroke="#F4E5C8" strokeWidth="1.5" rx="3" />
          <circle cx="-10" cy="5" r="4" fill="#080B4F" stroke="#D5DEEE" strokeWidth="1.5" />
          <circle cx="10" cy="5" r="4" fill="#080B4F" stroke="#D5DEEE" strokeWidth="1.5" />
        </g>

        {/* Start Gate */}
        <line x1="70" y1="50" x2="70" y2="160" stroke="#EF4444" strokeWidth="2" strokeDasharray="4 4" />
        <text x="70" y="42" fill="#EF4444" fontSize="10" textAnchor="middle">Gate 1</text>

        {/* End Photogate */}
        <line x1="380" y1="120" x2="380" y2="160" stroke="#10B981" strokeWidth="2" strokeDasharray="4 4" />
        <text x="380" y="112" fill="#10B981" fontSize="10" textAnchor="middle">Gate 2</text>
      </svg>
      <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-[#8194C6]/30 text-center font-mono-data text-xs">
        <div>a: <span className="text-[#C9A95C]">{acceleration} m/s²</span></div>
        <div>v_terminal: <span className="text-[#C9A95C]">{finalVelocity} m/s</span></div>
        <div>Time: <span className="text-[#C9A95C]">{transitTime} s</span></div>
      </div>
    </div>
  );
};

// =========================================================================
// ACID & BASE TITRATION VISUALIZER
// =========================================================================
interface AcidBaseProps {
  acidVol: number;
  baseAdded: number;
  ph: number;
  indicatorColor: string;
  isRunning: boolean;
  eqVolume: number;
}

const AcidBaseVisualizer: React.FC<AcidBaseProps> = ({
  acidVol,
  baseAdded,
  ph,
  indicatorColor,
  isRunning,
  eqVolume
}) => {
  return (
    <div className="w-full max-w-lg bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40 flex flex-col sm:flex-row items-center justify-around gap-6">
      {/* Burette & Flask Graphic */}
      <div className="relative w-44 h-64 flex flex-col items-center">
        {/* Burette Tube */}
        <div className="w-6 h-36 bg-blue-950/60 border-2 border-[#8194C6] rounded-t relative overflow-hidden">
          <div
            className="w-full bg-[#8194C6]/50 absolute bottom-0 transition-all duration-300"
            style={{ height: `${Math.max(5, 100 - (baseAdded / 50) * 100)}%` }}
          />
          {/* Graduation ticks */}
          <div className="absolute inset-0 flex flex-col justify-between py-1 px-0.5 text-[7px] text-[#D5DEEE] opacity-60">
            <span>0</span>
            <span>25</span>
            <span>50</span>
          </div>
        </div>

        {/* Burette Stopcock nozzle */}
        <div className="w-3 h-5 bg-[#C9A95C] my-0.5 rounded-sm relative">
          {isRunning && (
            <div className="w-1.5 h-1.5 rounded-full bg-blue-200 absolute -bottom-3 left-0.5 animate-bounce" />
          )}
        </div>

        {/* Erlenmeyer Flask */}
        <div className="w-32 h-24 relative mt-2">
          {/* Flask neck and body */}
          <div
            className="w-full h-full border-2 border-[#8194C6] rounded-b-3xl relative overflow-hidden"
            style={{
              clipPath: 'polygon(35% 0%, 65% 0%, 100% 100%, 0% 100%)',
              backgroundColor: 'rgba(255, 255, 255, 0.05)'
            }}
          >
            {/* Liquid inside flask */}
            <div
              className="w-full absolute bottom-0 transition-all duration-500"
              style={{
                height: `${Math.min(90, 30 + ((acidVol + baseAdded) / 100) * 55)}%`,
                backgroundColor: indicatorColor,
                opacity: ph >= 8.2 ? 0.75 : 0.25
              }}
            />
            {/* Spinning magnetic stir bar */}
            {isRunning && (
              <div className="w-6 h-1.5 bg-white rounded-full absolute bottom-2 left-1/2 -translate-x-1/2 animate-spin" />
            )}
          </div>
        </div>
      </div>

      {/* Titration Live Readout & pH Bar */}
      <div className="w-full sm:w-56 space-y-3">
        <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30">
          <div className="text-[11px] text-[#8194C6] uppercase font-medium">Digital pH Meter</div>
          <div className="text-2xl font-bold font-mono-data text-[#C9A95C]">{ph.toFixed(2)}</div>
          <div className="text-[11px] text-[#D5DEEE]">
            {ph < 6.8 ? 'Acidic Solution' : ph > 7.2 ? 'Alkaline (Pink End Point)' : 'Equivalence Point'}
          </div>
        </div>

        <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30 text-xs font-mono-data space-y-1">
          <div className="flex justify-between">
            <span className="text-[#8194C6]">Titrant Dispensed:</span>
            <span className="text-[#F4E5C8]">{baseAdded} mL</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#8194C6]">Target Equivalence:</span>
            <span className="text-[#C9A95C]">{eqVolume} mL</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// pH SCALE VISUALIZER
// =========================================================================
interface PhScaleProps {
  solutionIndex: number;
  measuredPh: number;
  hConc: string;
  liquidName: string;
  color: string;
}

const PhScaleVisualizer: React.FC<PhScaleProps> = ({
  measuredPh,
  hConc,
  liquidName,
  color
}) => {
  return (
    <div className="w-full max-w-xl bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs text-[#8194C6] uppercase">Active Analyte</div>
          <div className="text-lg font-serif-display font-semibold text-[#F4E5C8]">{liquidName}</div>
        </div>
        <div
          className="px-4 py-2 rounded-lg font-mono-data text-lg font-bold text-white shadow"
          style={{ backgroundColor: color }}
        >
          pH {measuredPh.toFixed(1)}
        </div>
      </div>

      {/* pH Spectrum Bar 1 - 14 */}
      <div className="space-y-1">
        <div className="h-5 w-full rounded-md flex overflow-hidden border border-white/20">
          {[
            '#EF4444', '#F97316', '#F59E0B', '#EAB308', '#84CC16', '#22C55E', '#10B981',
            '#14B8A6', '#06B6D4', '#0EA5E9', '#3B82F6', '#6366F1', '#8B5CF6', '#A855F7'
          ].map((c, i) => (
            <div key={i} className="flex-1 flex items-center justify-center text-[9px] font-bold text-white/90" style={{ backgroundColor: c }}>
              {i + 1}
            </div>
          ))}
        </div>
        {/* Indicator marker */}
        <div className="relative h-4">
          <div
            className="absolute top-0 -translate-x-1/2 w-3 h-3 bg-white rotate-45 border border-black shadow transition-all duration-300"
            style={{ left: `${((measuredPh - 1) / 13) * 100}%` }}
          />
        </div>
      </div>

      <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30 text-xs font-mono-data flex justify-between">
        <span className="text-[#8194C6]">[H⁺] Hydronium Ion:</span>
        <span className="text-[#C9A95C]">{hConc} M</span>
      </div>
    </div>
  );
};

// =========================================================================
// SOLUTION CONCENTRATION VISUALIZER
// =========================================================================
interface SolConcProps {
  mass: number;
  volume: number;
  temp: number;
  molarity: number;
  precipitate: number;
  isSaturated: boolean;
}

const SolutionConcentrationVisualizer: React.FC<SolConcProps> = ({
  mass,
  volume,
  temp,
  molarity,
  precipitate,
  isSaturated
}) => {
  return (
    <div className="w-full max-w-md bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40 flex items-center justify-around gap-6">
      {/* Beaker with solution */}
      <div className="w-36 h-48 border-2 border-t-0 border-[#8194C6] rounded-b-xl relative overflow-hidden bg-white/5">
        {/* Graduations */}
        <div className="absolute right-1 top-2 bottom-2 flex flex-col justify-between text-[8px] text-[#8194C6]">
          <span>500mL</span>
          <span>250mL</span>
          <span>100mL</span>
        </div>

        {/* Liquid level & copper blue color */}
        <div
          className="w-full absolute bottom-0 transition-all duration-500"
          style={{
            height: `${Math.min(90, (volume / 500) * 90)}%`,
            backgroundColor: `rgba(14, 116, 144, ${Math.min(0.9, 0.2 + molarity * 0.4)})`
          }}
        >
          {/* Precipitate crystals at bottom if saturated */}
          {precipitate > 0 && (
            <div
              className="w-full bg-[#1e40af] border-t border-[#38bdf8] absolute bottom-0 transition-all"
              style={{ height: `${Math.min(25, precipitate * 1.2)}px` }}
            />
          )}
        </div>
      </div>

      <div className="space-y-3 text-xs font-mono-data">
        <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30">
          <div className="text-[11px] text-[#8194C6]">Molar Concentration</div>
          <div className="text-xl font-bold text-[#C9A95C]">{molarity} M</div>
        </div>
        <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30 space-y-1">
          <div>Temp: <span className="text-[#F4E5C8]">{temp} °C</span></div>
          <div>Precipitate: <span className="text-amber-400">{precipitate} g</span></div>
          <div className={isSaturated ? 'text-amber-300 font-semibold' : 'text-emerald-400'}>
            {isSaturated ? '● Saturated' : '● Dissolved'}
          </div>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// CHEMICAL REACTION VISUALIZER
// =========================================================================
interface ChemReactionProps {
  molarity: number;
  temp: number;
  gasVolume: number;
  rateIndex: number;
  isRunning: boolean;
}

const ChemicalReactionVisualizer: React.FC<ChemReactionProps> = ({
  molarity,
  gasVolume,
  rateIndex,
  isRunning
}) => {
  return (
    <div className="w-full max-w-lg bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40 flex flex-col sm:flex-row items-center justify-around gap-4">
      {/* Flask effervescence */}
      <div className="relative w-28 h-36 flex flex-col items-center">
        <div className="w-32 h-28 border-2 border-[#8194C6] rounded-b-full bg-white/5 relative overflow-hidden">
          <div className="w-full h-16 bg-blue-900/40 absolute bottom-0" />
          {/* Effervescent bubbles */}
          {isRunning && (
            <div className="absolute inset-x-2 bottom-2 top-8 flex justify-around">
              <span className="w-2 h-2 bg-white rounded-full animate-ping" />
              <span className="w-1.5 h-1.5 bg-white rounded-full animate-bounce" />
              <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
            </div>
          )}
        </div>
        <div className="text-[10px] text-[#C9A95C] mt-1 font-mono-data">CaCO₃ + {molarity}M HCl</div>
      </div>

      {/* Gas Syringe with sliding plunger */}
      <div className="w-48 bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30">
        <div className="text-[11px] text-[#8194C6] uppercase font-semibold mb-1">CO₂ Gas Syringe</div>
        <div className="w-full h-8 bg-black/40 border border-[#8194C6] rounded relative overflow-hidden flex items-center">
          <div
            className="h-full bg-sky-500/60 border-r-4 border-white transition-all duration-300"
            style={{ width: `${Math.min(100, (gasVolume / 100) * 100)}%` }}
          />
        </div>
        <div className="flex justify-between text-xs font-mono-data text-[#C9A95C] mt-1">
          <span>0 mL</span>
          <span>{gasVolume} mL captured</span>
          <span>100 mL</span>
        </div>
        <div className="text-[10px] text-[#8194C6] mt-2">
          Rate Index: {rateIndex} rel. u.
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// PLANT GROWTH VISUALIZER
// =========================================================================
interface PlantProps {
  light: number;
  co2: number;
  bubbleRate: number;
  growthMm: number;
  isRunning: boolean;
}

const PlantGrowthVisualizer: React.FC<PlantProps> = ({
  light,
  bubbleRate,
  growthMm,
  isRunning
}) => {
  return (
    <div className="w-full max-w-md bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40 flex items-center justify-around gap-6">
      {/* Chamber */}
      <div className="w-28 h-48 border-2 border-[#8194C6] rounded-t-lg bg-emerald-950/30 relative flex flex-col items-center justify-end pb-2 overflow-hidden">
        {/* Submerged Elodea Plant */}
        <div className="text-4xl text-emerald-400">🌿</div>
        {/* Floating Oxygen Bubbles */}
        {isRunning && (
          <div className="absolute inset-0 flex flex-col items-center justify-around">
            <span className="w-2 h-2 rounded-full bg-sky-300/80 animate-bounce" />
            <span className="w-1.5 h-1.5 rounded-full bg-sky-300/80 animate-ping" />
            <span className="w-2.5 h-2.5 rounded-full bg-sky-300/80 animate-pulse" />
          </div>
        )}
      </div>

      <div className="space-y-3 font-mono-data text-xs">
        <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30">
          <div className="text-[11px] text-[#8194C6]">O₂ Bubble Emission</div>
          <div className="text-xl font-bold text-[#C9A95C]">{bubbleRate} bubbles/min</div>
        </div>
        <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30">
          <div className="text-[11px] text-[#8194C6]">Vegetative Elongation</div>
          <div className="text-lg font-bold text-emerald-400">+{growthMm} mm / day</div>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// CELL OSMOSIS VISUALIZER
// =========================================================================
interface CellProps {
  isAnimal: boolean;
  saline: number;
  magnification: number;
  volumePct: number;
  tonicity: string;
}

const CellOsmosisVisualizer: React.FC<CellProps> = ({
  isAnimal,
  saline,
  magnification,
  volumePct,
  tonicity
}) => {
  return (
    <div className="w-full max-w-md bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40 flex flex-col sm:flex-row items-center justify-around gap-4">
      {/* Microscope Circular Ocular View */}
      <div className="w-44 h-44 rounded-full border-4 border-[#C9A95C] bg-black/80 flex items-center justify-center relative overflow-hidden shadow-2xl">
        {/* Microscope reticle crosshair */}
        <div className="absolute w-full h-[1px] bg-white/20" />
        <div className="absolute h-full w-[1px] bg-white/20" />

        {/* Cell Graphic */}
        {isAnimal ? (
          // Red blood cell (biconcave disc)
          <div
            className="rounded-full bg-rose-600 transition-all duration-500 shadow-inner"
            style={{
              width: `${Math.min(100, 48 * (volumePct / 100))}px`,
              height: `${Math.min(100, 48 * (volumePct / 100))}px`,
              border: saline < 0.6 ? '2px dashed #fca5a5' : '2px solid #b91c1c'
            }}
          />
        ) : (
          // Plant cell with rigid cell wall
          <div className="w-28 h-20 border-2 border-emerald-500 bg-emerald-950/40 rounded flex items-center justify-center p-1">
            <div
              className="bg-emerald-600/60 rounded border border-emerald-400 transition-all duration-500"
              style={{
                width: `${Math.min(100, (volumePct / 100) * 100)}%`,
                height: `${Math.min(100, (volumePct / 100) * 100)}%`
              }}
            />
          </div>
        )}
      </div>

      <div className="space-y-2 text-xs font-mono-data">
        <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30">
          <div className="text-[11px] text-[#8194C6]">Tonicity State</div>
          <div className="font-semibold text-[#F4E5C8]">{tonicity}</div>
          <div className="text-[#C9A95C] mt-1">Cytoplasm Volume: {volumePct}%</div>
        </div>
        <div className="text-[10px] text-[#D5DEEE] text-center">
          Objective: {magnification}x · Saline: {saline}% NaCl
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// GENETICS VISUALIZER
// =========================================================================
interface GeneticsProps {
  p1: number;
  p2: number;
  purpleCount: number;
  whiteCount: number;
  ratio: string;
}

const GeneticsVisualizer: React.FC<GeneticsProps> = ({
  p1,
  p2,
  purpleCount,
  whiteCount,
  ratio
}) => {
  const g1 = p1 === 0 ? ['P', 'P'] : p1 === 1 ? ['P', 'p'] : ['p', 'p'];
  const g2 = p2 === 0 ? ['P', 'P'] : p2 === 1 ? ['P', 'p'] : ['p', 'p'];

  return (
    <div className="w-full max-w-md bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40">
      <div className="text-center text-xs text-[#8194C6] mb-2 font-mono-data">
        Mendelian Monohybrid Cross · {g1.join('')} × {g2.join('')}
      </div>
      {/* 2x2 Punnett Matrix */}
      <div className="grid grid-cols-2 gap-2 my-3 max-w-[220px] mx-auto text-center font-mono-data font-bold text-sm">
        <div className="p-3 bg-[#080B4F] border border-[#8194C6]/40 rounded text-[#C9A95C]">
          {g1[0] + g2[0]}
        </div>
        <div className="p-3 bg-[#080B4F] border border-[#8194C6]/40 rounded text-[#C9A95C]">
          {g1[0] + g2[1]}
        </div>
        <div className="p-3 bg-[#080B4F] border border-[#8194C6]/40 rounded text-[#C9A95C]">
          {g1[1] + g2[0]}
        </div>
        <div className="p-3 bg-[#080B4F] border border-[#8194C6]/40 rounded text-[#C9A95C]">
          {g1[1] + g2[1]}
        </div>
      </div>
      <div className="flex justify-around text-xs font-mono-data mt-2 pt-2 border-t border-[#8194C6]/30">
        <div className="text-purple-300">🌸 Purple: {purpleCount}</div>
        <div className="text-slate-300">⚪ White: {whiteCount}</div>
        <div className="text-[#C9A95C]">{ratio}</div>
      </div>
    </div>
  );
};

// =========================================================================
// WATER QUALITY VISUALIZER
// =========================================================================
interface WaterProps {
  doVal: number;
  turbidity: number;
  nitrates: number;
  wqi: number;
  status: string;
}

const WaterQualityVisualizer: React.FC<WaterProps> = ({
  doVal,
  turbidity,
  nitrates,
  wqi,
  status
}) => {
  return (
    <div className="w-full max-w-md bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40 flex items-center justify-around gap-6">
      {/* Water Sample Vessel */}
      <div className="w-28 h-40 border-2 border-[#8194C6] rounded-b-xl relative overflow-hidden bg-white/5 flex flex-col items-center justify-center">
        <div
          className="w-full absolute bottom-0 transition-all duration-300"
          style={{
            height: '80%',
            backgroundColor: turbidity > 30 ? '#78716c' : '#38bdf8',
            opacity: 0.6
          }}
        />
        <div className="relative z-10 text-center font-mono-data text-xs text-[#080B4F] font-bold">
          {doVal} mg/L DO
        </div>
      </div>

      <div className="space-y-3 font-mono-data text-xs">
        <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30">
          <div className="text-[11px] text-[#8194C6]">Water Quality Index</div>
          <div className="text-2xl font-bold text-[#C9A95C]">{wqi} / 100</div>
          <div className="text-[10px] text-emerald-400 mt-1">{status}</div>
        </div>
        <div className="text-[11px] text-[#D5DEEE]">
          Turbidity: {turbidity} NTU · Nitrates: {nitrates} ppm
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// RENEWABLE ENERGY VISUALIZER
// =========================================================================
interface RenewableProps {
  irradiance: number;
  panelAngle: number;
  windSpeed: number;
  solarPower: number;
  windPower: number;
  totalPower: number;
  isRunning: boolean;
}

const RenewableEnergyVisualizer: React.FC<RenewableProps> = ({
  irradiance,
  panelAngle,
  windSpeed,
  solarPower,
  windPower,
  totalPower,
  isRunning
}) => {
  return (
    <div className="w-full max-w-lg bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40 flex flex-col sm:flex-row items-center justify-around gap-4">
      {/* Solar Panel & Wind Turbine Icons with rotation */}
      <div className="flex items-center gap-6">
        {/* Solar Panel */}
        <div className="text-center">
          <div
            className="w-16 h-12 bg-blue-900 border-2 border-[#8194C6] rounded shadow flex items-center justify-center transition-transform"
            style={{ transform: `rotate(${-panelAngle / 3}deg)` }}
          >
            <span className="text-xl">☀️</span>
          </div>
          <div className="text-[10px] text-[#C9A95C] mt-1 font-mono-data">{solarPower} W</div>
        </div>

        {/* Wind Turbine */}
        <div className="text-center">
          <div className="w-12 h-16 flex flex-col items-center justify-between">
            <div className={`text-2xl ${isRunning ? 'animate-spin' : ''}`} style={{ animationDuration: `${Math.max(0.4, 3 / windSpeed)}s` }}>
              🌀
            </div>
            <div className="w-1 h-8 bg-slate-400" />
          </div>
          <div className="text-[10px] text-[#C9A95C] mt-1 font-mono-data">{windPower} W</div>
        </div>
      </div>

      <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30 font-mono-data text-xs space-y-1">
        <div className="text-[11px] text-[#8194C6] uppercase">Combined Generation</div>
        <div className="text-2xl font-bold text-[#F4E5C8]">{totalPower} W</div>
        <div className="text-[10px] text-emerald-400">Clean Renewable Microgrid</div>
      </div>
    </div>
  );
};

// =========================================================================
// FOREST & CARBON VISUALIZER
// =========================================================================
interface ForestProps {
  hectares: number;
  age: number;
  density: number;
  tonsCO2: number;
}

const ForestCarbonVisualizer: React.FC<ForestProps> = ({
  hectares,
  age,
  tonsCO2
}) => {
  return (
    <div className="w-full max-w-md bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40 flex items-center justify-around gap-4">
      <div className="text-4xl text-emerald-500">🌲🌳🌲</div>
      <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30 font-mono-data text-xs space-y-1">
        <div className="text-[11px] text-[#8194C6]">CO₂ Sequestered</div>
        <div className="text-xl font-bold text-[#C9A95C]">{tonsCO2.toLocaleString()} t / yr</div>
        <div className="text-[10px] text-[#D5DEEE]">{hectares} ha stand · {age} yrs age</div>
      </div>
    </div>
  );
};

// =========================================================================
// RECYCLING IMPACT VISUALIZER
// =========================================================================
interface RecyclingProps {
  alKg: number;
  plasticKg: number;
  paperKg: number;
  energyKwh: number;
  co2Kg: number;
}

const RecyclingVisualizer: React.FC<RecyclingProps> = ({
  energyKwh,
  co2Kg
}) => {
  return (
    <div className="w-full max-w-md bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40 flex items-center justify-around gap-4">
      <div className="text-4xl text-emerald-400">♻️</div>
      <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30 font-mono-data text-xs space-y-1">
        <div className="text-[11px] text-[#8194C6]">Energy Conserved</div>
        <div className="text-xl font-bold text-[#C9A95C]">{energyKwh.toLocaleString()} kWh</div>
        <div className="text-[10px] text-emerald-300">GHG Avoided: {co2Kg.toLocaleString()} kg CO₂</div>
      </div>
    </div>
  );
};

// =========================================================================
// PROJECTILE MOTION VISUALIZER
// =========================================================================
interface ProjectileProps {
  v0: number;
  angle: number;
  g: number;
  range: number;
  maxHeight: number;
  time: number;
  isRunning: boolean;
  chartData?: any;
}

const ProjectileVisualizer: React.FC<ProjectileProps> = ({
  v0,
  angle,
  range,
  maxHeight,
  time,
  chartData
}) => {
  return (
    <div className="w-full max-w-2xl bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40 space-y-4">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Cannon & Angle Arc */}
        <div className="flex items-center gap-4">
          <div className="relative w-20 h-20 flex items-center justify-center">
            {/* Cannon barrel rotating with angle */}
            <div
              className="w-12 h-4 bg-[#C9A95C] border border-[#F4E5C8] rounded origin-left transition-transform shadow"
              style={{ transform: `rotate(${-angle}deg)` }}
            />
            {/* Cannon Base Wheel */}
            <div className="w-8 h-8 rounded-full bg-[#080B4F] border-2 border-[#8194C6] absolute left-0 bottom-2" />
          </div>
          <div>
            <div className="text-xs font-semibold text-[#F4E5C8]">Ballistic Cannon Launcher</div>
            <div className="text-[11px] font-mono-data text-[#C9A95C]">
              v₀ = {v0} m/s · Angle = {angle}°
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 text-xs font-mono-data text-center bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30">
          <div>Range: <span className="text-[#C9A95C] font-bold">{range}m</span></div>
          <div>Apex: <span className="text-[#C9A95C] font-bold">{maxHeight}m</span></div>
          <div>Time: <span className="text-[#C9A95C] font-bold">{time}s</span></div>
        </div>
      </div>

      {chartData && (
        <LiveChart
          data={chartData}
          title="Parabolic Trajectory Plot (y vs x)"
          xLabel="Range (m)"
          yLabel="Altitude (m)"
        />
      )}
    </div>
  );
};

// =========================================================================
// SIMPLE PENDULUM VISUALIZER
// =========================================================================
interface PendulumProps {
  length: number;
  period: number;
  frequency: number;
  isRunning: boolean;
  animProgress: number;
}

const PendulumVisualizer: React.FC<PendulumProps> = ({
  length,
  period,
  frequency,
  isRunning,
  animProgress
}) => {
  // Harmonic oscillation angle (-20 to +20 deg)
  const currentAngle = isRunning && period > 0
    ? Math.sin((animProgress * 2 * Math.PI) / period) * 22
    : 15;

  return (
    <div className="w-full max-w-lg bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40 flex flex-col sm:flex-row items-center justify-around gap-6">
      {/* Swinging pendulum SVG */}
      <div className="w-48 h-56 relative flex justify-center">
        <svg viewBox="0 0 200 220" className="w-full h-full">
          {/* Top pivot mounting */}
          <rect x="70" y="10" width="60" height="8" fill="#8194C6" rx="2" />
          <circle cx="100" cy="14" r="4" fill="#C9A95C" />

          {/* Swinging string & bob */}
          <g transform={`rotate(${currentAngle} 100 14)`}>
            <line
              x1="100"
              y1="14"
              x2="100"
              y2={60 + length * 70}
              stroke="#D5DEEE"
              strokeWidth="2"
            />
            <circle
              cx="100"
              cy={60 + length * 70}
              r="16"
              fill="#C9A95C"
              stroke="#F4E5C8"
              strokeWidth="2"
            />
          </g>
        </svg>
      </div>

      <div className="space-y-3 font-mono-data text-xs">
        <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30">
          <div className="text-[11px] text-[#8194C6]">Harmonic Period (T)</div>
          <div className="text-2xl font-bold text-[#C9A95C]">{period} s</div>
        </div>
        <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30 space-y-1">
          <div>Frequency: <span className="text-[#F4E5C8]">{frequency} Hz</span></div>
          <div>String Length: <span className="text-[#F4E5C8]">{length} m</span></div>
          <div className="text-[10px] text-emerald-400">T = 2π √(L/g)</div>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// HOOKE'S LAW VISUALIZER
// =========================================================================
interface HookeProps {
  k: number;
  force: number;
  extensionCm: number;
  pe: number;
  chartData?: any;
}

const HookesLawVisualizer: React.FC<HookeProps> = ({
  k,
  force,
  extensionCm,
  pe,
  chartData
}) => {
  return (
    <div className="w-full max-w-2xl bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40 space-y-4">
      <div className="flex flex-col sm:flex-row items-center justify-around gap-6">
        {/* Spring & Weight graphic */}
        <div className="w-36 h-48 border-l-2 border-[#8194C6]/50 pl-4 relative flex flex-col items-center">
          {/* Top bracket */}
          <div className="w-20 h-4 bg-[#8194C6] rounded-t-sm" />
          {/* Spring Coils */}
          <div
            className="w-10 border-x-2 border-dashed border-[#C9A95C] transition-all duration-300"
            style={{ height: `${Math.min(110, 40 + extensionCm * 3.5)}px` }}
          />
          {/* Hanging Load */}
          <div className="w-14 h-10 bg-[#A27F35] border border-[#F4E5C8] rounded flex items-center justify-center font-mono-data text-xs font-bold text-white shadow">
            {force} N
          </div>
        </div>

        <div className="space-y-3 font-mono-data text-xs">
          <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30">
            <div className="text-[11px] text-[#8194C6]">Spring Extension (Δx)</div>
            <div className="text-2xl font-bold text-[#C9A95C]">{extensionCm} cm</div>
          </div>
          <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30 space-y-1">
            <div>Spring Constant: <span className="text-[#F4E5C8]">{k} N/m</span></div>
            <div>Stored Elastic PE: <span className="text-emerald-400">{pe} J</span></div>
          </div>
        </div>
      </div>

      {chartData && (
        <LiveChart
          data={chartData}
          title="Force vs Extension (Linear Elastic Slope)"
          xLabel="Extension (cm)"
          yLabel="Applied Force (N)"
        />
      )}
    </div>
  );
};

// =========================================================================
// REFRACTION SNELL'S LAW VISUALIZER
// =========================================================================
interface RefractionProps {
  theta1: number;
  theta2: number;
  n2: number;
  crit: number;
}

const RefractionVisualizer: React.FC<RefractionProps> = ({
  theta1,
  theta2,
  n2,
  crit
}) => {
  return (
    <div className="w-full max-w-lg bg-[#050736] p-4 rounded-xl border border-[#8194C6]/40 flex flex-col sm:flex-row items-center justify-around gap-6">
      {/* Prism Boundary Diagram */}
      <div className="w-48 h-48 relative flex items-center justify-center">
        <svg viewBox="0 0 200 200" className="w-full h-full">
          {/* Dense medium semicircular block */}
          <path d="M 20 100 A 80 80 0 0 0 180 100 Z" fill="#0c1a66" stroke="#8194C6" strokeWidth="2" />
          {/* Normal line */}
          <line x1="100" y1="20" x2="100" y2="180" stroke="#D5DEEE" strokeDasharray="3 3" strokeWidth="1.5" />
          {/* Incident Laser Ray */}
          <line
            x1={100 - Math.tan((theta1 * Math.PI) / 180) * 80}
            y1="20"
            x2="100"
            y2="100"
            stroke="#EF4444"
            strokeWidth="2.5"
          />
          {/* Refracted Ray in dense medium */}
          <line
            x1="100"
            y1="100"
            x2={100 + Math.tan((theta2 * Math.PI) / 180) * 70}
            y2="170"
            stroke="#EF4444"
            strokeWidth="2.5"
          />
        </svg>
      </div>

      <div className="space-y-3 font-mono-data text-xs">
        <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30">
          <div className="text-[11px] text-[#8194C6]">Refraction Angle (θ₂)</div>
          <div className="text-2xl font-bold text-[#C9A95C]">{theta2}°</div>
        </div>
        <div className="bg-[#080B4F] p-3 rounded-lg border border-[#8194C6]/30 space-y-1">
          <div>Incident Angle: <span className="text-[#F4E5C8]">{theta1}°</span></div>
          <div>Medium Index (n₂): <span className="text-[#F4E5C8]">{n2}</span></div>
          <div>Critical Angle: <span className="text-amber-400">{crit}°</span></div>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// UNIVERSAL APPARATUS VISUALIZER (FOR ALL 60 EXPERIMENTS)
// =========================================================================
interface UniversalProps {
  experiment: ExperimentDef;
  inputs: Record<string, number | string | boolean>;
  simulation: SimulationState;
  isRunning: boolean;
}

const UniversalApparatusVisualizer: React.FC<UniversalProps> = ({
  experiment,
  inputs,
  simulation,
  isRunning
}) => {
  return (
    <div className="w-full max-w-2xl bg-[#050736] p-5 rounded-2xl border border-[#8194C6]/40 space-y-5">
      {/* Visual Apparatus Rack */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#8194C6]/30 pb-4">
        <div>
          <span className="text-[10px] font-mono-data uppercase tracking-wider text-[#C9A95C]">
            {experiment.category} Laboratory Apparatus
          </span>
          <h4 className="font-serif-display font-bold text-lg text-[#F4E5C8]">
            {experiment.title}
          </h4>
        </div>

        <div className="flex items-center gap-2">
          {experiment.equipment.slice(0, 4).map((eq, i) => (
            <div
              key={i}
              className="w-10 h-10 rounded-xl bg-[#080B4F] border border-[#8194C6]/40 flex items-center justify-center text-lg shadow"
              title={`${eq.name}: ${eq.spec}`}
            >
              {eq.icon}
            </div>
          ))}
        </div>
      </div>

      {/* Dynamic Animated Domain-Specific Apparatus Stage */}
      <DynamicApparatusStage
        experiment={experiment}
        inputs={inputs}
        simulation={simulation}
        isRunning={isRunning}
      />

      {/* Live Digital Telemetry Gauges */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {Object.entries(simulation.outputs).map(([key, val]) => (
          <div
            key={key}
            className="p-3 rounded-xl bg-[#080B4F] border border-[#8194C6]/30 font-mono-data text-xs space-y-1"
          >
            <div className="text-[10px] text-[#8194C6] truncate">{key}</div>
            <div className="text-lg font-bold text-[#F4E5C8] truncate">
              {String(val)} <span className="text-xs text-[#C9A95C]">{simulation.units[key] || ''}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Embedded Telemetry Chart if available */}
      {simulation.chartData && (
        <LiveChart
          data={simulation.chartData}
          title={simulation.chartTitle || 'Experimental Telemetry Dynamics'}
          xLabel={simulation.chartXLabel || 'Controlled Parameter'}
          yLabel={simulation.chartYLabel || 'Measured Output'}
        />
      )}
    </div>
  );
};

