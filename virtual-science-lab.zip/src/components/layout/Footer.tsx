import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="no-print mt-auto bg-[#080B4F] text-[#D5DEEE] border-t border-[#8194C6]/20 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-2">
          <span className="font-serif-display font-bold text-sm text-[#F4E5C8]">Virtual Science Lab</span>
          <span className="text-[#8194C6]">—</span>
          <span className="text-[#F4E5C8]/80 italic">"Explore. Experiment. Discover."</span>
        </div>
        <div className="flex items-center gap-6 text-[#D5DEEE]/80">
          <span>Interactive STEM Learning Platform</span>
          <span aria-hidden="true">·</span>
          <span>Standards Aligned Curriculum</span>
          <span aria-hidden="true">·</span>
          <span>© 2026 Virtual Science Lab</span>
        </div>
      </div>
    </footer>
  );
};
