import React from 'react';
import { ExperimentDef } from '../../types';
import { soundEngine } from '../../utils/audio';

interface ControlPanelProps {
  experiment: ExperimentDef;
  inputs: Record<string, number | string | boolean>;
  onChangeInput: (key: string, value: number) => void;
  onResetDefaults: () => void;
  onExecuteAndFinish: () => void;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
  experiment,
  inputs,
  onChangeInput,
  onResetDefaults,
  onExecuteAndFinish
}) => {
  return (
    <div className="bg-[#FBF4E8] rounded-2xl p-6 border border-[#080B4F]/15 shadow-sm space-y-6">
      <div className="flex items-center justify-between border-b border-[#080B4F]/10 pb-3">
        <div>
          <h4 className="font-serif-display font-semibold text-lg text-[#080B4F]">
            Experiment Parameters
          </h4>
          <p className="text-xs text-[#080B4F]/70">
            Adjust variables to simulate laboratory conditions in real time
          </p>
        </div>
        <button
          onClick={() => {
            soundEngine.click();
            onResetDefaults();
          }}
          className="text-xs text-[#080B4F]/80 hover:text-[#080B4F] underline font-medium"
        >
          Reset Defaults
        </button>
      </div>

      {/* Control Sliders */}
      <div className="space-y-5">
        {experiment.controls.map((ctrl) => {
          const val = Number(inputs[ctrl.id] ?? ctrl.defaultValue);

          return (
            <div key={ctrl.id} className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-[#080B4F]">{ctrl.label}</span>
                <span className="font-mono-data font-bold text-[#080B4F] bg-white px-2 py-0.5 rounded border border-[#080B4F]/15">
                  {val} {ctrl.unit}
                </span>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-[11px] text-[#080B4F]/60 font-mono-data w-8 text-right">
                  {ctrl.min}
                </span>
                <input
                  type="range"
                  min={ctrl.min}
                  max={ctrl.max}
                  step={ctrl.step}
                  value={val}
                  onChange={(e) => {
                    onChangeInput(ctrl.id, parseFloat(e.target.value));
                  }}
                  className="w-full h-2 bg-[#8194C6]/30 rounded-lg appearance-none cursor-pointer accent-[#080B4F]"
                />
                <span className="text-[11px] text-[#080B4F]/60 font-mono-data w-8">
                  {ctrl.max}
                </span>
              </div>

              <p className="text-[11px] text-[#080B4F]/65 italic">
                {ctrl.description}
              </p>
            </div>
          );
        })}
      </div>

      {/* Required Equipment checklist */}
      <div className="pt-2 border-t border-[#080B4F]/10">
        <div className="text-xs font-semibold text-[#080B4F] uppercase tracking-wider mb-2.5">
          Virtual Equipment in Circuit
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs">
          {experiment.equipment.map((eq, idx) => (
            <div
              key={idx}
              className="flex items-center gap-2 p-2 bg-white rounded-lg border border-[#080B4F]/10"
            >
              <span className="text-base">{eq.icon}</span>
              <div className="truncate">
                <div className="font-medium text-[#080B4F] truncate">{eq.name}</div>
                <div className="text-[10px] text-[#080B4F]/60 truncate">{eq.spec}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Main Action CTA */}
      <div className="pt-2">
        <button
          onClick={() => {
            soundEngine.successFanfare();
            onExecuteAndFinish();
          }}
          className="w-full py-3 px-4 rounded-xl font-semibold text-sm bg-[#080B4F] hover:bg-[#0e1363] text-[#F4E5C8] shadow-md transition-all flex items-center justify-center gap-2"
        >
          <span>📊</span>
          <span>Record Data & View Results</span>
        </button>
      </div>
    </div>
  );
};
