import { ExperimentDef, ExperimentResult, ChartDataPoint } from '../types';

export interface SimulationState {
  outputs: Record<string, number | string>;
  units: Record<string, string>;
  observation: string;
  learningResult: string;
  dynamicVisuals: Record<string, number | string | boolean | string[]>;
  chartData?: ChartDataPoint[];
  chartTitle?: string;
  chartXLabel?: string;
  chartYLabel?: string;
}

// =========================================================================
// REUSABLE SCIENTIFIC CALCULATION FUNCTIONS
// =========================================================================

export function calculateOhmsLaw(voltage: number, resistance: number) {
  const current = Number((voltage / resistance).toFixed(3));
  const power = Number((voltage * current).toFixed(2));
  return { current, power };
}

export function calculateProjectileMotion(v0: number, angleDeg: number, g: number) {
  const rad = (angleDeg * Math.PI) / 180;
  const flightTime = Number(((2 * v0 * Math.sin(rad)) / g).toFixed(2));
  const maxHeight = Number(((Math.pow(v0 * Math.sin(rad), 2)) / (2 * g)).toFixed(2));
  const range = Number(((Math.pow(v0, 2) * Math.sin(2 * rad)) / g).toFixed(2));

  // Generate trajectory points for chart
  const points: ChartDataPoint[] = [];
  const steps = 20;
  for (let i = 0; i <= steps; i++) {
    const t = (flightTime * i) / steps;
    const x = Number((v0 * Math.cos(rad) * t).toFixed(1));
    const y = Math.max(0, Number((v0 * Math.sin(rad) * t - 0.5 * g * t * t).toFixed(1)));
    points.push({ x, y, label: `${t.toFixed(1)}s` });
  }

  return { flightTime, maxHeight, range, points };
}

export function calculatePendulum(length: number, gravity: number) {
  const period = Number((2 * Math.PI * Math.sqrt(length / gravity)).toFixed(3));
  const frequency = Number((1 / period).toFixed(3));
  return { period, frequency };
}

export function calculateHookesLaw(k: number, force: number) {
  const extension = Number((force / k).toFixed(3)); // meters
  const extensionCm = Number((extension * 100).toFixed(1));
  const potentialEnergy = Number((0.5 * k * Math.pow(extension, 2)).toFixed(3));

  const points: ChartDataPoint[] = [];
  for (let f = 0; f <= force * 1.5; f += (force * 1.5) / 10) {
    const ext = (f / k) * 100;
    points.push({ x: Number(ext.toFixed(1)), y: Number(f.toFixed(1)), label: `${ext.toFixed(1)} cm` });
  }

  return { extension, extensionCm, potentialEnergy, points };
}

export function calculateDensity(mass: number, volume: number, fluidDensity: number) {
  const density = Number((mass / volume).toFixed(2));
  const buoyantForce = Number(((fluidDensity * volume * 9.81) / 1000).toFixed(3));
  const floats = density <= fluidDensity;
  return { density, buoyantForce, floats };
}

export function calculatePH(hydrogenConc: number) {
  const ph = Number((-Math.log10(hydrogenConc)).toFixed(2));
  const poh = Number((14 - ph).toFixed(2));
  return { ph, poh };
}

export function calculateDilution(m1: number, v1: number, v2: number) {
  const m2 = Number(((m1 * v1) / v2).toFixed(3));
  const moles = Number(((m1 * v1) / 1000).toFixed(4));
  return { m2, moles };
}

export function calculateReactionRate(molarity: number, surfaceFactor: number, tempC: number) {
  const tempFactor = Math.pow(1.07, tempC - 20);
  const rateIndex = Number((molarity * surfaceFactor * tempFactor * 1.5).toFixed(2));
  const gasVolume = Number(Math.min(100, rateIndex * 14).toFixed(1));
  return { rateIndex, gasVolume };
}

export function calculatePlantGrowth(light: number, water: number, temp: number) {
  const lightFactor = Math.min(1.0, light / 12);
  const waterFactor = Math.min(1.0, water / 60);
  const tempFactor = Math.max(0.1, 1 - Math.pow(Math.abs(temp - 24) / 15, 2));
  const dailyGrowthMm = Number((4.5 * Math.min(lightFactor, waterFactor) * tempFactor).toFixed(2));
  return { dailyGrowthMm, healthScore: Math.round(Math.min(lightFactor, waterFactor) * tempFactor * 100) };
}

export function calculateOsmosis(salinePct: number, isAnimal: boolean) {
  let volumePct = 100;
  let tonicity = 'Isotonic';
  if (salinePct < 0.6) {
    tonicity = 'Hypotonic';
    volumePct = isAnimal ? 140 : 105;
  } else if (salinePct > 1.2) {
    tonicity = 'Hypertonic';
    volumePct = Math.max(45, Math.round(100 - (salinePct - 0.9) * 16));
  }
  return { volumePct, tonicity };
}

export function calculatePopulationGrowth(r: number, k: number, n0: number) {
  const points: ChartDataPoint[] = [];
  const years = 15;
  let currentN = n0;
  for (let t = 0; t <= years; t++) {
    const n = Math.round(k / (1 + ((k - n0) / n0) * Math.exp(-r * t)));
    points.push({ x: `Yr ${t}`, y: n });
    if (t === years) currentN = n;
  }
  return { finalPopulation: currentN, points };
}

export function calculateSolarEnergy(irradiance: number, tiltDeg: number, efficiencyPct: number) {
  const rad = (tiltDeg * Math.PI) / 180;
  const powerW = Math.max(0, Math.round(1.6 * (efficiencyPct / 100) * irradiance * Math.cos(rad - 0.5)));
  const dailyKwh = Number(((powerW * 6.5) / 1000).toFixed(2));
  return { powerW, dailyKwh };
}

export function calculateWindEnergy(windSpeed: number, diameter: number, cp: number) {
  const radius = diameter / 2;
  const area = Math.PI * radius * radius;
  const rho = 1.225; // kg/m3 air
  const powerW = Math.max(0, Math.round(0.5 * rho * area * cp * Math.pow(windSpeed, 3)));
  return { powerW, sweptArea: Number(area.toFixed(2)) };
}

export function calculateCarbonFootprint(carMiles: number, homeKwh: number, dietIndex: number) {
  const carTons = (carMiles * 0.404) / 1000;
  const homeTons = (homeKwh * 12 * 0.386) / 1000;
  const dietTons = dietIndex === 0 ? 1.5 : dietIndex === 1 ? 2.5 : 3.3;
  const totalTons = Number((carTons + homeTons + dietTons).toFixed(2));
  return { totalTons, carTons: Number(carTons.toFixed(2)), homeTons: Number(homeTons.toFixed(2)), dietTons };
}

export function calculateSustainabilityScore(cleanTransit: number, renewableGrid: number, greenSpace: number) {
  const score = Math.round(cleanTransit * 0.35 + renewableGrid * 0.40 + (greenSpace / 50) * 100 * 0.25);
  return { score };
}

// =========================================================================
// MAIN SIMULATION DISPATCH ENGINE (SCALABLE TO ALL 60+ EXPERIMENTS)
// =========================================================================

export function computeSimulation(
  experiment: ExperimentDef,
  inputs: Record<string, number | string | boolean>
): SimulationState {
  switch (experiment.id) {
    // -------------------------------------------------------------
    // PHYSICS LAB (1–15)
    // -------------------------------------------------------------
    case 'ohm-law': {
      const v = Number(inputs.voltage || 10);
      const r = Number(inputs.resistance || 5);
      const { current, power } = calculateOhmsLaw(v, r);
      const filamentTemp = Math.round(20 + power * 45);
      const bulbBrightness = Math.min(100, Math.round((power / 60) * 100));

      const points: ChartDataPoint[] = [];
      for (let volt = 2; volt <= 24; volt += 2) {
        points.push({ x: `${volt}V`, y: Number((volt / r).toFixed(2)) });
      }

      return {
        outputs: { Current: current, Power: power, Resistance: r, 'Filament Temp': filamentTemp },
        units: { Current: 'A', Power: 'W', Resistance: 'Ω', 'Filament Temp': '°C' },
        observation: `With voltage at ${v}V and resistance at ${r}Ω, circuit current reaches ${current}A with ${power}W power dissipated across the bulb filament.`,
        learningResult: "Ohm's Law verified: Current scales linearly with voltage and inversely with resistance.",
        dynamicVisuals: { current, power, bulbBrightness, voltmeterAngle: Math.min(90, (v / 24) * 90 - 45), ammeterAngle: Math.min(90, (current / 10) * 90 - 45), electronSpeed: Math.max(0.4, Math.min(3.5, current * 0.7)) },
        chartData: points,
        chartTitle: 'Current vs Applied Voltage (Linear Ohmic Curve)',
        chartXLabel: 'Voltage (V)',
        chartYLabel: 'Current (A)'
      };
    }

    case 'series-circuit': {
      const v = Number(inputs.sourceVoltage || 12);
      const r1 = Number(inputs.resistor1 || 4);
      const r2 = Number(inputs.resistor2 || 6);
      const rTotal = r1 + r2;
      const current = Number((v / rTotal).toFixed(3));
      const v1 = Number((current * r1).toFixed(2));
      const v2 = Number((current * r2).toFixed(2));
      const pTotal = Number((v * current).toFixed(2));

      return {
        outputs: { 'Equivalent Resistance': rTotal, 'Loop Current': current, 'Voltage Drop R₁': v1, 'Voltage Drop R₂': v2, 'Total Power': pTotal },
        units: { 'Equivalent Resistance': 'Ω', 'Loop Current': 'A', 'Voltage Drop R₁': 'V', 'Voltage Drop R₂': 'V', 'Total Power': 'W' },
        observation: `Total resistance R_total = ${rTotal}Ω. Identical current ${current}A passes through both loads. Potential divides: ${v1}V on R₁ and ${v2}V on R₂.`,
        learningResult: "Kirchhoff's Voltage Law confirmed: Total voltage equals the sum of individual series voltage drops.",
        dynamicVisuals: { current, rTotal, bulb1Brightness: Math.min(100, Math.round(((v1 * current) / 40) * 100)), bulb2Brightness: Math.min(100, Math.round(((v2 * current) / 40) * 100)) }
      };
    }

    case 'parallel-circuit': {
      const v = Number(inputs.sourceVoltage || 12);
      const r1 = Number(inputs.resistor1 || 4);
      const r2 = Number(inputs.resistor2 || 6);
      const rEq = Number(((r1 * r2) / (r1 + r2)).toFixed(3));
      const i1 = Number((v / r1).toFixed(3));
      const i2 = Number((v / r2).toFixed(3));
      const iTotal = Number((i1 + i2).toFixed(3));

      return {
        outputs: { 'Equivalent Resistance': rEq, 'Branch 1 Current (I₁)': i1, 'Branch 2 Current (I₂)': i2, 'Total Current': iTotal },
        units: { 'Equivalent Resistance': 'Ω', 'Branch 1 Current (I₁)': 'A', 'Branch 2 Current (I₂)': 'A', 'Total Current': 'A' },
        observation: `Equivalent resistance drops to ${rEq}Ω. Full ${v}V is maintained across both branches, with current splitting into ${i1}A and ${i2}A.`,
        learningResult: "Parallel circuits maintain identical component voltage while lowering equivalent resistance.",
        dynamicVisuals: { iTotal, i1, i2, rEq, bulb1Brightness: Math.min(100, Math.round(((v * i1) / 50) * 100)), bulb2Brightness: Math.min(100, Math.round(((v * i2) / 50) * 100)) }
      };
    }

    case 'kirchhoff-laws': {
      const v1 = Number(inputs.sourceV1 || 12);
      const v2 = Number(inputs.sourceV2 || 6);
      const rc = Number(inputs.rCommon || 5);
      const iCommon = Number(((v1 + v2) / (rc + 4)).toFixed(3));
      const loopDeltaV = 0.0;

      return {
        outputs: { 'Junction Current': iCommon, 'Loop 1 Sum ΔV': loopDeltaV, 'Loop 2 Sum ΔV': loopDeltaV },
        units: { 'Junction Current': 'A', 'Loop 1 Sum ΔV': 'V', 'Loop 2 Sum ΔV': 'V' },
        observation: `Junction rule verified: Σ I_in = Σ I_out (${iCommon}A). Loop potential drops algebraically sum to 0.00V.`,
        learningResult: "Kirchhoff's Laws confirmed: Charge is conserved at nodes, and electrical energy is conserved in closed loops.",
        dynamicVisuals: { iCommon }
      };
    }

    case 'projectile-motion': {
      const v0 = Number(inputs.initialVelocity || 20);
      const angle = Number(inputs.launchAngle || 45);
      const g = Number(inputs.gravity || 9.8);
      const { flightTime, maxHeight, range, points } = calculateProjectileMotion(v0, angle, g);

      return {
        outputs: { 'Horizontal Range': range, 'Maximum Altitude': maxHeight, 'Flight Duration': flightTime },
        units: { 'Horizontal Range': 'm', 'Maximum Altitude': 'm', 'Flight Duration': 's' },
        observation: `Launched at ${v0} m/s and ${angle}°, the projectile achieves an altitude of ${maxHeight}m and impacts at ${range}m after ${flightTime}s of flight.`,
        learningResult: "2D Kinematics validated: Horizontal velocity is constant while gravity accelerates vertical motion symmetrically.",
        dynamicVisuals: { range, maxHeight, flightTime },
        chartData: points,
        chartTitle: 'Parabolic Ballistic Trajectory (Altitude vs Range)',
        chartXLabel: 'Horizontal Distance (m)',
        chartYLabel: 'Vertical Altitude (m)'
      };
    }

    case 'newton-second-law': {
      const f = Number(inputs.appliedForce || 3.0);
      const m = Number(inputs.cartMass || 0.8);
      const acc = Number((f / m).toFixed(3));
      const vTerminal = Number((acc * 2.0).toFixed(2)); // after 2s

      return {
        outputs: { Acceleration: acc, 'Final Speed (2s)': vTerminal, 'Momentum (2s)': Number((m * vTerminal).toFixed(2)) },
        units: { Acceleration: 'm/s²', 'Final Speed (2s)': 'm/s', 'Momentum (2s)': 'kg·m/s' },
        observation: `A net force of ${f}N accelerating a ${m}kg mass yields an acceleration of ${acc} m/s².`,
        learningResult: "Newton's Second Law confirmed: Acceleration is proportional to force and inversely proportional to mass.",
        dynamicVisuals: { acc, f, m }
      };
    }

    case 'friction': {
      const mass = Number(inputs.normalMass || 2.0);
      const surfaceType = Number(inputs.surfaceType || 0);
      const g = 9.81;
      const normalForce = Number((mass * g).toFixed(2));
      const coeffs = surfaceType === 0 ? { s: 0.40, k: 0.30 } : surfaceType === 1 ? { s: 0.80, k: 0.65 } : { s: 0.10, k: 0.05 };
      const staticMax = Number((coeffs.s * normalForce).toFixed(2));
      const kineticDrag = Number((coeffs.k * normalForce).toFixed(2));

      return {
        outputs: { 'Normal Force (N)': normalForce, 'Max Static Friction': staticMax, 'Kinetic Friction': kineticDrag },
        units: { 'Normal Force (N)': 'N', 'Max Static Friction': 'N', 'Kinetic Friction': 'N' },
        observation: `With normal load ${normalForce}N, breakaway static friction threshold is ${staticMax}N, dropping to ${kineticDrag}N once sliding initiates.`,
        learningResult: "Amontons' laws of friction verified: Static friction threshold exceeds kinetic sliding resistance.",
        dynamicVisuals: { normalForce, staticMax, kineticDrag }
      };
    }

    case 'simple-pendulum': {
      const len = Number(inputs.pendulumLength || 1.0);
      const g = Number(inputs.localGravity || 9.8);
      const { period, frequency } = calculatePendulum(len, g);

      return {
        outputs: { Period: period, Frequency: frequency, 'Pendulum Length': len },
        units: { Period: 's', Frequency: 'Hz', 'Pendulum Length': 'm' },
        observation: `A ${len}m pendulum oscillating in gravity ${g} m/s² completes a full cycle in ${period}s (frequency: ${frequency} Hz).`,
        learningResult: "Isochronism confirmed: Period depends on string length and gravity, completely independent of bob mass.",
        dynamicVisuals: { period, frequency, len }
      };
    }

    case 'hookes-law': {
      const k = Number(inputs.springConstant || 50);
      const force = Number(inputs.appliedForce || 5.0);
      const { extensionCm, potentialEnergy, points } = calculateHookesLaw(k, force);

      return {
        outputs: { 'Extension (Δx)': extensionCm, 'Stored Elastic Energy': potentialEnergy, 'Spring Constant (k)': k },
        units: { 'Extension (Δx)': 'cm', 'Stored Elastic Energy': 'J', 'Spring Constant (k)': 'N/m' },
        observation: `Under a tensile load of ${force}N, the k = ${k} N/m spring stretches ${extensionCm}cm, storing ${potentialEnergy}J of strain energy.`,
        learningResult: "Hooke's Law confirmed: Restoring force is directly proportional to displacement within elastic limits.",
        dynamicVisuals: { extensionCm, potentialEnergy, k },
        chartData: points,
        chartTitle: "Force vs Extension Hookean Slope",
        chartXLabel: 'Extension (cm)',
        chartYLabel: 'Applied Force (N)'
      };
    }

    case 'conservation-energy': {
      const h0 = Number(inputs.initialHeight || 2.5);
      const m = Number(inputs.cartMass || 0.5);
      const g = 9.81;
      const initialPE = Number((m * g * h0).toFixed(2));
      const vBottom = Number(Math.sqrt(2 * g * h0).toFixed(2));
      const finalKE = initialPE;

      return {
        outputs: { 'Initial Potential Energy': initialPE, 'Maximum Velocity': vBottom, 'Final Kinetic Energy': finalKE },
        units: { 'Initial Potential Energy': 'J', 'Maximum Velocity': 'm/s', 'Final Kinetic Energy': 'J' },
        observation: `Released from ${h0}m, all ${initialPE}J of potential energy converts into kinetic energy at bottom velocity ${vBottom} m/s.`,
        learningResult: "Conservation of mechanical energy verified: Total energy PE + KE remains constant throughout frictionless descent.",
        dynamicVisuals: { initialPE, vBottom, finalKE }
      };
    }

    case 'free-fall': {
      const h = Number(inputs.dropHeight || 5);
      const inAir = Number(inputs.airDensity || 0) === 1;
      const g = 9.81;
      const tVac = Number(Math.sqrt((2 * h) / g).toFixed(3));
      const vVac = Number((g * tVac).toFixed(2));
      const tFinal = inAir ? Number((tVac * 1.15).toFixed(3)) : tVac;
      const vFinal = inAir ? Number((vVac * 0.90).toFixed(2)) : vVac;

      return {
        outputs: { 'Descent Time': tFinal, 'Impact Speed': vFinal, 'Air Drag': inAir ? 'Atmosphere' : 'Vacuum' },
        units: { 'Descent Time': 's', 'Impact Speed': 'm/s', 'Air Drag': '' },
        observation: `Falling through ${h}m ${inAir ? 'with air drag' : 'in vacuum'}, object impacts at ${vFinal} m/s in ${tFinal} seconds.`,
        learningResult: "Galileo's equivalence principle confirmed in vacuum: Acceleration g is identical for all bodies.",
        dynamicVisuals: { tFinal, vFinal }
      };
    }

    case 'density-measurement': {
      const m = Number(inputs.specimenMass || 200);
      const v = Number(inputs.specimenVolume || 50);
      const fluidRho = Number(inputs.fluidDensity || 1.0);
      const { density, buoyantForce, floats } = calculateDensity(m, v, fluidRho);

      return {
        outputs: { 'Calculated Density': density, 'Buoyant Force': buoyantForce, 'Floating State': floats ? 'Floats on surface' : 'Sinks to bottom' },
        units: { 'Calculated Density': 'g/cm³', 'Buoyant Force': 'N', 'Floating State': '' },
        observation: `Specimen density is ${density} g/cm³. Relative to fluid (${fluidRho} g/cm³), buoyant uplift is ${buoyantForce}N (${floats ? 'Floats' : 'Sinks'}).`,
        learningResult: "Archimedes' principle verified: Buoyant force equals the weight of displaced fluid.",
        dynamicVisuals: { density, buoyantForce, floats }
      };
    }

    case 'refraction-light': {
      const theta1 = Number(inputs.incidentAngle || 40);
      const n2 = Number(inputs.mediumIndex || 1.5);
      const n1 = 1.0; // air
      const sinTheta2 = (n1 * Math.sin((theta1 * Math.PI) / 180)) / n2;
      const theta2 = Number(((Math.asin(Math.min(1.0, sinTheta2)) * 180) / Math.PI).toFixed(1));
      const critAngle = Number(((Math.asin(1.0 / n2) * 180) / Math.PI).toFixed(1));

      return {
        outputs: { 'Refraction Angle (θ₂)': theta2, 'Critical Angle (θ_c)': critAngle, 'Index of Medium (n₂)': n2 },
        units: { 'Refraction Angle (θ₂)': '°', 'Critical Angle (θ_c)': '°', 'Index of Medium (n₂)': '' },
        observation: `Light striking interface at ${theta1}° bends to ${theta2}° in the denser medium. Critical angle for total internal reflection is ${critAngle}°.`,
        learningResult: "Snell's Law verified: Light bends toward the normal when entering an optically denser medium.",
        dynamicVisuals: { theta1, theta2, critAngle }
      };
    }

    case 'lens-focal-length': {
      const f = Number(inputs.focalLength || 10);
      const doVal = Number(inputs.objectDistance || 25);
      const diVal = Number(((f * doVal) / (doVal - f)).toFixed(2));
      const mag = Number((-diVal / doVal).toFixed(2));

      return {
        outputs: { 'Image Distance (d_i)': diVal, Magnification: `${mag}x`, 'Image Nature': diVal > 0 ? 'Real & Inverted' : 'Virtual & Upright' },
        units: { 'Image Distance (d_i)': 'cm', Magnification: '', 'Image Nature': '' },
        observation: `With object at ${doVal}cm and focal length ${f}cm, real image forms at ${diVal}cm with magnification ${mag}x.`,
        learningResult: "Thin Lens equation confirmed: 1/f = 1/d_o + 1/d_i accurately predicts conjugate focal points.",
        dynamicVisuals: { diVal, mag, f }
      };
    }

    case 'wave-motion': {
      const freq = Number(inputs.waveFrequency || 40);
      const tension = Number(inputs.stringTension || 4);
      const length = Number(inputs.stringLength || 1.5);
      const mu = 0.002; // kg/m
      const waveSpeed = Number(Math.sqrt(tension / mu).toFixed(1));
      const wavelength = Number((waveSpeed / freq).toFixed(3));
      const harmonics = Math.round((2 * length) / wavelength);

      return {
        outputs: { 'Wave Velocity (v)': waveSpeed, Wavelength: wavelength, 'Resonant Harmonics': harmonics },
        units: { 'Wave Velocity (v)': 'm/s', Wavelength: 'm', 'Resonant Harmonics': 'nodes' },
        observation: `At ${freq} Hz and ${tension}N tension, transverse waves propagate at ${waveSpeed} m/s (wavelength: ${wavelength}m, resonant nodes: ${harmonics}).`,
        learningResult: "Fundamental wave relationship verified: Wave speed v = f λ and v = √(T / μ).",
        dynamicVisuals: { waveSpeed, wavelength, harmonics }
      };
    }

    // -------------------------------------------------------------
    // CHEMISTRY LAB (16–30)
    // -------------------------------------------------------------
    case 'acids-bases': {
      const type = Number(inputs.substanceType || 0);
      const conc = Number(inputs.solutionMolarity || 0.1);
      const names = ['Hydrochloric Acid (HCl)', 'Acetic Acid (CH₃COOH)', 'Sodium Hydroxide (NaOH)', 'Ammonia (NH₃)'];
      const phVal = type === 0 ? Number((-Math.log10(conc)).toFixed(2)) : type === 1 ? Number((2.87 - 0.5 * Math.log10(conc / 0.1)).toFixed(2)) : type === 2 ? Number((14 + Math.log10(conc)).toFixed(2)) : 11.1;

      return {
        outputs: { Substance: names[type], 'Solution pH': phVal, Ionization: type === 0 || type === 2 ? '100% (Strong)' : '~1.3% (Weak)' },
        units: { Substance: '', 'Solution pH': '', Ionization: '' },
        observation: `${names[type]} at ${conc}M yields a solution pH of ${phVal}.`,
        learningResult: "Electrolyte strength confirmed: Strong acids/bases dissociate completely, while weak counterparts establish equilibrium.",
        dynamicVisuals: { phVal }
      };
    }

    case 'ph-measurement': {
      const idx = Number(inputs.liquidSelection || 0);
      const dilution = Number(inputs.waterDilution || 1);
      const liquids = [
        { name: 'Lemon Juice', base: 2.2, color: '#EF4444' },
        { name: 'Vinegar', base: 2.8, color: '#F97316' },
        { name: 'Black Coffee', base: 5.0, color: '#EAB308' },
        { name: 'Pure Water', base: 7.0, color: '#10B981' },
        { name: 'Baking Soda', base: 8.4, color: '#06B6D4' },
        { name: 'Ammonia', base: 11.2, color: '#3B82F6' },
        { name: 'Bleach', base: 12.6, color: '#8B5CF6' }
      ];
      const sel = liquids[idx];
      let ph = sel.base;
      if (ph < 7) ph = Math.min(6.9, ph + Math.log10(dilution) * 0.85);
      else if (ph > 7) ph = Math.max(7.1, ph - Math.log10(dilution) * 0.85);
      const rounded = Number(ph.toFixed(2));

      return {
        outputs: { 'Analyte Tested': sel.name, 'Calibrated pH': rounded, '[H⁺] Hydronium': Math.pow(10, -rounded).toExponential(2) },
        units: { 'Analyte Tested': '', 'Calibrated pH': '', '[H⁺] Hydronium': 'mol/L' },
        observation: `${sel.name} exhibits a measured pH of ${rounded} ([H⁺] = ${Math.pow(10, -rounded).toExponential(2)} M).`,
        learningResult: "pH logarithmic scale confirmed: Each whole unit represents a 10-fold shift in hydrogen ion concentration.",
        dynamicVisuals: { ph: rounded, color: sel.color }
      };
    }

    case 'neutralization': {
      const vAcid = Number(inputs.acidVolume || 25);
      const mAcid = Number(inputs.acidMolarity || 0.1);
      const vBase = Number(inputs.baseAdded || 25);
      const molesAcid = (vAcid * mAcid) / 1000;
      const molesBase = (vBase * 0.1) / 1000;
      const eqVol = Number(((molesAcid / 0.1) * 1000).toFixed(1));
      let ph = 7.0;
      if (molesAcid > molesBase) ph = Math.max(1.0, -Math.log10((molesAcid - molesBase) / ((vAcid + vBase) / 1000)));
      else if (molesBase > molesAcid) ph = Math.min(13.5, 14.0 + Math.log10((molesBase - molesAcid) / ((vAcid + vBase) / 1000)));
      const rounded = Number(ph.toFixed(2));

      // Titration curve points
      const points: ChartDataPoint[] = [];
      for (let vb = 0; vb <= 50; vb += 5) {
        let p = 7.0;
        const mb = (vb * 0.1) / 1000;
        if (molesAcid > mb) p = Math.max(1.0, -Math.log10((molesAcid - mb) / ((vAcid + vb) / 1000)));
        else if (mb > molesAcid) p = Math.min(13.5, 14.0 + Math.log10((mb - molesAcid) / ((vAcid + vb) / 1000)));
        points.push({ x: `${vb}mL`, y: Number(p.toFixed(2)) });
      }

      return {
        outputs: { 'Solution pH': rounded, 'Equivalence Volume': eqVol, 'Indicator Color': rounded >= 8.2 ? 'Pink (End Point)' : 'Colorless' },
        units: { 'Solution pH': '', 'Equivalence Volume': 'mL', 'Indicator Color': '' },
        observation: `Dispensing ${vBase}mL of base into ${vAcid}mL of acid produces pH ${rounded}. Target equivalence is ${eqVol}mL.`,
        learningResult: "Stoichiometric neutralization completed: H⁺ + OH⁻ → H₂O.",
        dynamicVisuals: { ph: rounded, isPink: rounded >= 8.2 },
        chartData: points,
        chartTitle: 'Sigmoidal Titration Curve (pH vs NaOH Volume)',
        chartXLabel: 'Base Added (mL)',
        chartYLabel: 'Solution pH'
      };
    }

    case 'concentration-dilution': {
      const m1 = Number(inputs.initialMolarity || 1.0);
      const v1 = Number(inputs.initialVolume || 20);
      const v2 = Number(inputs.finalVolume || 100);
      const { m2, moles } = calculateDilution(m1, v1, v2);

      return {
        outputs: { 'Diluted Concentration (M₂)': m2, 'Solute Moles': moles, 'Dilution Factor': `${Number((v2 / v1).toFixed(1))}x` },
        units: { 'Diluted Concentration (M₂)': 'M', 'Solute Moles': 'mol', 'Dilution Factor': '' },
        observation: `Diluting ${v1}mL of ${m1}M stock up to ${v2}mL yields a final concentration of ${m2}M while conserving ${moles} moles of solute.`,
        learningResult: "M₁V₁ = M₂V₂ confirmed: Solvent expansion decreases concentration while preserving solute quantity.",
        dynamicVisuals: { m2 }
      };
    }

    case 'solubility': {
      const temp = Number(inputs.temperature || 30);
      const solute = Number(inputs.soluteAdded || 45);
      const maxSat = Number((14 + 0.45 * temp).toFixed(1));
      const dissolved = Math.min(solute, maxSat);
      const precipitate = Math.max(0, Number((solute - dissolved).toFixed(1)));

      return {
        outputs: { 'Max Solubility': maxSat, 'Dissolved Mass': dissolved, 'Precipitate Mass': precipitate },
        units: { 'Max Solubility': 'g / 100mL', 'Dissolved Mass': 'g', 'Precipitate Mass': 'g' },
        observation: `At ${temp}°C, saturation capacity is ${maxSat}g/100mL. Adding ${solute}g yields ${dissolved}g dissolved and ${precipitate}g precipitate.`,
        learningResult: "Thermal solubility confirmed: Endothermic dissolution shifts equilibrium toward dissolved solute as temperature rises.",
        dynamicVisuals: { dissolved, precipitate }
      };
    }

    case 'reaction-rate': {
      const surfaceType = Number(inputs.surfaceType || 2);
      const conc = Number(inputs.acidMolarity || 1.5);
      const surfaceFactor = surfaceType === 1 ? 0.6 : surfaceType === 2 ? 1.0 : 2.0;
      const { rateIndex, gasVolume } = calculateReactionRate(conc, surfaceFactor, 25);

      return {
        outputs: { 'Reaction Rate Index': rateIndex, 'CO₂ Gas Produced': gasVolume, 'Time to 50mL': Number((50 / (rateIndex * 0.4)).toFixed(1)) },
        units: { 'Reaction Rate Index': 'rel. u.', 'CO₂ Gas Produced': 'mL in 30s', 'Time to 50mL': 's' },
        observation: `Reacting with particle size mode ${surfaceType} generates ${gasVolume}mL of gas in 30s at rate index ${rateIndex}.`,
        learningResult: "Collision theory confirmed: Greater surface contact area multiplies effective particle collisions per second.",
        dynamicVisuals: { rateIndex, gasVolume }
      };
    }

    case 'temp-reaction-rate': {
      const temp = Number(inputs.reactionTemp || 25);
      const ea = Number(inputs.activationEnergy || 50);
      const rConstant = 8.314;
      const tempK = temp + 273.15;
      const kRate = Number((Math.exp(- (ea * 1000) / (rConstant * tempK)) * 1e8).toFixed(2));
      const timeSec = Number(Math.max(5, (300 / kRate)).toFixed(1));

      return {
        outputs: { 'Rate Constant (k)': kRate, 'Reaction Time': timeSec, 'Temp (K)': tempK },
        units: { 'Rate Constant (k)': 'rel. u.', 'Reaction Time': 's', 'Temp (K)': 'K' },
        observation: `Elevating temperature to ${temp}°C (${tempK}K) increases rate constant k to ${kRate}, completing the reaction in ${timeSec} seconds.`,
        learningResult: "Arrhenius equation confirmed: Temperature exponentially multiplies the fraction of collisions exceeding activation energy.",
        dynamicVisuals: { kRate, timeSec }
      };
    }

    case 'liquid-density': {
      const layers = Number(inputs.liquidLayerCount || 4);
      const beadRho = Number(inputs.testBeadDensity || 0.95);
      const layerNames = ['Honey (1.42)', 'Dish Soap (1.06)', 'Water (1.00)', 'Vegetable Oil (0.92)', 'Ethanol (0.79)'];
      const activeLayers = layerNames.slice(0, layers);

      return {
        outputs: { 'Active Layers': layers, 'Indicator Bead Density': beadRho, 'Equilibrium Position': beadRho > 1.0 ? 'Below Water' : 'Above Water' },
        units: { 'Active Layers': 'fluids', 'Indicator Bead Density': 'g/cm³', 'Equilibrium Position': '' },
        observation: `${layers} immiscible fluids form stable hydrostatic stratification. Indicator bead (${beadRho} g/cm³) settles at its neutral density zone.`,
        learningResult: "Density stratification verified: Immiscible fluids arrange in strict descending order of volumetric density.",
        dynamicVisuals: { layers, beadRho, activeLayers }
      };
    }

    case 'separation-mixtures': {
      const distSolv = Number(inputs.solventFrontDist || 10);
      const polarity = Number(inputs.solventPolarity || 1);
      const rfValues = polarity === 0 ? [0.35, 0.60] : polarity === 1 ? [0.45, 0.75] : [0.55, 0.88];
      const pigment1Dist = Number((rfValues[0] * distSolv).toFixed(1));
      const pigment2Dist = Number((rfValues[1] * distSolv).toFixed(1));

      return {
        outputs: { 'Pigment A Rf': rfValues[0], 'Pigment B Rf': rfValues[1], 'Solvent Front': distSolv },
        units: { 'Pigment A Rf': '', 'Pigment B Rf': '', 'Solvent Front': 'cm' },
        observation: `Solvent front traveled ${distSolv}cm. Pigment A migrated ${pigment1Dist}cm (Rf = ${rfValues[0]}) and Pigment B reached ${pigment2Dist}cm (Rf = ${rfValues[1]}).`,
        learningResult: "Paper chromatography validated: Components separate based on differential partition affinity between stationary and mobile phases.",
        dynamicVisuals: { distSolv, pigment1Dist, pigment2Dist }
      };
    }

    case 'chemical-equilibrium': {
      const temp = Number(inputs.temperatureEq || 25);
      const cl = Number(inputs.chlorideConc || 2.0);
      const blueFraction = Math.min(100, Math.round((temp / 80) * 60 + (cl / 5) * 40));

      return {
        outputs: { 'Equilibrium Position': blueFraction > 50 ? 'Shifted Right (Blue)' : 'Shifted Left (Pink)', 'Blue Complex %': blueFraction, 'Pink Complex %': 100 - blueFraction },
        units: { 'Equilibrium Position': '', 'Blue Complex %': '%', 'Pink Complex %': '%' },
        observation: `At ${temp}°C and [Cl⁻] = ${cl}M, the reversible cobalt complex shifts to ${blueFraction}% blue [CoCl₄]²⁻.`,
        learningResult: "Le Chatelier's Principle confirmed: Adding heat shifts endothermic reaction forward; adding reactant shifts forward.",
        dynamicVisuals: { blueFraction }
      };
    }

    case 'indicators': {
      const chosen = Number(inputs.chosenIndicator || 1);
      const ph = Number(inputs.targetSolutionPh || 7.0);
      const names = ['Methyl Orange', 'Bromothymol Blue', 'Phenolphthalein'];
      let color = 'Green';
      if (chosen === 0) color = ph < 3.1 ? 'Red' : ph > 4.4 ? 'Yellow' : 'Orange';
      else if (chosen === 1) color = ph < 6.0 ? 'Yellow' : ph > 7.6 ? 'Blue' : 'Green';
      else color = ph < 8.2 ? 'Colorless' : 'Vibrant Pink';

      return {
        outputs: { Indicator: names[chosen], 'Observed Color': color, 'Solution pH': ph },
        units: { Indicator: '', 'Observed Color': '', 'Solution pH': '' },
        observation: `${names[chosen]} in solution at pH ${ph} displays a distinctive ${color} optical hue.`,
        learningResult: "Indicator halochromism confirmed: Chromophores alter electronic orbital transitions upon protonation/deprotonation.",
        dynamicVisuals: { color, ph }
      };
    }

    case 'gas-formation': {
      const mass = Number(inputs.carbonateMass || 0.25);
      const temp = Number(inputs.ambientTemp || 25);
      const moles = mass / 84.0; // NaHCO3
      const rGas = 0.08206;
      const volL = (moles * rGas * (temp + 273.15)) / 1.0;
      const volMl = Number((volL * 1000).toFixed(1));

      return {
        outputs: { 'CO₂ Gas Evolved': volMl, 'Reactant Moles': Number(moles.toFixed(4)), 'Molar Volume': Number(((volL / moles)).toFixed(2)) },
        units: { 'CO₂ Gas Evolved': 'mL', 'Reactant Moles': 'mol', 'Molar Volume': 'L/mol' },
        observation: `Reacting ${mass}g NaHCO₃ at ${temp}°C evolves ${volMl}mL of gaseous CO₂ (stoichiometric mole yield: ${moles.toFixed(4)} mol).`,
        learningResult: "Ideal Gas Law PV = nRT verified: 1 mole of gas occupies predictable molar volume at given temperature and pressure.",
        dynamicVisuals: { volMl }
      };
    }

    case 'conservation-mass': {
      const isClosed = Number(inputs.systemType || 0) === 0;
      const initMass = Number(inputs.reagentMassTotal || 100);
      const finalMass = isClosed ? initMass : Number((initMass - 1.25).toFixed(2));

      return {
        outputs: { 'Initial Mass': initMass, 'Post-Reaction Mass': finalMass, 'Delta Mass': Number((finalMass - initMass).toFixed(2)) },
        units: { 'Initial Mass': 'g', 'Post-Reaction Mass': 'g', 'Delta Mass': 'g' },
        observation: `In a ${isClosed ? 'sealed closed flask' : 'vented open beaker'}, mass changed by ${Number((finalMass - initMass).toFixed(2))}g (${isClosed ? 'Exact conservation' : 'CO₂ gas escaped into room'}).`,
        learningResult: "Law of Conservation of Mass confirmed: In closed systems, total mass is exactly invariant across chemical transformations.",
        dynamicVisuals: { isClosed, initMass, finalMass }
      };
    }

    case 'crystallization': {
      const coolProg = Number(inputs.coolingRate || 0);
      const initTemp = Number(inputs.initialSaturationTemp || 70);
      const crystalSize = coolProg === 0 ? 'Large Rhombic Prisms (>10mm)' : coolProg === 1 ? 'Medium Granules (3–5mm)' : 'Fine Micro-Needles (<1mm)';
      const crystalPurity = coolProg === 0 ? '99.5% (High Purity)' : coolProg === 1 ? '96.0%' : '88.0% (Inclusions trapped)';

      return {
        outputs: { 'Crystal Morphology': crystalSize, 'Estimated Purity': crystalPurity, 'Starting Saturation': `${initTemp}°C` },
        units: { 'Crystal Morphology': '', 'Estimated Purity': '', 'Starting Saturation': '' },
        observation: `Cooling program ${coolProg} produced ${crystalSize} with ${crystalPurity} crystalline perfection.`,
        learningResult: "Crystallization kinetics confirmed: Slow cooling promotes controlled crystal lattice propagation over uncontrolled nucleation.",
        dynamicVisuals: { coolProg }
      };
    }

    case 'solution-conductivity': {
      const sample = Number(inputs.solutionSample || 2);
      const conc = Number(inputs.saltConcentration || 15);
      const names = ['Pure Water', 'Sucrose Solution', 'Vinegar (Acetic Acid)', 'Table Salt (NaCl)', 'Hydrochloric Acid (HCl)'];
      const cond = sample === 0 ? 0.05 : sample === 1 ? 0.1 : sample === 2 ? 450 : sample === 3 ? conc * 1200 : conc * 3500;
      const bulbLit = cond > 100;

      return {
        outputs: { Solution: names[sample], 'Conductivity (κ)': Math.round(cond), 'Bulb State': bulbLit ? 'Brilliantly Glowing' : 'Unlit / Off' },
        units: { Solution: '', 'Conductivity (κ)': 'μS/cm', 'Bulb State': '' },
        observation: `${names[sample]} exhibits ${Math.round(cond)} μS/cm electrical conductivity (${bulbLit ? 'Conducts electricity' : 'Non-conductive'}).`,
        learningResult: "Ionic conduction verified: Mobile dissociated ions are required to conduct electric current in aqueous media.",
        dynamicVisuals: { cond, bulbLit }
      };
    }

    // -------------------------------------------------------------
    // BIOLOGY LAB (31–45)
    // -------------------------------------------------------------
    case 'plant-growth': {
      const water = Number(inputs.waterLevel || 50);
      const light = Number(inputs.lightHours || 14);
      const temp = Number(inputs.tempBio || 24);
      const { dailyGrowthMm, healthScore } = calculatePlantGrowth(light, water, temp);

      const points: ChartDataPoint[] = [];
      let cumulativeHeight = 10;
      for (let day = 1; day <= 10; day++) {
        cumulativeHeight += dailyGrowthMm;
        points.push({ x: `Day ${day}`, y: Number(cumulativeHeight.toFixed(1)) });
      }

      return {
        outputs: { 'Daily Elongation': dailyGrowthMm, 'Vegetative Health': `${healthScore}%`, '10-Day Projected Height': Number((cumulativeHeight).toFixed(1)) },
        units: { 'Daily Elongation': 'mm / day', 'Vegetative Health': '', '10-Day Projected Height': 'mm' },
        observation: `Under ${light}h light, ${water}mL water, and ${temp}°C, the plant grows ${dailyGrowthMm} mm/day (${healthScore}% vitality score).`,
        learningResult: "Liebig's Law of the Minimum confirmed: Vegetative growth is constrained by the scarcest environmental input.",
        dynamicVisuals: { dailyGrowthMm, healthScore },
        chartData: points,
        chartTitle: 'Cumulative Vegetative Growth Over 10 Days',
        chartXLabel: 'Growth Day',
        chartYLabel: 'Plant Stem Height (mm)'
      };
    }

    case 'photosynthesis': {
      const light = Number(inputs.lightIntensity || 100);
      const co2 = Number(inputs.co2Level || 500);
      const rate = Math.round(Math.min(75, (light / 150) * 60 * Math.min(1.0, co2 / 600)));

      return {
        outputs: { 'Oxygen Bubble Rate': rate, 'Photosynthetic Index': Math.round((rate / 75) * 100), 'Primary Limiting Factor': light < 80 ? 'Light Intensity' : 'CO₂ Concentration' },
        units: { 'Oxygen Bubble Rate': 'bubbles/min', 'Photosynthetic Index': '%', 'Primary Limiting Factor': '' },
        observation: `At ${light} W/m² and ${co2} ppm CO₂, the Elodea sprig releases ${rate} oxygen bubbles/min.`,
        learningResult: "Photosynthesis validated: Photolysis rate scales with light and carbon availability until enzyme saturation.",
        dynamicVisuals: { rate }
      };
    }

    case 'osmosis': {
      const isAnimal = Number(inputs.cellModel || 0) === 1;
      const saline = Number(inputs.salineConc || 0.9);
      const { volumePct, tonicity } = calculateOsmosis(saline, isAnimal);

      return {
        outputs: { 'Tonicity State': tonicity, 'Cytoplasm Volume': volumePct, 'Cell State': isAnimal ? (saline < 0.6 ? 'Lysis (Burst)' : saline > 1.2 ? 'Crenated' : 'Normal') : (saline > 1.2 ? 'Plasmolyzed' : 'Turgid') },
        units: { 'Tonicity State': '', 'Cytoplasm Volume': '% of baseline', 'Cell State': '' },
        observation: `In ${saline}% NaCl (${tonicity}), cell volume shifted to ${volumePct}%. ${isAnimal ? 'Animal membrane responded' : 'Plant cell wall maintained structural envelope'}.`,
        learningResult: "Water potential osmosis confirmed: Water flows down water potential gradients across semi-permeable membranes.",
        dynamicVisuals: { volumePct, tonicity, isAnimal }
      };
    }

    case 'diffusion': {
      const mw = Number(inputs.molecularWeight || 158);
      const temp = Number(inputs.gelTemperature || 25);
      const t = Number(inputs.diffusionTime || 30);
      const haloDiameter = Number((Math.sqrt(t) * (temp / 20) * (300 / mw) * 1.8).toFixed(1));

      return {
        outputs: { 'Diffusion Halo Diameter': haloDiameter, 'Diffusion Velocity': Number((haloDiameter / t).toFixed(2)), 'Molecular Mass': mw },
        units: { 'Diffusion Halo Diameter': 'mm', 'Diffusion Velocity': 'mm/min', 'Molecular Mass': 'g/mol' },
        observation: `After ${t} minutes at ${temp}°C, the ${mw} g/mol dye diffused to form a ${haloDiameter}mm radial ring.`,
        learningResult: "Graham's & Fick's laws verified: Lighter molecules and higher temperatures diffuse at maximum velocity.",
        dynamicVisuals: { haloDiameter }
      };
    }

    case 'cell-observation': {
      const choice = Number(inputs.specimenChoice || 0);
      const mag = Number(inputs.magnificationPower || 400);
      const specimens = ['Allium Cepa (Onion Skin)', 'Human Buccal (Cheek)', 'Elodea Densa (Leaf)'];
      const fieldDiameter = mag === 100 ? 1.8 : mag === 400 ? 0.45 : 0.18;

      return {
        outputs: { Specimen: specimens[choice], Magnification: `${mag}x`, 'Field of View': fieldDiameter },
        units: { Specimen: '', Magnification: '', 'Field of View': 'mm' },
        observation: `${specimens[choice]} under ${mag}x ocular resolution displays clear cellular boundaries across a ${fieldDiameter}mm field of view.`,
        learningResult: "Cell Theory confirmed: Plant cells exhibit rigid cellulose walls and chloroplasts absent in animal cells.",
        dynamicVisuals: { choice, mag }
      };
    }

    case 'mendelian-genetics': {
      const p1 = Number(inputs.parent1Genotype || 1);
      const p2 = Number(inputs.parent2Genotype || 1);
      const count = Number(inputs.sampleSize || 200);
      const p1Alleles = p1 === 0 ? ['P', 'P'] : p1 === 1 ? ['P', 'p'] : ['p', 'p'];
      const p2Alleles = p2 === 0 ? ['P', 'P'] : p2 === 1 ? ['P', 'p'] : ['p', 'p'];
      const combinations = [
        p1Alleles[0] + p2Alleles[0],
        p1Alleles[0] + p2Alleles[1],
        p1Alleles[1] + p2Alleles[0],
        p1Alleles[1] + p2Alleles[1]
      ].map((g) => (g === 'pP' ? 'Pp' : g));
      let purpleFrac = combinations.filter((c) => c.includes('P')).length / 4;
      const purpleCount = Math.round(count * purpleFrac);
      const whiteCount = count - purpleCount;

      return {
        outputs: { 'Purple Offspring (Dominant)': purpleCount, 'White Offspring (Recessive)': whiteCount, 'Phenotype Ratio': `${Math.round(purpleFrac * 4)} Purple : ${Math.round((1 - purpleFrac) * 4)} White` },
        units: { 'Purple Offspring (Dominant)': 'plants', 'White Offspring (Recessive)': 'plants', 'Phenotype Ratio': '' },
        observation: `Monohybrid cross (${p1Alleles.join('')} × ${p2Alleles.join('')}) across ${count} progeny yielded ${purpleCount} purple and ${whiteCount} white individuals.`,
        learningResult: "Mendel's Law of Segregation verified: Alleles segregate into gametes, yielding characteristic 3:1 phenotype ratios.",
        dynamicVisuals: { purpleCount, whiteCount, combinations }
      };
    }

    case 'enzyme-activity': {
      const temp = Number(inputs.tempEnzyme || 37);
      const ph = Number(inputs.phEnzyme || 7.0);
      const sub = Number(inputs.substrateConc || 3.0);
      const tempFactor = temp > 55 ? Math.max(0, 1 - (temp - 55) * 0.08) : Math.min(1.0, temp / 37);
      const phFactor = Math.max(0.1, 1 - Math.abs(ph - 7.0) * 0.25);
      const activity = Math.round(tempFactor * phFactor * (sub / 4) * 100);

      return {
        outputs: { 'Enzyme Activity Index': activity, 'Optimum State': temp === 37 && ph === 7.0 ? 'Optimal Activity' : temp > 55 ? 'Thermal Denaturation' : 'Sub-optimal', 'O₂ Gas Evolution': `${Math.round(activity * 0.8)} mL/min` },
        units: { 'Enzyme Activity Index': '%', 'Optimum State': '', 'O₂ Gas Evolution': '' },
        observation: `At ${temp}°C and pH ${ph}, catalase activity is ${activity}% of maximum physiological catalytic velocity.`,
        learningResult: "Enzyme kinetics confirmed: Catalase functions optimally at 37°C and pH 7.0; excessive heat triggers protein denaturation.",
        dynamicVisuals: { activity, temp, ph }
      };
    }

    case 'transpiration': {
      const wind = Number(inputs.windSpeed || 1.0);
      const hum = Number(inputs.relativeHumidity || 50);
      const leaves = Number(inputs.leafCount || 15);
      const waterLossMlHr = Number(((leaves * 0.25 * (1 + wind * 0.5) * (1 - hum / 120))).toFixed(2));

      return {
        outputs: { 'Transpiration Rate': waterLossMlHr, 'Stomatal Conductance': Math.round(100 - hum * 0.6), 'Active Leaves': leaves },
        units: { 'Transpiration Rate': 'mL / hour', 'Stomatal Conductance': '%', 'Active Leaves': '' },
        observation: `With ${leaves} leaves exposed to ${wind} m/s wind and ${hum}% humidity, water uptake through potometer is ${waterLossMlHr} mL/hr.`,
        learningResult: "Cohesion-Tension theory confirmed: Transpiration pull accelerates under dry, windy atmospheric conditions.",
        dynamicVisuals: { waterLossMlHr }
      };
    }

    case 'cellular-respiration': {
      const isGerm = Number(inputs.seedState || 1) === 1;
      const temp = Number(inputs.respirationTemp || 25);
      const mass = Number(inputs.seedMass || 25);
      const o2Rate = isGerm ? Number(((mass * 0.08 * (temp / 20))).toFixed(2)) : Number(((mass * 0.005)).toFixed(3));

      return {
        outputs: { 'O₂ Consumption Rate': o2Rate, 'Respiratory State': isGerm ? 'Active Germination' : 'Dormant', 'KOH Absorbed CO₂': `${o2Rate} mL/hr` },
        units: { 'O₂ Consumption Rate': 'mL O₂ / hour', 'Respiratory State': '', 'KOH Absorbed CO₂': '' },
        observation: `${mass}g of ${isGerm ? 'germinating' : 'dormant'} seeds consume ${o2Rate} mL of oxygen per hour at ${temp}°C.`,
        learningResult: "Aerobic cellular respiration validated: Active cellular mitosis and metabolism consumes oxygen to produce ATP.",
        dynamicVisuals: { o2Rate, isGerm }
      };
    }

    case 'food-testing': {
      const sample = Number(inputs.foodSample || 0);
      const test = Number(inputs.reagentTest || 0);
      const foods = ['White Bread', 'Cow Milk', 'Egg White Albumin', 'Vegetable Oil', 'Pure Glucose Solution'];
      const tests = ["Iodine (Starch)", "Benedict's (Reducing Sugars)", "Biuret (Proteins)", "Sudan III (Lipids)"];
      const resultsMatrix = [
        ['Blue-Black (Positive)', 'Negative (Blue)', 'Negative', 'Negative'], // Bread
        ['Negative', 'Orange Precipitate (Positive)', 'Violet (Positive)', 'Light Red (Positive)'], // Milk
        ['Negative', 'Negative', 'Deep Violet (Positive)', 'Negative'], // Egg
        ['Negative', 'Negative', 'Negative', 'Intense Red Layer (Positive)'], // Oil
        ['Negative', 'Brick Red (Strong Positive)', 'Negative', 'Negative'] // Glucose
      ];
      const outcome = resultsMatrix[sample][test];

      return {
        outputs: { 'Food Matrix': foods[sample], 'Reagent Assay': tests[test], 'Biochemical Verdict': outcome },
        units: { 'Food Matrix': '', 'Reagent Assay': '', 'Biochemical Verdict': '' },
        observation: `Testing ${foods[sample]} with ${tests[test]} produced verdict: "${outcome}".`,
        learningResult: "Macromolecule assays validated: Biochemical reagents selectively confirm the presence of dietary nutrients.",
        dynamicVisuals: { outcome }
      };
    }

    case 'ecosystem-simulation': {
      const prodE = Number(inputs.producerEnergy || 10000);
      const eff = Number(inputs.trophicEfficiency || 10) / 100;
      const herbE = Math.round(prodE * eff);
      const carnE = Math.round(herbE * eff);
      const apexE = Math.round(carnE * eff);

      const points: ChartDataPoint[] = [
        { x: 'Producers', y: prodE },
        { x: 'Herbivores', y: herbE },
        { x: 'Carnivores', y: carnE },
        { x: 'Apex Predators', y: apexE }
      ];

      return {
        outputs: { 'Primary Producers': prodE, 'Primary Consumers (Herbivores)': herbE, 'Secondary Consumers': carnE, 'Apex Predators': apexE },
        units: { 'Primary Producers': 'kJ', 'Primary Consumers (Herbivores)': 'kJ', 'Secondary Consumers': 'kJ', 'Apex Predators': 'kJ' },
        observation: `With ${prodE} kJ of plant energy and ${eff * 100}% transfer efficiency, the ecosystem supports ${herbE} kJ of herbivores and ${apexE} kJ of apex predators.`,
        learningResult: "Lindeman's 10% rule confirmed: Trophic energetic losses limit the length of ecological food chains.",
        dynamicVisuals: { prodE, herbE, carnE, apexE },
        chartData: points,
        chartTitle: 'Trophic Biomass & Energy Pyramid (kJ)',
        chartXLabel: 'Trophic Level',
        chartYLabel: 'Energy Available (kJ)'
      };
    }

    case 'natural-selection': {
      const soot = Number(inputs.treePollutionLevel || 70);
      const gens = Number(inputs.generations || 5);
      const darkSurvival = Math.min(95, Math.round(20 + soot * 0.75));
      const lightSurvival = Math.max(5, Math.round(95 - soot * 0.80));
      const darkFreqFinal = Math.min(98, Math.round(15 + (soot / 100) * 80 * (gens / 5)));

      return {
        outputs: { 'Dark Morph Survival': `${darkSurvival}%`, 'Light Morph Survival': `${lightSurvival}%`, 'Final Dark Phenotype %': `${darkFreqFinal}%` },
        units: { 'Dark Morph Survival': '', 'Light Morph Survival': '', 'Final Dark Phenotype %': '' },
        observation: `On ${soot}% soot-darkened bark across ${gens} generations, dark moth representation shifted to ${darkFreqFinal}%.`,
        learningResult: "Natural selection demonstrated: Environmental shifts alter differential survival, driving rapid evolutionary adaptation.",
        dynamicVisuals: { darkFreqFinal, darkSurvival, lightSurvival }
      };
    }

    case 'population-growth': {
      const r = Number(inputs.growthRate || 0.4);
      const k = Number(inputs.carryingCapacity || 1000);
      const n0 = Number(inputs.initialPop || 50);
      const { finalPopulation, points } = calculatePopulationGrowth(r, k, n0);

      return {
        outputs: { 'Carrying Capacity (K)': k, '15-Year Population': finalPopulation, 'Growth Rate (r)': r },
        units: { 'Carrying Capacity (K)': 'individuals', '15-Year Population': 'individuals', 'Growth Rate (r)': '' },
        observation: `Population grew logistically from ${n0} to stabilize at ${finalPopulation} individuals near carrying capacity ${k}.`,
        learningResult: "Logistic growth model verified: Density-dependent environmental resistance halts exponential expansion at carrying capacity K.",
        dynamicVisuals: { finalPopulation, k },
        chartData: points,
        chartTitle: 'Logistic Sigmoid S-Curve Population Trajectory',
        chartXLabel: 'Time (Years)',
        chartYLabel: 'Population Size (N)'
      };
    }

    case 'microorganism-growth': {
      const gMin = Number(inputs.generationTimeMin || 20);
      const hours = Number(inputs.cultureTimeHours || 8);
      const doublings = Math.round((hours * 60) / gMin);
      const finalCountSci = Math.min(1e9, 1000 * Math.pow(2, Math.min(25, doublings)));

      return {
        outputs: { 'Binary Doublings': doublings, 'Estimated Bacteria Count': finalCountSci.toExponential(2), 'Doubling Time': `${gMin} min` },
        units: { 'Binary Doublings': 'cycles', 'Estimated Bacteria Count': 'cells / mL', 'Doubling Time': '' },
        observation: `In ${hours} hours with ${gMin} min doubling intervals, bacterial population grew through ${doublings} binary fission cycles to reach ${finalCountSci.toExponential(2)} cells/mL.`,
        learningResult: "Microbial exponential kinetics confirmed: Bacterial colonies experience exponential log phase growth before nutrient depletion.",
        dynamicVisuals: { doublings }
      };
    }

    case 'human-body-systems': {
      const watts = Number(inputs.workloadWatts || 100);
      const hr = Math.round(60 + (watts / 300) * 115);
      const sv = Math.round(75 + (watts / 300) * 35); // mL
      const cardiacOutputLMin = Number(((hr * sv) / 1000).toFixed(1));
      const vo2 = Number((0.25 + (watts / 300) * 2.8).toFixed(2));

      return {
        outputs: { 'Heart Rate': hr, 'Stroke Volume': sv, 'Cardiac Output (Q)': cardiacOutputLMin, 'Oxygen Uptake (VO₂)': vo2 },
        units: { 'Heart Rate': 'bpm', 'Stroke Volume': 'mL / beat', 'Cardiac Output (Q)': 'L / min', 'Oxygen Uptake (VO₂)': 'L / min' },
        observation: `At ${watts}W workload, heart rate is ${hr} bpm and stroke volume is ${sv} mL, delivering ${cardiacOutputLMin} L/min of cardiac output.`,
        learningResult: "Cardiovascular hemodynamics verified: Cardiac output Q = HR × SV scales to satisfy elevated skeletal muscle oxygen requirements.",
        dynamicVisuals: { hr, sv, cardiacOutputLMin }
      };
    }

    // -------------------------------------------------------------
    // ENVIRONMENTAL SCIENCE (46–60)
    // -------------------------------------------------------------
    case 'water-quality': {
      const doVal = Number(inputs.dissolvedOxygen || 8.5);
      const turb = Number(inputs.turbidity || 12);
      const nit = Number(inputs.nitrates || 2.0);
      const ph = Number(inputs.waterPh || 7.2);
      const qDO = Math.min(100, Math.max(10, doVal * 11));
      const qTurb = Math.max(10, 100 - turb * 1.1);
      const qNit = Math.max(15, 100 - nit * 5.2);
      const qPh = Math.max(10, 100 - Math.abs(ph - 7.4) * 28);
      const wqi = Math.round(qDO * 0.35 + qTurb * 0.25 + qNit * 0.2 + qPh * 0.2);

      return {
        outputs: { 'Water Quality Index': wqi, 'Ecological Health': wqi >= 80 ? 'Excellent' : wqi >= 65 ? 'Good' : 'Degraded', 'DO Saturation': Math.round(qDO) },
        units: { 'Water Quality Index': '/100', 'Ecological Health': '', 'DO Saturation': '/100' },
        observation: `Multi-parameter testing yields a Water Quality Index of ${wqi}/100. Dissolved oxygen is ${doVal} mg/L and turbidity is ${turb} NTU.`,
        learningResult: "Water quality indexing validated: Combined physical and chemical parameters diagnose aquatic ecosystem health.",
        dynamicVisuals: { wqi }
      };
    }

    case 'water-pollution': {
      const phos = Number(inputs.phosphateLoad || 0.08);
      const bod = Number((phos * 85).toFixed(1));
      const bottomDO = Math.max(0.5, Number((9.0 - bod * 0.8).toFixed(1)));
      const isHypoxic = bottomDO < 2.0;

      return {
        outputs: { 'Biological Oxygen Demand': bod, 'Bottom Dissolved Oxygen': bottomDO, 'Hypoxic State': isHypoxic ? 'Hypoxic Dead Zone (<2 mg/L)' : 'Oxygenated' },
        units: { 'Biological Oxygen Demand': 'mg/L', 'Bottom Dissolved Oxygen': 'mg/L', 'Hypoxic State': '' },
        observation: `Phosphate loading of ${phos} mg/L creates ${bod} mg/L of BOD, driving bottom DO to ${bottomDO} mg/L (${isHypoxic ? 'Dead Zone' : 'Adequate'}).`,
        learningResult: "Eutrophication mechanisms confirmed: Phosphorus enrichment triggers decomposition blooms that exhaust dissolved oxygen.",
        dynamicVisuals: { bod, bottomDO, isHypoxic }
      };
    }

    case 'air-quality': {
      const pm25 = Number(inputs.pm25Level || 22);
      const o3 = Number(inputs.ozonePpb || 45);
      const aqiPm = Math.round((pm25 / 35.4) * 100);
      const aqi = Math.max(aqiPm, Math.round((o3 / 70) * 100));
      const category = aqi <= 50 ? 'Good' : aqi <= 100 ? 'Moderate' : aqi <= 150 ? 'Unhealthy for Sensitive Groups' : 'Unhealthy';

      return {
        outputs: { 'Air Quality Index (AQI)': aqi, 'Air Quality Category': category, 'PM2.5 Level': pm25 },
        units: { 'Air Quality Index (AQI)': 'pts', 'Air Quality Category': '', 'PM2.5 Level': 'μg/m³' },
        observation: `With PM2.5 at ${pm25} μg/m³ and ozone at ${o3} ppb, the calculated Air Quality Index is ${aqi} (${category}).`,
        learningResult: "AQI multi-pollutant scoring confirmed: Fine particulate concentration dictates health risk advisories.",
        dynamicVisuals: { aqi, category }
      };
    }

    case 'carbon-footprint': {
      const car = Number(inputs.carMiles || 8000);
      const kwh = Number(inputs.homeKwh || 650);
      const diet = Number(inputs.dietChoice || 1);
      const { totalTons, carTons, homeTons, dietTons } = calculateCarbonFootprint(car, kwh, diet);

      const points: ChartDataPoint[] = [
        { x: 'Transport', y: carTons },
        { x: 'Home Grid', y: homeTons },
        { x: 'Diet', y: dietTons }
      ];

      return {
        outputs: { 'Annual Carbon Footprint': totalTons, 'Transportation Emissions': carTons, 'Home Electricity': homeTons },
        units: { 'Annual Carbon Footprint': 't CO₂e / yr', 'Transportation Emissions': 't CO₂e / yr', 'Home Electricity': 't CO₂e / yr' },
        observation: `Total annual greenhouse gas footprint is ${totalTons} metric tons CO₂e (${carTons}t car, ${homeTons}t home, ${dietTons}t diet).`,
        learningResult: "Carbon accounting confirmed: Individual vehicle travel and residential energy are the largest personal levers for climate mitigation.",
        dynamicVisuals: { totalTons },
        chartData: points,
        chartTitle: 'Personal Carbon Emissions Breakdown by Sector',
        chartXLabel: 'Emission Sector',
        chartYLabel: 'Metric Tons CO₂e'
      };
    }

    case 'renewable-energy': {
      const solarCap = Number(inputs.solarCapacity || 40);
      const windCap = Number(inputs.windCapacity || 20);
      const batt = Number(inputs.batteryStorage || 80);
      const dailyGenKwh = Math.round(solarCap * 4.5 + windCap * 7.0);
      const cleanFraction = Math.min(100, Math.round((dailyGenKwh / (dailyGenKwh + 50)) * 100));

      return {
        outputs: { 'Daily Clean Generation': dailyGenKwh, 'Microgrid Clean Energy %': `${cleanFraction}%`, 'Storage Capacity': batt },
        units: { 'Daily Clean Generation': 'kWh / day', 'Microgrid Clean Energy %': '', 'Storage Capacity': 'kWh' },
        observation: `Microgrid installation generated ${dailyGenKwh} kWh/day with ${batt} kWh storage, achieving ${cleanFraction}% clean renewable power share.`,
        learningResult: "Renewable energy integration confirmed: Pairing solar, wind, and storage smooths temporal intermittency.",
        dynamicVisuals: { dailyGenKwh, cleanFraction }
      };
    }

    case 'solar-energy': {
      const irr = Number(inputs.solarIrradiance || 800);
      const tilt = Number(inputs.panelTiltAngle || 30);
      const eff = Number(inputs.panelEfficiency || 20);
      const { powerW, dailyKwh } = calculateSolarEnergy(irr, tilt, eff);

      return {
        outputs: { 'Photovoltaic Output': powerW, 'Daily Energy Generated': dailyKwh, 'Aperture Area': '1.6 m²' },
        units: { 'Photovoltaic Output': 'Watts', 'Daily Energy Generated': 'kWh', 'Aperture Area': '' },
        observation: `Under ${irr} W/m² irradiance at ${tilt}° tilt, the ${eff}% efficient panel produces ${powerW}W (${dailyKwh} kWh daily).`,
        learningResult: "Photovoltaic power generation confirmed: Perpendicular panel orientation maximizes energy capture.",
        dynamicVisuals: { powerW, dailyKwh }
      };
    }

    case 'wind-energy': {
      const v = Number(inputs.windVelocity || 8.0);
      const diam = Number(inputs.rotorDiameter || 2.5);
      const cp = Number(inputs.powerCoeff || 0.40);
      const { powerW, sweptArea } = calculateWindEnergy(v, diam, cp);

      const points: ChartDataPoint[] = [];
      for (let speed = 2; speed <= 16; speed += 2) {
        points.push({ x: `${speed}m/s`, y: calculateWindEnergy(speed, diam, cp).powerW });
      }

      return {
        outputs: { 'Turbine Electric Power': powerW, 'Rotor Swept Area': sweptArea, 'Betz Fraction': `${Math.round(cp * 100)}%` },
        units: { 'Turbine Electric Power': 'Watts', 'Rotor Swept Area': 'm²', 'Betz Fraction': '' },
        observation: `At wind speed ${v} m/s with a ${diam}m rotor, the turbine generates ${powerW}W of clean electric power.`,
        learningResult: "Cubic wind power law validated: Power output scales with wind speed cubed (P ∝ v³).",
        dynamicVisuals: { powerW, sweptArea },
        chartData: points,
        chartTitle: 'Cubic Wind Power Curve (P ∝ v³)',
        chartXLabel: 'Wind Speed (m/s)',
        chartYLabel: 'Generated Power (Watts)'
      };
    }

    case 'forest-ecosystem': {
      const ha = Number(inputs.forestHectares || 100);
      const age = Number(inputs.standAgeYears || 45);
      const density = Number(inputs.treeDensityHa || 450);
      const totalTrees = ha * density;
      const annualCO2Tons = Math.round((totalTrees * Math.min(28, 5 + age * 0.35)) / 1000);

      return {
        outputs: { 'Annual CO₂ Sequestration': annualCO2Tons, 'Total Trees Conserved': totalTrees, 'Cars Offset': Math.round(annualCO2Tons / 4.6) },
        units: { 'Annual CO₂ Sequestration': 't CO₂ / yr', 'Total Trees Conserved': 'trees', 'Cars Offset': 'vehicles / yr' },
        observation: `Conserving ${ha} hectares of ${age}-year-old forest (${totalTrees.toLocaleString()} trees) actively sequesters ${annualCO2Tons.toLocaleString()} tons of CO₂ per year.`,
        learningResult: "Terrestrial forest carbon sinks verified: Photosynthetic biomass accumulation permanently captures atmospheric carbon.",
        dynamicVisuals: { annualCO2Tons, totalTrees }
      };
    }

    case 'recycling': {
      const al = Number(inputs.aluminumRecovered || 100);
      const plastic = Number(inputs.plasticRecovered || 200);
      const paper = Number(inputs.paperRecovered || 500);
      const energySavedKwh = Math.round(al * 14.0 + plastic * 5.8 + paper * 4.0);
      const co2AvoidedKg = Math.round(energySavedKwh * 0.82);

      return {
        outputs: { 'Energy Conserved': energySavedKwh, 'GHG Emissions Avoided': co2AvoidedKg, 'Landfill Volume Saved': `${Number((plastic * 0.003 + paper * 0.002).toFixed(2))} m³` },
        units: { 'Energy Conserved': 'kWh', 'GHG Emissions Avoided': 'kg CO₂', 'Landfill Volume Saved': '' },
        observation: `Recycling ${al}kg aluminum, ${plastic}kg plastic, and ${paper}kg paper conserves ${energySavedKwh} kWh and avoids ${co2AvoidedKg} kg CO₂.`,
        learningResult: "Closed-loop circular recycling confirmed: Secondary remelting uses 95% less energy than primary virgin extraction.",
        dynamicVisuals: { energySavedKwh, co2AvoidedKg }
      };
    }

    case 'climate-simulation': {
      const albedo = Number(inputs.planetaryAlbedo || 0.30);
      const em = Number(inputs.greenhouseEmissivity || 0.62);
      const s0 = 1361; // W/m2
      const sigma = 5.67e-8;
      const tKelvin = Math.pow(((1 - albedo) * s0) / (4 * em * sigma), 0.25);
      const tCelsius = Number((tKelvin - 273.15).toFixed(2));

      return {
        outputs: { 'Equilibrium Temperature': `${tCelsius}°C`, 'Surface Albedo (α)': albedo, 'Solar Absorbed Flux': Math.round(((1 - albedo) * s0) / 4) },
        units: { 'Equilibrium Temperature': '', 'Surface Albedo (α)': '', 'Solar Absorbed Flux': 'W/m²' },
        observation: `With surface albedo α = ${albedo} and emissivity ε = ${em}, planetary equilibrium temperature stabilizes at ${tCelsius}°C.`,
        learningResult: "Ice-albedo feedback validated: Melting reflective polar ice lowers global albedo, amplifying planetary heat absorption.",
        dynamicVisuals: { tCelsius, albedo }
      };
    }

    case 'greenhouse-effect': {
      const co2 = Number(inputs.co2Concentration || 420);
      const lambda = Number(inputs.climateSensitivity || 0.8);
      const forcing = Number((5.35 * Math.log(co2 / 280)).toFixed(2));
      const deltaT = Number((forcing * lambda).toFixed(2));

      const points: ChartDataPoint[] = [];
      for (let c = 280; c <= 700; c += 40) {
        points.push({ x: `${c}ppm`, y: Number(((5.35 * Math.log(c / 280)) * lambda).toFixed(2)) });
      }

      return {
        outputs: { 'Radiative Forcing (ΔF)': forcing, 'Temperature Anomaly (ΔT)': `+${deltaT}°C`, 'Atmospheric CO₂': co2 },
        units: { 'Radiative Forcing (ΔF)': 'W/m²', 'Temperature Anomaly (ΔT)': '', 'Atmospheric CO₂': 'ppm' },
        observation: `At ${co2} ppm CO₂ (baseline 280 ppm), radiative forcing is +${forcing} W/m², producing a global temperature anomaly of +${deltaT}°C.`,
        learningResult: "Logarithmic radiative forcing verified: Polyatomic greenhouse gas molecules trap outgoing thermal infrared radiation.",
        dynamicVisuals: { forcing, deltaT },
        chartData: points,
        chartTitle: 'Global Temperature Anomaly vs Atmospheric CO₂',
        chartXLabel: 'CO₂ Concentration (ppm)',
        chartYLabel: 'Temperature Rise (°C)'
      };
    }

    case 'ocean-pollution': {
      const plasticKg = Number(inputs.initialPlasticKg || 50);
      const years = Number(inputs.uvExposureYears || 5);
      const microparticleCount = Math.round(plasticKg * 250 * Math.pow(years, 1.4));

      return {
        outputs: { 'Microplastics Density': microparticleCount.toLocaleString(), 'Weathering Elapsed': `${years} years`, 'Marine Ingestion Risk': years > 4 ? 'Severe High Risk' : 'Moderate' },
        units: { 'Microplastics Density': 'particles / km²', 'Weathering Elapsed': '', 'Marine Ingestion Risk': '' },
        observation: `Over ${years} years of marine UV and wave weathering, ${plasticKg} kg/km² of macro-plastic sheared into ${microparticleCount.toLocaleString()} microplastic fragments.`,
        learningResult: "Plastic persistence confirmed: Polymers fragment into billions of microparticles that bioaccumulate in marine food chains.",
        dynamicVisuals: { microparticleCount }
      };
    }

    case 'biodiversity': {
      const s = Number(inputs.speciesRichness || 8);
      const evenness = Number(inputs.evennessFactor || 2);
      const p = 1 / s;
      const maxH = Math.log(s);
      const shannonH = Number(((evenness === 1 ? maxH * 0.5 : evenness === 2 ? maxH * 0.85 : maxH)).toFixed(2));
      const evennessJ = Number((shannonH / maxH).toFixed(2));

      return {
        outputs: { "Shannon Diversity Index (H')": shannonH, 'Pielou Evenness (J)': evennessJ, 'Species Richness (S)': s },
        units: { "Shannon Diversity Index (H')": 'nats', 'Pielou Evenness (J)': '', 'Species Richness (S)': 'species' },
        observation: `Quadrat survey with ${s} species yields a Shannon-Wiener Index of H' = ${shannonH} and evenness J = ${evennessJ}.`,
        learningResult: "Biodiversity indexing confirmed: High species richness and balanced evenness maximize ecosystem resilience.",
        dynamicVisuals: { shannonH, evennessJ }
      };
    }

    case 'sustainable-city': {
      const transit = Number(inputs.cleanTransitPct || 50);
      const grid = Number(inputs.renewableGridPct || 60);
      const green = Number(inputs.greenSpacePct || 25);
      const { score } = calculateSustainabilityScore(transit, grid, green);

      const points: ChartDataPoint[] = [
        { x: 'Clean Transit', y: transit },
        { x: 'Renewable Grid', y: grid },
        { x: 'Green Space', y: Math.round((green / 50) * 100) },
        { x: 'Overall Score', y: score }
      ];

      return {
        outputs: { 'Sustainability Score': score, 'Metropolitan Eco-Rating': score >= 80 ? 'Platinum Eco-City' : score >= 60 ? 'Gold Sustainable' : 'Developing', 'Clean Energy Grid': `${grid}%` },
        units: { 'Sustainability Score': '/100', 'Metropolitan Eco-Rating': '', 'Clean Energy Grid': '' },
        observation: `City configuration scores ${score}/100 with ${transit}% clean transit, ${grid}% clean energy, and ${green}% green canopy.`,
        learningResult: "Urban sustainability verified: Integrated green infrastructure transforms cities into low-carbon circular ecosystems.",
        dynamicVisuals: { score },
        chartData: points,
        chartTitle: 'Municipal Sustainability Performance Indicators',
        chartXLabel: 'Urban Sector',
        chartYLabel: 'Score (% of Target)'
      };
    }

    case 'waste-management': {
      const wasteTons = Number(inputs.monthlyWasteTons || 800);
      const divPct = Number(inputs.diversionRatePct || 40);
      const divertedTons = Math.round((wasteTons * divPct) / 100);
      const methaneAvoidedTons = Math.round(divertedTons * 0.48);

      return {
        outputs: { 'Waste Diverted': divertedTons, 'Avoided Methane (CO₂e)': methaneAvoidedTons, 'Diversion Rate': `${divPct}%` },
        units: { 'Waste Diverted': 'tons / mo', 'Avoided Methane (CO₂e)': 't CO₂e / mo', 'Diversion Rate': '' },
        observation: `Diverting ${divPct}% (${divertedTons} tons) of waste prevents ${methaneAvoidedTons} metric tons of atmospheric methane equivalents per month.`,
        learningResult: "Organic waste diversion verified: Composting eliminates anaerobic landfill methane emissions.",
        dynamicVisuals: { divertedTons, methaneAvoidedTons }
      };
    }

    default: {
      return {
        outputs: { Status: 'Completed', Parameters: Object.keys(inputs).length },
        units: { Status: '', Parameters: '' },
        observation: 'The experiment parameters were successfully processed.',
        learningResult: 'Experimental variables analyzed.',
        dynamicVisuals: {}
      };
    }
  }
}

export function buildExperimentResultRecord(
  experiment: ExperimentDef,
  inputs: Record<string, number | string | boolean>,
  simulation: SimulationState
): ExperimentResult {
  const now = new Date();
  const dateFormatted = now.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });

  return {
    id: `res_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    experimentId: experiment.id,
    experimentTitle: experiment.title,
    category: experiment.category,
    difficulty: experiment.difficulty,
    completedAt: now.toISOString(),
    dateFormatted,
    xpEarned: experiment.xpReward,
    inputs,
    calculatedOutputs: simulation.outputs,
    outputUnits: simulation.units,
    observation: simulation.observation,
    conclusion: experiment.conclusionTemplate || simulation.learningResult,
    learningResult: simulation.learningResult,
    scientificPrinciple: experiment.scientificPrinciple,
    formula: experiment.formula,
    chartData: simulation.chartData,
    chartTitle: simulation.chartTitle,
    chartXLabel: simulation.chartXLabel,
    chartYLabel: simulation.chartYLabel,
    accuracyScore: 100
  };
}
