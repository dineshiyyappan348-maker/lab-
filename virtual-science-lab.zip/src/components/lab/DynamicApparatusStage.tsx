import React from 'react';
import { ExperimentDef } from '../../types';
import { SimulationState } from '../../utils/simulationEngine';

interface StageProps {
  experiment: ExperimentDef;
  inputs: Record<string, number | string | boolean>;
  simulation: SimulationState;
  isRunning: boolean;
}

export const DynamicApparatusStage: React.FC<StageProps> = ({
  experiment,
  inputs,
  simulation,
  isRunning
}) => {
  const simId = experiment.simulationType || experiment.id;
  const outputs = simulation.outputs;

  // 1. CONDUCTIVITY OF SOLUTIONS
  if (simId === 'solution-conductivity') {
    const soluteChoice = Number(inputs.solutionSample ?? 2);
    const conc = Number(inputs.saltConcentration ?? 15);
    const isStrong = soluteChoice === 3 || soluteChoice === 4;
    const isWeak = soluteChoice === 2;
    const isNone = soluteChoice === 0 || soluteChoice === 1;

    const bulbGlow = isStrong
      ? Math.min(100, 30 + conc * 1.5)
      : isWeak
      ? Math.min(35, 10 + conc * 0.4)
      : 0;

    return (
      <div className="w-full bg-[#030526] p-4 rounded-xl border border-[#8194C6]/30 flex flex-col items-center justify-center gap-4">
        <div className="relative w-64 h-48 border-b-4 border-slate-600 flex flex-col items-center justify-end">
          {/* Light bulb assembly above beaker */}
          <div className="absolute top-2 flex flex-col items-center">
            <div
              className={`w-12 h-12 rounded-full border-2 transition-all duration-300 flex items-center justify-center ${
                bulbGlow > 0
                  ? 'bg-amber-300 border-amber-200 shadow-[0_0_35px_rgba(252,211,77,0.9)]'
                  : 'bg-slate-800 border-slate-600'
              }`}
            >
              <span className="text-xs font-mono font-bold text-slate-900">
                {bulbGlow > 0 ? '💡' : '○'}
              </span>
            </div>
            <div className="w-1.5 h-6 bg-slate-500" />
          </div>

          {/* Dual Electrodes */}
          <div className="absolute bottom-6 flex justify-center gap-10">
            <div className="w-2.5 h-24 bg-slate-400 rounded-b shadow" title="Platinum Anode (+)" />
            <div className="w-2.5 h-24 bg-slate-400 rounded-b shadow" title="Platinum Cathode (-)" />
          </div>

          {/* Glass Beaker with solution */}
          <div className="w-48 h-32 border-2 border-t-0 border-[#8194C6]/60 rounded-b-2xl bg-cyan-950/40 relative overflow-hidden flex flex-col justify-end">
            <div
              className="w-full bg-cyan-600/30 transition-all duration-500 relative flex items-center justify-center"
              style={{ height: '75%' }}
            >
              {isRunning && bulbGlow > 0 && (
                <div className="absolute inset-0 flex justify-around items-center opacity-70">
                  <span className="text-[10px] animate-bounce text-cyan-200">Na⁺ ➔</span>
                  <span className="text-[10px] animate-bounce text-amber-200">Cl⁻ ➔</span>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="text-center font-mono-data text-xs space-y-0.5">
          <div className="text-[#F4E5C8] font-bold">
            Solution: {outputs['Tested Sample'] || 'Electrolyte Solution'}
          </div>
          <div className="text-[#C9A95C]">
            Conductivity: {outputs['Ionic Conductivity'] || '0'} μS/cm · Bulb: {bulbGlow > 0 ? `${Math.round(bulbGlow)}% Brightness` : 'Dark (Non-Conductive)'}
          </div>
        </div>
      </div>
    );
  }

  // 2. LIQUID DENSITY STRATIFICATION
  if (simId === 'liquid-density') {
    const layers = Number(inputs.liquidLayerCount ?? 4);
    const beadRho = Number(inputs.testBeadDensity ?? 0.95);

    const layerPalette = [
      { name: 'Honey (1.42 g/cm³)', color: '#b45309' },
      { name: 'Dish Soap (1.06 g/cm³)', color: '#047857' },
      { name: 'Water (1.00 g/cm³)', color: '#0284c7' },
      { name: 'Vegetable Oil (0.92 g/cm³)', color: '#eab308' },
      { name: 'Ethanol (0.79 g/cm³)', color: '#7c3aed' }
    ];

    const activeLayers = layerPalette.slice(0, layers).reverse();

    return (
      <div className="w-full bg-[#030526] p-4 rounded-xl border border-[#8194C6]/30 flex flex-col sm:flex-row items-center justify-center gap-6">
        {/* Graduated Cylinder */}
        <div className="relative w-24 h-56 border-2 border-t-0 border-[#8194C6]/60 rounded-b-xl bg-[#080B4F]/60 overflow-hidden flex flex-col justify-end p-0.5">
          {activeLayers.map((l, i) => (
            <div
              key={i}
              className="w-full transition-all duration-300 relative flex items-center justify-center text-[9px] font-mono text-white/80 font-bold"
              style={{
                backgroundColor: l.color,
                height: `${100 / layers}%`,
                opacity: 0.85
              }}
            >
              {/* Density bead resting in middle */}
              {i === Math.floor(layers / 2) && (
                <div
                  className="w-4 h-4 rounded-full bg-red-500 border-2 border-white shadow-lg flex items-center justify-center text-[7px] text-white"
                  title={`Bead: ${beadRho} g/cm³`}
                >
                  ●
                </div>
              )}
            </div>
          ))}

          {/* Tick marks on graduated cylinder */}
          <div className="absolute right-1 inset-y-2 flex flex-col justify-between text-[8px] font-mono text-white/50 pointer-events-none">
            <span>100</span>
            <span>75</span>
            <span>50</span>
            <span>25</span>
          </div>
        </div>

        <div className="space-y-2 text-xs font-mono-data">
          <div className="text-[#C9A95C] font-bold text-sm">Density Column Stratification</div>
          <div className="text-slate-300">
            Active Layers: <strong className="text-[#F4E5C8]">{layers} immiscible fluids</strong>
          </div>
          <div className="text-slate-300">
            Bead Density: <strong className="text-rose-400">{beadRho} g/cm³</strong>
          </div>
          <div className="p-2 bg-[#080B4F] rounded border border-[#8194C6]/30 text-[11px] text-[#D5DEEE]">
            Equilibrium: {outputs['Equilibrium Position'] || 'Stable interface balance'}
          </div>
        </div>
      </div>
    );
  }

  // 3. SEPARATION OF MIXTURES (PAPER CHROMATOGRAPHY)
  if (simId === 'separation-mixtures') {
    const distSolv = Number(inputs.solventFrontDist ?? 10);
    const rfA = Number(outputs['Pigment A Rf'] ?? 0.45);
    const rfB = Number(outputs['Pigment B Rf'] ?? 0.75);

    return (
      <div className="w-full bg-[#030526] p-4 rounded-xl border border-[#8194C6]/30 flex flex-col sm:flex-row items-center justify-center gap-6">
        {/* Chromatography Chamber */}
        <div className="relative w-36 h-56 border-2 border-[#8194C6]/50 rounded-xl bg-slate-900/60 p-3 flex flex-col items-center justify-between">
          <div className="w-28 h-2 bg-slate-600 rounded-t-sm" />

          {/* Whatman Paper Strip */}
          <div className="w-16 h-44 bg-[#FBF4E8] rounded border border-slate-300 relative shadow-inner flex flex-col justify-end p-1">
            {/* Solvent front line */}
            <div
              className="absolute left-0 right-0 border-b border-dashed border-cyan-600"
              style={{ bottom: `${Math.min(90, distSolv * 8)}%` }}
            >
              <span className="text-[7px] text-cyan-700 font-mono font-bold pl-0.5">Solvent</span>
            </div>

            {/* Pigment B Spot */}
            <div
              className="absolute left-1/2 -translate-x-1/2 w-4 h-3 rounded-full bg-blue-500 opacity-90 shadow-xs"
              style={{ bottom: `${Math.min(85, distSolv * 8 * rfB)}%` }}
              title={`Pigment B: Rf = ${rfB}`}
            />

            {/* Pigment A Spot */}
            <div
              className="absolute left-1/2 -translate-x-1/2 w-4 h-3 rounded-full bg-amber-500 opacity-90 shadow-xs"
              style={{ bottom: `${Math.min(85, distSolv * 8 * rfA)}%` }}
              title={`Pigment A: Rf = ${rfA}`}
            />

            {/* Origin line */}
            <div className="border-b border-slate-400 w-full mb-1">
              <span className="text-[6px] text-slate-500 font-mono">Origin</span>
            </div>
          </div>

          <div className="w-32 h-2 bg-cyan-700/50 rounded-b" />
        </div>

        <div className="space-y-2 text-xs font-mono-data">
          <div className="text-[#C9A95C] font-bold text-sm">Paper Chromatography Chamber</div>
          <div className="text-slate-300">
            Solvent Front Distance: <span className="text-[#F4E5C8] font-bold">{distSolv} cm</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-amber-500" />
            <span>Pigment A Rf: <strong>{rfA}</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-blue-500" />
            <span>Pigment B Rf: <strong>{rfB}</strong></span>
          </div>
        </div>
      </div>
    );
  }

  // 4. GAS FORMATION & WATER DISPLACEMENT
  if (simId === 'gas-formation') {
    const gasVol = Number(outputs['Gas Volume (L)'] ?? outputs['CO₂ Gas Produced'] ?? 1.2);

    return (
      <div className="w-full bg-[#030526] p-4 rounded-xl border border-[#8194C6]/30 flex flex-col sm:flex-row items-center justify-center gap-6">
        {/* Reaction Flask */}
        <div className="relative w-28 h-36 border-2 border-slate-400 rounded-b-3xl bg-[#080B4F]/40 flex flex-col justify-end p-2 overflow-hidden">
          <div className="w-full h-16 bg-cyan-600/40 rounded-b-2xl relative flex items-center justify-center">
            {isRunning && (
              <div className="absolute inset-0 flex justify-around items-center">
                <span className="text-xs animate-ping text-white">🫧</span>
                <span className="text-xs animate-ping text-white delay-150">🫧</span>
              </div>
            )}
            <span className="text-[9px] font-mono text-cyan-200 font-bold">Mg + 2HCl</span>
          </div>
        </div>

        {/* Transfer tube connector */}
        <div className="hidden sm:block text-slate-400 font-mono text-lg">➔ ⚗️ ➔</div>

        {/* Inverted Gas Collection Cylinder */}
        <div className="relative w-20 h-44 border-2 border-[#8194C6]/70 rounded-t-xl bg-slate-900 flex flex-col justify-start p-1 overflow-hidden">
          {/* Gas chamber cavity expanding at top */}
          <div
            className="w-full bg-amber-400/20 border-b-2 border-amber-400 transition-all duration-500 flex items-center justify-center"
            style={{ height: `${Math.min(90, Math.max(15, gasVol * 35))}%` }}
          >
            <span className="text-[9px] font-mono text-amber-300 font-bold">H₂ Gas</span>
          </div>
          {/* Remaining water */}
          <div className="flex-1 bg-cyan-700/50" />
        </div>

        <div className="space-y-1 text-xs font-mono-data">
          <div className="text-[#C9A95C] font-bold text-sm">Pneumatic Gas Trough</div>
          <div className="text-slate-300">
            Collected Gas Volume: <span className="text-[#F4E5C8] font-bold">{gasVol} L</span>
          </div>
          <div className="text-slate-400 text-[11px]">
            PV = nRT Stoichiometric Gas Law
          </div>
        </div>
      </div>
    );
  }

  // 5. HUMAN BODY SYSTEMS (ECG & CARDIAC OUTPUT)
  if (simId === 'human-body-systems') {
    const hr = Number(outputs['Heart Rate'] ?? 72);
    const sv = Number(outputs['Stroke Volume'] ?? 70);
    const co = Number(outputs['Cardiac Output'] ?? 5.0);

    return (
      <div className="w-full bg-[#030526] p-4 rounded-xl border border-[#8194C6]/30 space-y-4">
        {/* Oscilloscope ECG Monitor */}
        <div className="w-full h-28 bg-black rounded-xl border-2 border-emerald-500/50 p-2 relative overflow-hidden flex items-center">
          {/* Grid lines */}
          <div
            className="absolute inset-0 opacity-15"
            style={{
              backgroundImage: 'linear-gradient(#10B981 1px, transparent 1px), linear-gradient(90deg, #10B981 1px, transparent 1px)',
              backgroundSize: '16px 16px'
            }}
          />

          {/* Animated SVG ECG trace */}
          <svg viewBox="0 0 400 60" className="w-full h-full relative z-10">
            <path
              d="M 0 30 L 50 30 L 60 25 L 70 30 L 80 30 L 90 10 L 100 50 L 110 30 L 130 30 L 145 20 L 160 30 L 210 30 L 220 25 L 230 30 L 240 30 L 250 10 L 260 50 L 270 30 L 290 30 L 305 20 L 320 30 L 400 30"
              fill="none"
              stroke="#10B981"
              strokeWidth="2.5"
              className={isRunning ? 'animate-pulse' : ''}
            />
          </svg>

          <div className="absolute top-2 right-3 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-xs font-mono font-bold text-emerald-400">PULSE ACTIVE</span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 font-mono-data text-xs text-center">
          <div className="p-2 bg-[#080B4F] rounded-lg border border-[#8194C6]/30">
            <div className="text-slate-400 text-[10px]">Heart Rate</div>
            <div className="text-lg font-bold text-rose-400">{hr} bpm</div>
          </div>
          <div className="p-2 bg-[#080B4F] rounded-lg border border-[#8194C6]/30">
            <div className="text-slate-400 text-[10px]">Stroke Volume</div>
            <div className="text-lg font-bold text-cyan-400">{sv} mL/beat</div>
          </div>
          <div className="p-2 bg-[#080B4F] rounded-lg border border-[#8194C6]/30">
            <div className="text-slate-400 text-[10px]">Cardiac Output (Q)</div>
            <div className="text-lg font-bold text-[#C9A95C]">{co} L/min</div>
          </div>
        </div>
      </div>
    );
  }

  // 6. MICROORGANISM GROWTH & CELL OBSERVATION
  if (simId === 'microorganism-growth' || simId === 'cell-observation') {
    const count = Number(outputs['Total Population'] ?? outputs['Cell Density'] ?? 240);
    const mag = Number(inputs.magnification ?? 400);

    return (
      <div className="w-full bg-[#030526] p-4 rounded-xl border border-[#8194C6]/30 flex flex-col sm:flex-row items-center justify-center gap-6">
        {/* Microscope Viewfinder Circle */}
        <div className="relative w-44 h-44 rounded-full border-4 border-slate-400 bg-sky-950/70 shadow-[inset_0_0_20px_rgba(0,0,0,0.8)] overflow-hidden flex items-center justify-center">
          {/* Reticle Crosshairs */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-30">
            <div className="w-full h-px bg-cyan-300" />
            <div className="h-full w-px bg-cyan-300 absolute" />
          </div>

          {/* Microscopic Cells */}
          <div className="relative w-full h-full flex items-center justify-center">
            {[...Array(12)].map((_, idx) => (
              <div
                key={idx}
                className="absolute w-4 h-4 rounded-full bg-emerald-400/80 border border-emerald-200 shadow-xs flex items-center justify-center transition-all duration-700"
                style={{
                  top: `${20 + ((idx * 17) % 65)}%`,
                  left: `${20 + ((idx * 23) % 65)}%`,
                  transform: isRunning ? `scale(${0.9 + (idx % 3) * 0.15})` : 'scale(1)'
                }}
              >
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-800" />
              </div>
            ))}
          </div>

          <div className="absolute bottom-2 text-[9px] font-mono text-cyan-200 bg-black/60 px-2 py-0.5 rounded">
            {mag}× Optical
          </div>
        </div>

        <div className="space-y-2 text-xs font-mono-data">
          <div className="text-[#C9A95C] font-bold text-sm">Fluorescence Micro-Aperture</div>
          <div className="text-slate-300">
            Field Population: <span className="text-[#F4E5C8] font-bold">{count}</span>
          </div>
          <div className="text-emerald-400 text-[11px]">
            Binary Fission Generation Rate: Active
          </div>
        </div>
      </div>
    );
  }

  // 7. WAVE MOTION & STANDING WAVES
  if (simId === 'wave-motion') {
    const freq = Number(inputs.waveFrequency ?? 40);
    const harmonics = Math.max(1, Math.min(6, Math.round(freq / 20)));

    return (
      <div className="w-full bg-[#030526] p-4 rounded-xl border border-[#8194C6]/30 space-y-3">
        <div className="flex items-center justify-between text-xs font-mono-data">
          <span className="text-[#C9A95C] font-bold">Oscillator Standing Wave Harmonics</span>
          <span className="text-slate-300">Mode: <strong>n = {harmonics} Loops</strong></span>
        </div>

        {/* Vibrating String Canvas */}
        <div className="w-full h-24 bg-black rounded-lg border border-[#8194C6]/40 relative overflow-hidden flex items-center">
          <svg viewBox="0 0 500 80" className="w-full h-full">
            {/* Upper & lower harmonic wave envelopes */}
            <path
              d={Array.from({ length: 50 }, (_, i) => {
                const x = (i / 49) * 500;
                const y = 40 + Math.sin((i / 49) * Math.PI * harmonics) * 26;
                return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
              }).join(' ')}
              fill="none"
              stroke="#C9A95C"
              strokeWidth="2.5"
            />
            <path
              d={Array.from({ length: 50 }, (_, i) => {
                const x = (i / 49) * 500;
                const y = 40 - Math.sin((i / 49) * Math.PI * harmonics) * 26;
                return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
              }).join(' ')}
              fill="none"
              stroke="#8194C6"
              strokeWidth="1.5"
              strokeDasharray="3 3"
              opacity="0.7"
            />
          </svg>
        </div>

        <div className="flex items-center justify-around font-mono-data text-xs text-slate-300">
          <div>Frequency: <span className="text-[#F4E5C8] font-bold">{freq} Hz</span></div>
          <div>Speed: <span className="text-[#C9A95C] font-bold">{outputs['Wave Speed'] || '45 m/s'}</span></div>
          <div>Wavelength: <span className="text-cyan-400 font-bold">{outputs['Wavelength'] || '1.1 m'}</span></div>
        </div>
      </div>
    );
  }

  // 8. OPTICAL LENS FOCAL LENGTH
  if (simId === 'lens-focal-length') {
    const f = Number(inputs.focalLength ?? 10);
    const doVal = Number(inputs.objectDistance ?? 25);
    const diVal = Number(outputs['Image Distance (d_i)'] ?? 16.7);

    return (
      <div className="w-full bg-[#030526] p-4 rounded-xl border border-[#8194C6]/30 space-y-3">
        <div className="text-xs font-mono-data text-[#C9A95C] font-bold">
          Optical Bench Ray Diagram (1/f = 1/d_o + 1/d_i)
        </div>

        <div className="w-full h-32 bg-slate-950 rounded-lg border border-[#8194C6]/40 relative overflow-hidden flex items-center">
          {/* Optical Axis line */}
          <div className="w-full h-0.5 bg-slate-600 absolute" />

          {/* Lens center element */}
          <div className="absolute left-1/2 -translate-x-1/2 w-3 h-24 bg-cyan-400/50 rounded-full border border-cyan-200" title={`f = ${f} cm`} />

          {/* Object on left */}
          <div className="absolute left-12 flex flex-col items-center">
            <span className="text-amber-400 font-bold text-sm">↑</span>
            <span className="text-[9px] font-mono text-amber-300">Target</span>
          </div>

          {/* Inverted Image on right */}
          <div className="absolute right-16 flex flex-col items-center">
            <span className="text-rose-400 font-bold text-sm">↓</span>
            <span className="text-[9px] font-mono text-rose-300">Image</span>
          </div>
        </div>

        <div className="flex items-center justify-around font-mono-data text-xs text-slate-300">
          <div>Object d_o: <span className="text-amber-400 font-bold">{doVal} cm</span></div>
          <div>Focal f: <span className="text-cyan-300 font-bold">{f} cm</span></div>
          <div>Image d_i: <span className="text-rose-400 font-bold">{diVal} cm</span></div>
        </div>
      </div>
    );
  }

  // 9. AIR QUALITY & PARTICULATE SMOG (ENVIRONMENTAL)
  if (simId === 'air-quality') {
    const aqi = Number(outputs['Air Quality Index (AQI)'] ?? 85);
    const pm25 = Number(inputs.pm25Concentration ?? 28);

    const aqiColor = aqi <= 50 ? 'bg-emerald-500' : aqi <= 100 ? 'bg-amber-500' : aqi <= 150 ? 'bg-orange-500' : 'bg-red-500';

    return (
      <div className="w-full bg-[#030526] p-4 rounded-xl border border-[#8194C6]/30 flex flex-col sm:flex-row items-center justify-center gap-6">
        <div className="relative w-36 h-36 rounded-2xl bg-slate-900 border border-slate-700 p-3 flex flex-col items-center justify-center gap-2">
          <div className={`w-16 h-16 rounded-full ${aqiColor} flex items-center justify-center font-mono-data text-xl font-bold text-white shadow-lg`}>
            {aqi}
          </div>
          <span className="text-[10px] font-mono uppercase text-slate-300 font-bold">US EPA AQI</span>
        </div>

        <div className="space-y-1.5 text-xs font-mono-data">
          <div className="text-[#C9A95C] font-bold text-sm">Atmospheric Particulate Sensor</div>
          <div className="text-slate-300">PM2.5 Mass: <span className="text-rose-400 font-bold">{pm25} μg/m³</span></div>
          <div className="text-slate-300">Condition: <span className="text-[#F4E5C8] font-bold">{outputs['Health Category'] || 'Moderate Air Quality'}</span></div>
        </div>
      </div>
    );
  }

  // DEFAULT / GENERAL APPARATUS BENCH
  return (
    <div className="w-full bg-[#030526] p-4 rounded-xl border border-[#8194C6]/30 flex items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-xl bg-[#080B4F] border border-[#8194C6]/40 flex items-center justify-center text-2xl shadow">
          {experiment.equipment[0]?.icon || '🔬'}
        </div>
        <div>
          <div className="text-xs font-mono-data uppercase tracking-wider text-[#C9A95C]">
            {experiment.category} Apparatus Online
          </div>
          <div className="text-sm font-serif-display font-semibold text-[#F4E5C8]">
            {experiment.equipment[0]?.name || experiment.title}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 font-mono-data text-xs bg-[#080B4F] px-3 py-1.5 rounded-lg border border-[#8194C6]/30">
        <span className={`w-2.5 h-2.5 rounded-full ${isRunning ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
        <span className="text-[#D5DEEE]">{isRunning ? 'Active Telemetry' : 'Calibrated'}</span>
      </div>
    </div>
  );
};
