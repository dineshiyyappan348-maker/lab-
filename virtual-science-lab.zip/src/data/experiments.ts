import { ExperimentDef, Achievement } from '../types';
import { PHYSICS_EXPERIMENTS } from './physicsExperiments';
import { CHEMISTRY_EXPERIMENTS } from './chemistryExperiments';
import { BIOLOGY_EXPERIMENTS } from './biologyExperiments';
import { ENVIRONMENTAL_EXPERIMENTS } from './environmentalExperiments';

export const HERO_BANNER_IMAGE = '/src/assets/images/virtual_science_lab_hero_1791477937620.jpg';
export const PHYSICS_BENCH_IMAGE = '/src/assets/images/physics_lab_workbench_1791477950831.jpg';
export const CHEMISTRY_GLASSWARE_IMAGE = '/src/assets/images/chemistry_lab_glassware_1791477967554.jpg';

export const EXPERIMENTS_DATA: ExperimentDef[] = [
  ...PHYSICS_EXPERIMENTS,
  ...CHEMISTRY_EXPERIMENTS,
  ...BIOLOGY_EXPERIMENTS,
  ...ENVIRONMENTAL_EXPERIMENTS
];

export const CATEGORIES_DATA = [
  {
    id: 'physics' as const,
    name: 'Physics Lab',
    icon: '⚡',
    description: 'Electricity, circuits, kinematics, force, optics, and wave motion.',
    colorHex: '#080B4F',
    accentHex: '#8194C6',
    experimentCount: EXPERIMENTS_DATA.filter((e) => e.category === 'physics').length,
    highlight: "Ohm's Law, Projectiles & Optics"
  },
  {
    id: 'chemistry' as const,
    name: 'Chemistry Lab',
    icon: '⚗️',
    description: 'Acids, bases, pH dynamics, solubility, kinetics, and equilibrium.',
    colorHex: '#080B4F',
    accentHex: '#A27F35',
    experimentCount: EXPERIMENTS_DATA.filter((e) => e.category === 'chemistry').length,
    highlight: 'Titration, pH Scale & Reaction Rates'
  },
  {
    id: 'biology' as const,
    name: 'Biology Lab',
    icon: '🌱',
    description: 'Plant growth, photosynthesis, osmosis, genetics, and ecology.',
    colorHex: '#080B4F',
    accentHex: '#8194C6',
    experimentCount: EXPERIMENTS_DATA.filter((e) => e.category === 'biology').length,
    highlight: 'Photosynthesis, Genetics & Enzymes'
  },
  {
    id: 'environmental' as const,
    name: 'Environmental Science',
    icon: '🌍',
    description: 'Water quality, air pollution, renewables, and climate modeling.',
    colorHex: '#080B4F',
    accentHex: '#A27F35',
    experimentCount: EXPERIMENTS_DATA.filter((e) => e.category === 'environmental').length,
    highlight: 'Water Quality, Solar/Wind & Climate'
  }
];

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_exp',
    title: 'First Experiment',
    icon: '🧪',
    description: 'Complete your first interactive virtual laboratory experiment.',
    categoryRequirement: 'all',
    requiredCount: 1,
    xpBonus: 50
  },
  {
    id: 'lab_explorer',
    title: 'Lab Explorer',
    icon: '🔬',
    description: 'Successfully execute 5 experiments across any science domain.',
    categoryRequirement: 'all',
    requiredCount: 5,
    xpBonus: 100
  },
  {
    id: 'physics_explorer',
    title: 'Physics Explorer',
    icon: '⚡',
    description: 'Master circuits and motion by completing 5 physics trials.',
    categoryRequirement: 'physics',
    requiredCount: 5,
    xpBonus: 120
  },
  {
    id: 'chem_explorer',
    title: 'Chemistry Explorer',
    icon: '⚗️',
    description: 'Demonstrate laboratory mastery across 5 chemistry titrations and solutions.',
    categoryRequirement: 'chemistry',
    requiredCount: 5,
    xpBonus: 120
  },
  {
    id: 'bio_explorer',
    title: 'Biology Explorer',
    icon: '🌱',
    description: 'Investigate cells, genetics, and plant growth in 5 biology sessions.',
    categoryRequirement: 'biology',
    requiredCount: 5,
    xpBonus: 120
  },
  {
    id: 'eco_guardian',
    title: 'Eco Guardian',
    icon: '🌍',
    description: 'Evaluate water quality and renewable energy across 5 environmental studies.',
    categoryRequirement: 'environmental',
    requiredCount: 5,
    xpBonus: 120
  },
  {
    id: 'science_master',
    title: 'Science Master',
    icon: '🏆',
    description: 'Complete 25 total laboratory experiments and research simulations.',
    categoryRequirement: 'all',
    requiredCount: 25,
    xpBonus: 250
  },
  {
    id: 'grand_scholar',
    title: 'Grand Laboratory Scholar',
    icon: '🎓',
    description: 'Conduct 50 scientific simulations and master the laboratory syllabus.',
    categoryRequirement: 'all',
    requiredCount: 50,
    xpBonus: 500
  },
  {
    id: 'voltage_virtuoso',
    title: 'Circuit Specialist',
    icon: '🔋',
    description: 'Conclude 3 advanced electrical experiments with 100% calculation accuracy.',
    categoryRequirement: 'physics',
    requiredCount: 3,
    xpBonus: 80
  }
];
