import React, { useState } from 'react';
import { UserProfile } from '../types';
import { HERO_BANNER_IMAGE } from '../data/experiments';
import { soundEngine } from '../utils/audio';

interface LoginProps {
  onLoginSuccess: (user: Partial<UserProfile>) => void;
}

export const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [studentName, setStudentName] = useState('Alex Morgan');
  const [authMode, setAuthMode] = useState<'demo' | 'email' | 'phone'>('demo');
  const [emailInput, setEmailInput] = useState('');
  const [phoneInput, setPhoneInput] = useState('');

  const handleGuestDemo = () => {
    soundEngine.click();
    onLoginSuccess({
      name: 'Alex Morgan',
      email: 'alex.morgan@science.edu',
      role: 'Science Explorer'
    });
  };

  const handleCustomLogin = (e: React.FormEvent) => {
    e.preventDefault();
    soundEngine.click();
    const finalName = studentName.trim() || 'Young Scientist';
    onLoginSuccess({
      name: finalName,
      email: emailInput || `${finalName.toLowerCase().replace(/\s+/g, '.')}@science.edu`,
      role: 'Science Explorer'
    });
  };

  return (
    <div className="min-h-screen bg-[#F4E5C8] flex flex-col justify-center py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* LEFT SIDE: Brand introduction & Academic Illustrations */}
        <div className="lg:col-span-7 space-y-6">
          <div className="flex items-center gap-3 text-sm font-semibold tracking-wider uppercase text-[#080B4F]">
            <span className="w-2.5 h-2.5 rounded-full bg-[#A27F35]" />
            <span>Interactive Virtual Laboratory Platform</span>
          </div>

          <div className="space-y-3">
            <h1 className="font-serif-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#080B4F] leading-[1.1]">
              🔬 Virtual Science Lab
            </h1>
            <p className="font-serif-display text-2xl sm:text-3xl font-medium text-[#A27F35] italic">
              "Explore. Experiment. Discover."
            </p>
          </div>

          <p className="text-base sm:text-lg text-[#080B4F]/80 max-w-xl leading-relaxed">
            Learn science through interactive virtual experiments. Connect electrical circuits,
            titrate acids and bases, analyze plant photosynthesis, and investigate environmental
            ecosystems with real educational formulas.
          </p>

          {/* Minimal Academic Scientific Icons Strip */}
          <div className="flex items-center gap-6 py-2 text-[#080B4F]/70 text-sm">
            <div className="flex items-center gap-1.5 font-medium">
              <span>⚗️</span>
              <span>Beaker</span>
            </div>
            <span className="text-[#8194C6]">•</span>
            <div className="flex items-center gap-1.5 font-medium">
              <span>🔬</span>
              <span>Microscope</span>
            </div>
            <span className="text-[#8194C6]">•</span>
            <div className="flex items-center gap-1.5 font-medium">
              <span>⚛️</span>
              <span>Atom</span>
            </div>
            <span className="text-[#8194C6]">•</span>
            <div className="flex items-center gap-1.5 font-medium">
              <span>🧬</span>
              <span>Genetics</span>
            </div>
            <span className="text-[#8194C6]">•</span>
            <div className="flex items-center gap-1.5 font-medium">
              <span>🧪</span>
              <span>Reactions</span>
            </div>
          </div>

          {/* Hero Banner Visual Asset with Zero-Broken-Image Fallback */}
          <div className="relative rounded-2xl overflow-hidden border border-[#080B4F]/20 shadow-lg bg-[#080B4F]">
            <img
              src={HERO_BANNER_IMAGE}
              alt="Virtual Science Lab apparatus visual"
              referrerPolicy="no-referrer"
              className="w-full h-56 sm:h-64 object-cover object-center opacity-90 transition-transform duration-700 hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#080B4F]/80 via-transparent to-transparent flex items-end p-4">
              <span className="text-xs font-mono-data text-[#F4E5C8] bg-[#080B4F]/70 px-2.5 py-1 rounded backdrop-blur-sm">
                Physics · Chemistry · Biology · Environmental Science
              </span>
            </div>
          </div>
        </div>

        {/* RIGHT SIDE: Login Card */}
        <div className="lg:col-span-5">
          <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-xl border border-[#080B4F]/15 space-y-6">
            <div className="space-y-1">
              <h2 className="font-serif-display text-2xl sm:text-3xl font-bold text-[#080B4F]">
                Welcome Back
              </h2>
              <p className="text-sm text-slate-600">
                Sign in to continue your laboratory journey.
              </p>
            </div>

            {/* Quick Demo 1-Click Access Button */}
            <div className="p-4 rounded-2xl bg-[#F4E5C8]/40 border border-[#A27F35]/30 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#080B4F]">
                  Fast Student Access
                </span>
                <span className="text-[11px] font-mono-data text-[#A27F35] font-semibold">
                  Demo Mode
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-snug">
                Jump directly into the virtual lab as Research Student with 18 saved experiments & 720 XP.
              </p>
              <button
                type="button"
                onClick={handleGuestDemo}
                className="w-full mt-1 py-3 px-4 rounded-xl font-semibold text-sm bg-[#080B4F] hover:bg-[#0e1363] text-[#F4E5C8] shadow-md transition-all flex items-center justify-center gap-2"
              >
                <span>🚀</span>
                <span>Enter as Guest Demo Student</span>
              </button>
            </div>

            <div className="relative flex items-center justify-center text-xs text-slate-400">
              <div className="border-t border-slate-200 w-full" />
              <span className="bg-white px-3 whitespace-nowrap text-slate-500 font-medium">
                Or sign in with
              </span>
              <div className="border-t border-slate-200 w-full" />
            </div>

            {/* Social / Simulated Provider Buttons */}
            <div className="space-y-3">
              <button
                type="button"
                onClick={() => {
                  soundEngine.click();
                  onLoginSuccess({
                    name: 'Google Explorer',
                    email: 'student@google.demo',
                    role: 'Science Explorer'
                  });
                }}
                className="w-full py-2.5 px-4 rounded-xl border border-slate-300 hover:border-[#080B4F] bg-white text-slate-700 font-medium text-xs sm:text-sm flex items-center justify-center gap-3 transition-colors shadow-sm"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span>Continue with Google</span>
              </button>

              <button
                type="button"
                onClick={() => setAuthMode(authMode === 'email' ? 'demo' : 'email')}
                className="w-full py-2.5 px-4 rounded-xl border border-slate-300 hover:border-[#080B4F] bg-white text-slate-700 font-medium text-xs sm:text-sm flex items-center justify-center gap-3 transition-colors shadow-sm"
              >
                <span>✉️</span>
                <span>Continue with Email</span>
              </button>

              <button
                type="button"
                onClick={() => setAuthMode(authMode === 'phone' ? 'demo' : 'phone')}
                className="w-full py-2.5 px-4 rounded-xl border border-slate-300 hover:border-[#080B4F] bg-white text-slate-700 font-medium text-xs sm:text-sm flex items-center justify-center gap-3 transition-colors shadow-sm"
              >
                <span>📱</span>
                <span>Continue with Phone Number</span>
              </button>
            </div>

            {/* Email / Custom credentials input form */}
            {authMode !== 'demo' && (
              <form onSubmit={handleCustomLogin} className="pt-2 border-t border-slate-100 space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Student Full Name
                  </label>
                  <input
                    type="text"
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    required
                    placeholder="e.g. Alex Morgan"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#080B4F]"
                  />
                </div>

                {authMode === 'email' ? (
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      School Email Address
                    </label>
                    <input
                      type="email"
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      placeholder="student@school.org"
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#080B4F]"
                    />
                  </div>
                ) : (
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      value={phoneInput}
                      onChange={(e) => setPhoneInput(e.target.value)}
                      placeholder="+1 (555) 019-2834"
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#080B4F]"
                    />
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 rounded-xl bg-[#080B4F] text-[#F4E5C8] font-semibold text-sm hover:bg-[#0e1363] transition-colors"
                >
                  Sign In & Enter Laboratory
                </button>
              </form>
            )}

            <div className="pt-2 text-center text-xs text-slate-500">
              New student?{' '}
              <button
                type="button"
                onClick={handleGuestDemo}
                className="text-[#080B4F] font-semibold hover:underline"
              >
                Create Account
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
