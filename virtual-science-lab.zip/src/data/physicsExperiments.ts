import { ExperimentDef } from '../types';

export const PHYSICS_EXPERIMENTS: ExperimentDef[] = [
  {
    id: 'ohm-law',
    title: "Ohm's Law",
    category: 'physics',
    subcategory: 'Electricity & Circuits',
    topic: 'Ohmic Resistance & Current',
    keywords: ['voltage', 'current', 'resistance', 'electricity', 'circuits', 'power'],
    shortDescription: 'Explore the fundamental relationship between voltage, electric current, and resistance in a DC circuit.',
    learningObjective: 'Understand the relationship between voltage, current, and resistance by varying parameters and observing filament brightness and meter dials.',
    scientificPrinciple: 'V = I × R (Voltage = Current × Resistance). Current is directly proportional to applied voltage and inversely proportional to resistance.',
    whyItWorks: 'Free conduction electrons inside a metal conductor are accelerated by the electric field created by the voltage source. Collisions with vibrating lattice atoms dissipate energy as heat and light.',
    observationGuide: 'As you elevate the voltage slider while keeping resistance fixed, the ammeter needle deflects higher and the filament glows with increased luminous intensity.',
    conclusionTemplate: 'Ohm\'s Law is confirmed: current I scales linearly with voltage V and inversely with resistance R.',
    formula: 'I = V / R,  P = V × I',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Assemble the DC series circuit connecting the variable power supply, rheostat, ammeter, and tungsten bulb.",
      "Calibrate the digital ammeter and voltmeter to zero baseline before closing the knife switch.",
      "Set the circuit resistance to a fixed initial value (5 Ω) using the variable resistor slider.",
      "Increment the applied voltage from 1 V to 24 V in measured steps, recording the current and bulb brightness.",
      "Compute the slope of Voltage vs Current (V/I) to determine if the conductor exhibits Ohmic linearity."
],
    learningPoints: [
      "Current is directly proportional to applied voltage when physical temperature and resistance remain constant.",
      "Electrical resistance acts as friction against electron flow, converting kinetic electrical energy into thermal photons.",
      "Electrical power dissipation scales quadratically with voltage for a given resistance: P = V² / R."
],
    simulationType: 'ohm-law',
    equipment: [
      { name: 'DC Power Supply', icon: '🔋', spec: '0 – 24 V Variable' },
      { name: 'Incandescent Bulb', icon: '💡', spec: 'Tungsten filament 12V max' },
      { name: 'Variable Resistor', icon: '🎛️', spec: '1 – 50 Ω Rheostat' },
      { name: 'Precision Ammeter', icon: '📊', spec: '0 – 10 A Analog/Digital' },
      { name: 'Voltmeter', icon: '📈', spec: '0 – 30 V High Impedance' },
      { name: 'Copper Leads', icon: '🔌', spec: 'Low resistance banana plugs' }
    ],
    controls: [
      { id: 'voltage', label: 'Applied Voltage', unit: 'V', min: 1, max: 24, step: 1, defaultValue: 10, description: 'Electrical potential difference driving charge flow' },
      { id: 'resistance', label: 'Circuit Resistance', unit: 'Ω', min: 1, max: 50, step: 1, defaultValue: 5, description: 'Opposition to the flow of electric charge' }
    ]
  },
  {
    id: 'series-circuit',
    title: 'Series Circuit',
    category: 'physics',
    subcategory: 'Electricity & Circuits',
    topic: 'Voltage Divider & Resistance',
    keywords: ['series', 'circuits', 'resistors', 'voltage drop', 'kirchhoff', 'electricity'],
    shortDescription: 'Investigate how equivalent resistance accumulates and how electrical potential divides across series components.',
    learningObjective: 'Demonstrate that in a single-loop series circuit, current is uniform everywhere, while voltage divides according to each component\'s resistance.',
    scientificPrinciple: 'R_total = R₁ + R₂ and V_total = V₁ + V₂. Total resistance equals the sum of individual resistances, reducing overall circuit current.',
    whyItWorks: 'Charges have only one single path to travel. Any impediment added sequentially adds directly to the total resistance encountered by the flowing electrons.',
    observationGuide: 'Adding more bulbs in series increases total resistance and dims all bulbs equally. Opening the switch interrupts the entire loop.',
    conclusionTemplate: 'In a series circuit, current remains identical across every element, whereas total voltage divides proportionally to resistances.',
    formula: 'R_eq = R₁ + R₂,  I = V / R_eq',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Connect two resistive loads (R₁ and R₂) in series across the regulated 12 V DC power source.",
      "Insert the digital ammeter in series to verify that current magnitude is uniform at all points in the single loop.",
      "Place voltmeter leads across Load 1 (V₁) and Load 2 (V₂) sequentially to record individual component voltage drops.",
      "Vary the resistance of Resistor 1 and record the resulting reallocation of voltage across both loads.",
      "Confirm that the sum of individual voltage drops equals the source voltage (V_source = V₁ + V₂)."
],
    learningPoints: [
      "In a single continuous loop, every charge carrier must pass through all loads, ensuring identical current everywhere.",
      "Equivalent resistance in series is the algebraic sum of component resistances: R_total = R₁ + R₂.",
      "Voltage drops divide strictly in direct proportion to resistance ratios (Voltage Divider Principle)."
],
    simulationType: 'series-circuit',
    equipment: [
      { name: 'DC Supply', icon: '🔋', spec: '12 V Regulated' },
      { name: 'Bulb #1 (Load 1)', icon: '💡', spec: 'Variable load R₁' },
      { name: 'Bulb #2 (Load 2)', icon: '💡', spec: 'Variable load R₂' },
      { name: 'Digital Multimeter', icon: '📊', spec: 'Dual channel probe' },
      { name: 'Knife Switch', icon: '🎛️', spec: 'Single pole single throw' }
    ],
    controls: [
      { id: 'sourceVoltage', label: 'Supply Voltage', unit: 'V', min: 4, max: 24, step: 2, defaultValue: 12, description: 'Master battery voltage' },
      { id: 'resistor1', label: 'Resistor R₁', unit: 'Ω', min: 2, max: 20, step: 1, defaultValue: 4, description: 'First component resistance' },
      { id: 'resistor2', label: 'Resistor R₂', unit: 'Ω', min: 2, max: 20, step: 1, defaultValue: 6, description: 'Second component resistance' }
    ]
  },
  {
    id: 'parallel-circuit',
    title: 'Parallel Circuit',
    category: 'physics',
    subcategory: 'Electricity & Circuits',
    topic: 'Current Divider & Branching',
    keywords: ['parallel', 'circuits', 'current division', 'branches', 'electricity'],
    shortDescription: 'Analyze multiple independent branch paths where voltage is identical across each load while total current divides.',
    learningObjective: 'Observe that adding branches in parallel decreases overall equivalent resistance, allowing independent switching without dimming existing bulbs.',
    scientificPrinciple: '1 / R_eq = 1 / R₁ + 1 / R₂ and I_total = I₁ + I₂. Each branch experiences the full source voltage.',
    whyItWorks: 'Parallel branches offer alternate pathways for electron flow. The cross-sectional area for current effectively expands, reducing equivalent resistance.',
    observationGuide: 'Adjusting branch 2 has zero effect on branch 1 bulb brightness. Total current supplied by the battery equals the sum of both branch currents.',
    conclusionTemplate: 'Parallel topologies maintain constant component voltage and lower equivalent resistance.',
    formula: '1/R_eq = 1/R₁ + 1/R₂,  I_total = I₁ + I₂',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Construct a two-branch parallel network connecting Resistor 1 and Resistor 2 across a common 12 V rail.",
      "Measure the voltage across each parallel branch using a high-impedance voltmeter.",
      "Place individual current probes along Branch 1, Branch 2, and the main feeder line from the power supply.",
      "Vary Resistor 1 resistance and observe that Branch 2 current remains completely independent and unaffected.",
      "Verify that the total supply current equals the sum of the branch currents: I_total = I₁ + I₂."
],
    learningPoints: [
      "Every branch in a parallel circuit experiences the full supply potential difference: V₁ = V₂ = V_total.",
      "Total equivalent resistance in parallel is always strictly less than the smallest individual branch resistor.",
      "Parallel circuits provide independent operating paths; disconnecting one load does not interrupt remaining loads."
],
    simulationType: 'parallel-circuit',
    equipment: [
      { name: 'DC Supply', icon: '🔋', spec: '12 V Constant' },
      { name: 'Branch 1 Bulb', icon: '💡', spec: 'Parallel Branch A' },
      { name: 'Branch 2 Bulb', icon: '💡', spec: 'Parallel Branch B' },
      { name: 'Branch Ammeters', icon: '📊', spec: 'A₁ and A₂ gauges' },
      { name: 'Total Ammeter', icon: '📈', spec: 'A_total source gauge' }
    ],
    controls: [
      { id: 'sourceVoltage', label: 'Supply Voltage', unit: 'V', min: 6, max: 24, step: 2, defaultValue: 12, description: 'Common voltage applied across both branches' },
      { id: 'resistor1', label: 'Branch 1 Load (R₁)', unit: 'Ω', min: 2, max: 20, step: 1, defaultValue: 4, description: 'Resistance in branch 1' },
      { id: 'resistor2', label: 'Branch 2 Load (R₂)', unit: 'Ω', min: 2, max: 20, step: 1, defaultValue: 6, description: 'Resistance in branch 2' }
    ]
  },
  {
    id: 'kirchhoff-laws',
    title: "Kirchhoff's Laws",
    category: 'physics',
    subcategory: 'Electricity & Circuits',
    topic: 'Junction & Loop Rules',
    keywords: ['kirchhoff', 'junction rule', 'loop rule', 'nodal analysis', 'conservation of charge'],
    shortDescription: 'Validate Kirchhoff\'s Current Law (junctions) and Voltage Law (closed loops) in multi-node electrical networks.',
    learningObjective: 'Verify conservation of electric charge at circuit junctions and conservation of energy around closed loops.',
    scientificPrinciple: 'Σ I_in = Σ I_out (KCL) and Σ ΔV_loop = 0 (KVL). The algebraic sum of currents entering a node is zero, and the sum of potential differences around any closed mesh is zero.',
    whyItWorks: 'Electric charge cannot pool indefinitely at a node without creating enormous electrostatic repulsion, and moving around a closed path returns to the exact same scalar electric potential.',
    observationGuide: 'Current splitting at Node A recombines identically at Node B. Summing battery EMF and resistor drops around loop equals 0.00 V.',
    conclusionTemplate: 'Kirchhoff\'s Current and Voltage laws verified to 100% precision across multi-branch mesh.',
    formula: 'Σ I_junction = 0,  Σ V_loop = 0',
    difficulty: 'Advanced',
    duration: '20 min',
    xpReward: 80,
    procedure: [
      "Set up a dual-mesh circuit with two independent DC voltage sources (E₁ and E₂) and three interconnecting branches.",
      "Establish sign conventions for loop orientation (clockwise) and node current directions (inflow vs outflow).",
      "Measure the currents converging at the central junction node to test Kirchhoff's Current Law (KCL: ΣI_in = ΣI_out).",
      "Traverse Loop 1 and Loop 2 with a voltmeter to verify Kirchhoff's Voltage Law (KVL: ΣΔV = 0 around any closed path).",
      "Adjust Source 2 voltage and observe automatic redistribution of junction currents maintaining node conservation."
],
    learningPoints: [
      "Kirchhoff's Current Law (KCL) is a direct consequence of the fundamental conservation of electric charge.",
      "Kirchhoff's Voltage Law (KVL) is a direct consequence of the conservation of energy in electrostatic fields.",
      "Complex multi-loop networks with multiple active sources can be solved systematically via linear matrix algebra."
],
    simulationType: 'kirchhoff-laws',
    equipment: [
      { name: 'Dual DC Source', icon: '🔋', spec: 'Independent V₁ and V₂ rails' },
      { name: '3-Resistor Bridge', icon: '🎛️', spec: 'R₁, R₂, R₃ network' },
      { name: 'Junction Ammeter Array', icon: '📊', spec: 'Node current sensors' },
      { name: 'Differential Voltmeter', icon: '📈', spec: 'Loop potential tracker' }
    ],
    controls: [
      { id: 'sourceV1', label: 'Primary Voltage (V₁)', unit: 'V', min: 5, max: 20, step: 1, defaultValue: 12, description: 'Left mesh power supply' },
      { id: 'sourceV2', label: 'Secondary Voltage (V₂)', unit: 'V', min: 0, max: 15, step: 1, defaultValue: 6, description: 'Right mesh power supply' },
      { id: 'rCommon', label: 'Shared Branch (R_c)', unit: 'Ω', min: 2, max: 15, step: 1, defaultValue: 5, description: 'Middle junction resistor' }
    ]
  },
  {
    id: 'projectile-motion',
    title: 'Projectile Motion',
    category: 'physics',
    subcategory: 'Kinematics & Dynamics',
    topic: '2D Trajectory & Ballistics',
    keywords: ['projectile', 'motion', 'trajectory', 'angle', 'velocity', 'gravity', 'parabola'],
    shortDescription: 'Launch projectiles at variable angles and velocities to calculate maximum altitude, flight duration, and horizontal range.',
    learningObjective: 'Decompose 2D kinematics into independent constant-velocity horizontal and constant-acceleration vertical vectors.',
    scientificPrinciple: 'Horizontal: x(t) = v₀ cos(θ) t. Vertical: y(t) = v₀ sin(θ) t - ½ g t². Range R = (v₀² sin(2θ)) / g.',
    whyItWorks: 'Gravity acts purely vertically downward, leaving horizontal momentum conserved in the absence of air drag. The path forms a symmetric parabola.',
    observationGuide: 'A 45° launch angle maximizes horizontal range for any given initial speed, while complementary angles (e.g. 30° and 60°) achieve identical ground range.',
    conclusionTemplate: 'Kinematic trajectory calculations confirmed. Maximum range achieved at launch angle θ = 45° under uniform gravity.',
    formula: 'R = (v₀² sin 2θ)/g,  H_max = (v₀² sin²θ)/(2g)',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Position the virtual pneumatic launcher at ground level on the calibrated ballistic firing range.",
      "Select initial launch velocity (v₀) and set the angular elevation barrel angle (θ) on the graduated protractor.",
      "Specify local gravitational acceleration (e.g., Earth 9.8 m/s², Moon 1.6 m/s², or Mars 3.7 m/s²).",
      "Execute the ballistic launch and record trajectory data: flight duration, peak apogee, and horizontal impact range.",
      "Compare 30°, 45°, and 60° launch trajectories to confirm maximum horizontal displacement at 45° in vacuum."
],
    learningPoints: [
      "Horizontal and vertical kinematic motions are completely independent; gravity accelerates only the vertical component.",
      "Horizontal velocity remains constant (v_x = v₀ cos θ) when aerodynamic drag is neglected.",
      "Maximum horizontal range in flat terrain occurs at a 45° launch angle due to the sin(2θ) trigonometric relationship."
],
    simulationType: 'projectile-motion',
    equipment: [
      { name: 'Pneumatic Ballistic Launcher', icon: '🚀', spec: '0 – 50 m/s muzzle speed' },
      { name: 'Angle Goniometer', icon: '📐', spec: '0° – 90° azimuth elevation' },
      { name: 'Photogate Velocity Gate', icon: '⏱️', spec: 'Microsecond speed detector' },
      { name: 'Impact Landing Sand Strip', icon: '📏', spec: 'Precision metric range scale' }
    ],
    controls: [
      { id: 'initialVelocity', label: 'Muzzle Velocity (v₀)', unit: 'm/s', min: 5, max: 40, step: 1, defaultValue: 20, description: 'Initial exit speed of the projectile' },
      { id: 'launchAngle', label: 'Launch Angle (θ)', unit: '°', min: 10, max: 80, step: 5, defaultValue: 45, description: 'Elevation angle relative to horizontal ground' },
      { id: 'gravity', label: 'Gravitational Field (g)', unit: 'm/s²', min: 1.6, max: 24.8, step: 0.1, defaultValue: 9.8, description: 'Planetary gravity (9.8 Earth, 1.6 Moon, 24.8 Jupiter)' }
    ]
  },
  {
    id: 'newton-second-law',
    title: "Newton's Second Law",
    category: 'physics',
    subcategory: 'Kinematics & Dynamics',
    topic: 'Force, Mass & Acceleration',
    keywords: ['newton', 'force', 'mass', 'acceleration', 'dynamics', 'f=ma'],
    shortDescription: 'Accelerate a dynamics cart with variable hanging masses to demonstrate F = m × a on a frictionless air track.',
    learningObjective: 'Validate that acceleration is directly proportional to net applied force and inversely proportional to total system mass.',
    scientificPrinciple: 'F_net = m_total × a. Therefore a = F_net / m_total. Force produces uniform acceleration in the direction of the vector sum of forces.',
    whyItWorks: 'Inertia resists changes in state of motion. Increasing mass increases resistance to acceleration, while increasing unbalanced force intensifies momentum rate of change.',
    observationGuide: 'Doubling the towing force doubles acceleration. Doubling cart mass cuts acceleration in half.',
    conclusionTemplate: 'Newton\'s Second Law F = ma confirmed with high linear correlation (R² = 1.00).',
    formula: 'a = F_net / m,  F = m × a',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Place a low-friction dynamic cart of mass M on a leveled aluminum track with optical photogates.",
      "Attach a light inextensible cord passing over a low-inertia pulley to a suspended accelerating mass m.",
      "Set the applied net force and total system mass on the simulation control sliders.",
      "Release the cart from rest and record the transit acceleration using the dual photogate timers.",
      "Double the net accelerating force while maintaining constant system mass, observing the proportional doubling of acceleration."
],
    learningPoints: [
      "Acceleration is directly proportional to net external force and inversely proportional to total system mass: a = F_net / m.",
      "Mass represents mechanical inertia: the inherent resistance of matter to any change in its velocity state.",
      "System acceleration must account for all moving masses, including both the cart and the suspended hanging weight."
],
    simulationType: 'newton-second-law',
    equipment: [
      { name: 'Linear Air Track', icon: '📏', spec: '2.0 meter frictionless glide rail' },
      { name: 'Dynamics Glider', icon: '🛒', spec: 'Variable ballast cart (0.2 – 1.0 kg)' },
      { name: 'Hanging Weight Carrier', icon: '⚖️', spec: 'Towing mass producing tension force' },
      { name: 'Dual Optical Photogates', icon: '⏱️', spec: 'Acceleration timer readout' }
    ],
    controls: [
      { id: 'appliedForce', label: 'Applied Force (F)', unit: 'N', min: 0.5, max: 10.0, step: 0.5, defaultValue: 3.0, description: 'Net horizontal pulling force' },
      { id: 'cartMass', label: 'Object Mass (m)', unit: 'kg', min: 0.2, max: 2.0, step: 0.1, defaultValue: 0.8, description: 'Inertial mass of accelerating body' }
    ]
  },
  {
    id: 'friction',
    title: 'Friction: Static & Kinetic Coefficients',
    category: 'physics',
    subcategory: 'Kinematics & Dynamics',
    topic: 'Frictional Forces & Surface Contact',
    keywords: ['friction', 'normal force', 'static friction', 'kinetic friction', 'surfaces', 'coefficient'],
    shortDescription: 'Determine static and kinetic friction coefficients across wood, rubber, and steel surfaces at varying normal forces.',
    learningObjective: 'Measure maximum static friction force before slip and observe transition to constant kinetic friction during motion.',
    scientificPrinciple: 'f_s ≤ μ_s N and f_k = μ_k N. Normal force N = mg. Static coefficient μ_s is consistently greater than kinetic coefficient μ_k.',
    whyItWorks: 'Microscopic surface asperities cold-weld and interlock when stationary. Once shearing initiates, microscopic contact points slide and fracture with less average resisting force.',
    observationGuide: 'The force gauge spikes to a peak (static threshold) right before breakaway, then drops to a lower, steady plateau (kinetic drag).',
    conclusionTemplate: 'Friction forces scale directly with normal load N, confirming Amontons\' laws of friction.',
    formula: 'f_s(max) = μ_s N,  f_k = μ_k N',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Place a standardized test block of known mass onto the horizontal materials testing platform.",
      "Select contact material interface (e.g., Wood on Wood, Steel on Steel, Rubber on Concrete, or Ice on Steel).",
      "Apply an incrementally increasing horizontal pulling force while monitoring the load-cell force gauge.",
      "Record the peak static breakaway force immediately prior to motion initiation to determine coefficient μ_s.",
      "Measure the sustained kinetic pulling force during uniform steady sliding to evaluate kinetic coefficient μ_k."
],
    learningPoints: [
      "Static friction matches the applied tangential force up to a critical maximum threshold: f_s ≤ μ_s · N.",
      "Kinetic friction is almost universally lower than maximum static friction because microscopic asperities interlock less during motion.",
      "Frictional forces are fundamentally independent of apparent surface area, depending only on normal force and interface materials."
],
    simulationType: 'friction',
    equipment: [
      { name: 'Interchangeable Test Sled', icon: '🛷', spec: 'Wood, Rubber, Steel contact pads' },
      { name: 'Calibrated Force Sensor', icon: '📊', spec: 'Precision digital strain gauge' },
      { name: 'Normal Load Masses', icon: '⚖️', spec: 'Stackable brass weights' },
      { name: 'Motorized Pull Winch', icon: '🎛️', spec: 'Constant velocity drive' }
    ],
    controls: [
      { id: 'normalMass', label: 'Load Mass', unit: 'kg', min: 0.5, max: 5.0, step: 0.5, defaultValue: 2.0, description: 'Weight pressing block onto surface' },
      { id: 'surfaceType', label: 'Surface Pair', unit: '', min: 0, max: 2, step: 1, defaultValue: 0, description: '0: Wood on Wood (0.4/0.3), 1: Rubber on Concrete (0.8/0.65), 2: Steel on Ice (0.1/0.05)' }
    ]
  },
  {
    id: 'simple-pendulum',
    title: 'Simple Pendulum',
    category: 'physics',
    subcategory: 'Oscillations & Waves',
    topic: 'Harmonic Motion & Period',
    keywords: ['pendulum', 'period', 'frequency', 'simple harmonic motion', 'gravity', 'length'],
    shortDescription: 'Measure oscillation period as a function of string length, bob mass, and planetary gravitational acceleration.',
    learningObjective: 'Demonstrate that the period of a simple pendulum depends strictly on length and gravity, independent of bob mass for small angles.',
    scientificPrinciple: 'T = 2π √(L / g) for small angular displacements (θ < 15°). Period T is independent of bob mass m.',
    whyItWorks: 'The restoring gravitational torque is proportional to displacement angle. Higher mass increases inertia identically to how it increases gravitational restoring force, canceling mass entirely.',
    observationGuide: 'Quadrupling string length doubles the period T. Varying bob mass from 50g to 500g produces zero change in oscillation period.',
    conclusionTemplate: 'Isochronism of the pendulum verified: T ∝ √L and T is completely independent of mass.',
    formula: 'T = 2π √(L/g),  f = 1/T',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Suspend a dense spherical bob from an unyielding, negligible-mass string attached to a rigid clamp.",
      "Adjust string length (L) from 0.2 meters to 2.5 meters using the graduated length adjustment dial.",
      "Deflect the pendulum bob by a small angle (< 15°) to ensure simple harmonic small-angle approximation holds.",
      "Release the pendulum from rest and time 10 consecutive oscillations with a precision electronic stopwatch.",
      "Divide elapsed time by 10 to obtain experimental period T, and plot T² versus length L to determine gravity g."
],
    learningPoints: [
      "For small angles (sin θ ≈ θ), the oscillation period of a simple pendulum is strictly independent of bob mass and amplitude.",
      "Period scales with the square root of pendulum length: doubling the period requires quadrupling the string length (T ∝ √L).",
      "The simple pendulum provides an ultra-precise gravimeter for calculating local gravitational acceleration g = 4π²L / T²."
],
    simulationType: 'simple-pendulum',
    equipment: [
      { name: 'Rigid Stand & Clamp', icon: '📐', spec: 'Low-friction pivot knife' },
      { name: 'Fine Filament Cord', icon: '🪢', spec: 'Inextensible 0.2 – 2.0 m string' },
      { name: 'Interchangeable Bobs', icon: '⚪', spec: 'Dense brass/lead spherical masses' },
      { name: 'Laser Beam Photogate', icon: '⏱️', spec: 'Zero-crossing period counter' }
    ],
    controls: [
      { id: 'pendulumLength', label: 'String Length (L)', unit: 'm', min: 0.2, max: 2.0, step: 0.1, defaultValue: 1.0, description: 'Length from pivot point to center of bob' },
      { id: 'bobMass', label: 'Bob Mass (m)', unit: 'kg', min: 0.1, max: 1.0, step: 0.1, defaultValue: 0.3, description: 'Inertial mass of the suspended sphere' },
      { id: 'localGravity', label: 'Gravity (g)', unit: 'm/s²', min: 1.6, max: 24.8, step: 0.1, defaultValue: 9.8, description: 'Gravitational acceleration' }
    ]
  },
  {
    id: 'hookes-law',
    title: "Hooke's Law & Spring Constant",
    category: 'physics',
    subcategory: 'Mechanics & Elasticity',
    topic: 'Elastic Deformation & Potential Energy',
    keywords: ['hooke', 'spring constant', 'force', 'extension', 'elasticity', 'potential energy'],
    shortDescription: 'Stretch helical springs with calibrated tensile loads to determine spring constant k and elastic potential energy.',
    learningObjective: 'Determine the spring constant k from the linear slope of force versus extension and compute stored strain energy.',
    scientificPrinciple: 'F = -k Δx and Elastic Potential Energy U_s = ½ k (Δx)². Restoring force is directly proportional to displacement within the elastic limit.',
    whyItWorks: 'Atomic interatomic potentials near equilibrium approximate a parabolic potential well. Small displacements stretch metallic bonds elastically in direct proportion to applied stress.',
    observationGuide: 'Plotting Force vs Extension produces a straight line whose slope equals the spring constant k in N/m.',
    conclusionTemplate: 'Linear elastic compliance confirmed. Hooke\'s Law holds until reaching the material yield limit.',
    formula: 'F = k·Δx,  U_s = ½·k·(Δx)²',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Mount a helical spring vertically beside a millimeter scale with its top end rigidly clamped.",
      "Record the equilibrium resting position of the spring pointer before adding any external load.",
      "Apply graduated tensile force by suspending calibrated masses from the bottom hook.",
      "Record elongation (extension Δx = x - x₀) for each increment of applied load force.",
      "Plot Applied Force versus Extension to verify Hooke's Law linearity and extract spring stiffness k from the gradient."
],
    learningPoints: [
      "Elastic restoring force is directly proportional to displacement within the material's elastic limit: F = -k · Δx.",
      "The slope of the Force versus Extension graph represents spring constant k (N/m), a measure of elastic stiffness.",
      "Elastic potential energy stored within a stretched spring increases quadratically with elongation: PE = ½ k (Δx)²."
],
    simulationType: 'hookes-law',
    equipment: [
      { name: 'Helical Spring Array', icon: '🪀', spec: 'k = 20 to 100 N/m steel coils' },
      { name: 'Linear Vernier Scale', icon: '📏', spec: 'Millimeter pointer alignment' },
      { name: 'Suspended Weight Hanger', icon: '⚖️', spec: 'Calibrated slotted discs' },
      { name: 'Heavy Cast Iron Base', icon: '📐', spec: 'Vibration dampened mounting' }
    ],
    controls: [
      { id: 'springConstant', label: 'Spring Constant (k)', unit: 'N/m', min: 20, max: 120, step: 10, defaultValue: 50, description: 'Stiffness rating of helical spring' },
      { id: 'appliedForce', label: 'Hanging Force (F)', unit: 'N', min: 1.0, max: 15.0, step: 1.0, defaultValue: 5.0, description: 'Downward gravitational load' }
    ]
  },
  {
    id: 'conservation-energy',
    title: 'Conservation of Mechanical Energy',
    category: 'physics',
    subcategory: 'Mechanics & Dynamics',
    topic: 'Kinetic & Potential Energy Exchange',
    keywords: ['energy', 'conservation of energy', 'kinetic energy', 'potential energy', 'roller coaster', 'mechanics'],
    shortDescription: 'Track total mechanical energy exchange between gravitational potential and kinetic energy on a frictionless track.',
    learningObjective: 'Demonstrate that in an isolated conservative system, total mechanical energy E = KE + PE remains strictly constant.',
    scientificPrinciple: 'E_total = mgh + ½ mv² = constant. As altitude decreases, potential energy transforms into kinetic velocity with 100% theoretical efficiency.',
    whyItWorks: 'Gravity is a conservative vector field. Work done along any path depends solely on start and end elevation, conserving scalar mechanical energy.',
    observationGuide: 'At the crest of the track, kinetic energy is zero and potential energy is maximized. At the trough, speed peaks and potential energy drops to minimum.',
    conclusionTemplate: 'Mechanical energy conserved throughout full trajectory cycle with zero net dissipation.',
    formula: 'E = PE + KE = mgh + ½mv²',
    difficulty: 'Advanced',
    duration: '20 min',
    xpReward: 80,
    procedure: [
      "Configure a frictionless roller coaster track consisting of an initial hill of height h, a valley, and a vertical loop.",
      "Position a test car of mass m at the summit of the initial incline at zero initial velocity.",
      "Release the car and record continuous telemetry for gravitational potential energy (mgh) and kinetic energy (½mv²).",
      "Verify that total mechanical energy (E_total = PE + KE) remains perfectly invariant across every point on the frictionless track.",
      "Calculate the minimum initial launch height required for the car to safely negotiate a vertical loop without falling."
],
    learningPoints: [
      "In an isolated system with conservative forces, total mechanical energy is conserved: ΔE_mechanical = 0.",
      "Gravitational potential energy converts completely into kinetic velocity energy as an object descends: v = √(2gh).",
      "Negotiating a vertical loop of radius R requires minimum top velocity v_min = √(gR) and release height h_min = 2.5 R."
],
    simulationType: 'conservation-energy',
    equipment: [
      { name: 'Curved Roller Track', icon: '🎢', spec: 'Parabolic low-friction rail' },
      { name: 'Dynamics Spherical Car', icon: '⚪', spec: '0.25 kg low-rotational-inertia mass' },
      { name: 'Multi-point Photogates', icon: '⏱️', spec: 'Peak, mid, trough speed gates' },
      { name: 'Digital Energy Bar Display', icon: '📊', spec: 'Real-time KE vs PE bar visualizer' }
    ],
    controls: [
      { id: 'initialHeight', label: 'Release Elevation (h₀)', unit: 'm', min: 0.5, max: 5.0, step: 0.5, defaultValue: 2.5, description: 'Starting height above baseline datum' },
      { id: 'cartMass', label: 'Cart Mass (m)', unit: 'kg', min: 0.2, max: 2.0, step: 0.2, defaultValue: 0.5, description: 'Mass of the moving vehicle' },
      { id: 'frictionLoss', label: 'Friction Drag Loss', unit: '%', min: 0, max: 25, step: 5, defaultValue: 0, description: 'Non-conservative thermal friction loss' }
    ]
  },
  {
    id: 'free-fall',
    title: 'Free Fall & Terminal Velocity',
    category: 'physics',
    subcategory: 'Kinematics & Dynamics',
    topic: 'Gravitational Acceleration & Drag',
    keywords: ['free fall', 'gravity', 'air resistance', 'terminal velocity', 'kinematics'],
    shortDescription: 'Drop spheres of varying density in vacuum and air to observe uniform acceleration g and terminal velocity equilibrium.',
    learningObjective: 'Compare theoretical vacuum free fall with aerodynamic drag and calculate terminal velocity.',
    scientificPrinciple: 'In vacuum: v = gt, d = ½ gt². In air: F_net = mg - ½ ρ C_d A v², reaching terminal velocity v_t when drag equals weight.',
    whyItWorks: 'In a vacuum, gravitational force mg produces identical acceleration g for all bodies regardless of mass. In fluids, aerodynamic drag scales with velocity squared.',
    observationGuide: 'A bowling ball and feather fall together in a vacuum chamber. In air, the feather quickly reaches terminal velocity while the ball accelerates.',
    conclusionTemplate: 'Galileo\'s equivalence principle confirmed in vacuum. Terminal velocity reached when aerodynamic drag balances gravitational weight.',
    formula: 'v = gt,  v_t = √(2mg / (ρ A C_d))',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Set up the vertical vacuum drop tube with dual optical infrared photogates spaced at calibrated distances.",
      "Mount a polished spherical test mass at the electromagnetic release mechanism at the top of the column.",
      "Select environmental vacuum condition (vacuum chamber vs atmospheric air with aerodynamic drag).",
      "De-energize the electromagnet to initiate free fall and record transit times between photogates.",
      "Calculate acceleration from kinematic equation y = ½ g t² and compare free fall in vacuum to terminal velocity in air."
],
    learningPoints: [
      "In a vacuum, all objects accelerate at the identical rate g regardless of mass, density, or shape (Galileo's Equivalence Principle).",
      "In the presence of air, aerodynamic drag opposes motion, increasing quadratically with velocity until F_drag = F_gravity.",
      "When drag force balances gravitational weight, net acceleration drops to zero and the falling body achieves terminal velocity."
],
    simulationType: 'free-fall',
    equipment: [
      { name: 'Vertical Drop Tube', icon: '📏', spec: '3.0 meter transparent test column' },
      { name: 'Rotary Vacuum Pump', icon: '🎛️', spec: 'Evacuates to 10⁻² Torr' },
      { name: 'Electromagnetic Drop Latch', icon: '🧲', spec: 'Simultaneous dual release' },
      { name: 'High-speed Optical Gates', icon: '⏱️', spec: 'Microsecond transit timer' }
    ],
    controls: [
      { id: 'dropHeight', label: 'Release Height (h)', unit: 'm', min: 1, max: 10, step: 1, defaultValue: 5, description: 'Vertical descent distance' },
      { id: 'airDensity', label: 'Medium Air Drag', unit: '', min: 0, max: 1, step: 1, defaultValue: 0, description: '0: Pure Vacuum (No drag), 1: Standard Atmosphere' },
      { id: 'objectMass', label: 'Object Mass', unit: 'kg', min: 0.05, max: 2.0, step: 0.05, defaultValue: 0.2, description: 'Mass of the dropped sphere' }
    ]
  },
  {
    id: 'density-measurement',
    title: 'Density & Archimedes Buoyant Force',
    category: 'physics',
    subcategory: 'Fluid Mechanics',
    topic: 'Density & Buoyancy',
    keywords: ['density', 'buoyancy', 'archimedes', 'fluids', 'volume displacement'],
    shortDescription: 'Submerge solid specimens in fluid cylinders to determine density through water displacement and measure buoyant uplift.',
    learningObjective: 'Calculate volumetric density ρ = m/V and verify Archimedes\' Principle: buoyant force equals the weight of displaced fluid.',
    scientificPrinciple: 'ρ = m / V and F_b = ρ_fluid × V_displaced × g. An object floats if ρ_object < ρ_fluid and sinks if ρ_object > ρ_fluid.',
    whyItWorks: 'Fluid pressure increases linearly with depth (P = ρgh). The pressure on the bottom of a submerged body exceeds the top, producing net upward buoyant force.',
    observationGuide: 'The apparent weight of the submerged brass cylinder decreases by exactly the mass of water collected in the overflow beaker.',
    conclusionTemplate: 'Archimedes\' Principle confirmed: buoyant force F_b equals displaced fluid weight.',
    formula: 'ρ = m / V,  F_b = ρ_fluid · V_disp · g',
    difficulty: 'Beginner',
    duration: '10 min',
    xpReward: 30,
    procedure: [
      "Calibrate an electronic analytical balance and determine the dry mass (m) of unknown solid sample cylinders.",
      "Fill a graduated cylinder with a precise initial volume of water (V_initial) and record the meniscus baseline.",
      "Lower the solid sample gently into the cylinder using a fine nylon thread to prevent splashing.",
      "Record the new liquid volume (V_final) to compute solid displacement volume: ΔV = V_final - V_initial.",
      "Calculate density ρ = m / ΔV and immerse the object into water, oil, and brine to test Archimedes buoyant floating behavior."
],
    learningPoints: [
      "Density is an intensive physical property defined as mass per unit volume: ρ = m / V.",
      "Archimedes' Principle states that an immersed body experiences an upward buoyant force equal to the weight of displaced fluid.",
      "An object floats if its average density is strictly less than the fluid density, displacing only a fraction of its own volume."
],
    simulationType: 'density-measurement',
    equipment: [
      { name: 'Eureka Displacement Can', icon: '🍶', spec: 'Overflow spout graduated beaker' },
      { name: 'Spring Force Dynamometer', icon: '⚖️', spec: 'Dual scale mass/Newtons' },
      { name: 'Solid Metal Cylinders', icon: '⚪', spec: 'Aluminum, Iron, Gold test cubes' },
      { name: 'Fluid Reservoir Tank', icon: '💧', spec: 'Water (1.0 g/cm³) & Saltwater' }
    ],
    controls: [
      { id: 'specimenMass', label: 'Specimen Mass (m)', unit: 'g', min: 50, max: 500, step: 25, defaultValue: 200, description: 'Dry mass on analytical balance' },
      { id: 'specimenVolume', label: 'Displaced Volume (V)', unit: 'cm³', min: 20, max: 150, step: 5, defaultValue: 50, description: 'Volume determined by displacement' },
      { id: 'fluidDensity', label: 'Fluid Density', unit: 'g/cm³', min: 0.8, max: 1.3, step: 0.1, defaultValue: 1.0, description: '0.8: Oil, 1.0: Pure Water, 1.3: Dense Brine' }
    ]
  },
  {
    id: 'refraction-light',
    title: "Refraction of Light & Snell's Law",
    category: 'physics',
    subcategory: 'Optics & Waves',
    topic: 'Snell\'s Law & Critical Angle',
    keywords: ['refraction', 'snell', 'optics', 'index of refraction', 'light', 'critical angle', 'reflection'],
    shortDescription: 'Direct a laser ray through air-glass and air-water interfaces to calculate refractive indices and observe total internal reflection.',
    learningObjective: 'Measure angles of incidence and refraction to verify Snell\'s Law and calculate the critical angle for total internal reflection.',
    scientificPrinciple: 'n₁ sin(θ₁) = n₂ sin(θ₂). Critical angle θ_c = arcsin(n₂ / n₁) when transitioning from denser to rarer medium.',
    whyItWorks: 'Light alters phase velocity when crossing boundaries between optical media with differing polarizabilities, bending toward the normal in slower media.',
    observationGuide: 'Light bends toward the normal upon entering acrylic. Exceeding the critical angle produces 100% reflective total internal reflection.',
    conclusionTemplate: 'Snell\'s law confirmed. Measured index of refraction matches theoretical optical material specifications.',
    formula: 'n₁ sin θ₁ = n₂ sin θ₂,  θ_c = arcsin(n₂/n₁)',
    difficulty: 'Intermediate',
    duration: '15 min',
    xpReward: 50,
    procedure: [
      "Mount a semicircular acrylic/glass prism on the center of a 360° graduated optical ray table.",
      "Align a collimated laser diode to direct a narrow beam of light toward the flat boundary face at the center point.",
      "Set the incident angle (θ₁) on the protractor scale and observe the transmitted refracted ray angle (θ₂).",
      "Vary the incident angle from 10° to 80° in increments of 10°, recording corresponding angles of refraction.",
      "Plot sin(θ₁) versus sin(θ₂) to verify Snell's Law and determine the refractive index n = sin(θ₁) / sin(θ₂)."
],
    learningPoints: [
      "Snell's Law governs light refraction across optical boundaries: n₁ sin(θ₁) = n₂ sin(θ₂).",
      "Light bends toward the surface normal when entering an optically denser medium due to reduced phase velocity: v = c / n.",
      "Total Internal Reflection occurs when light travels from dense to rare media at incident angles exceeding the critical angle θ_c."
],
    simulationType: 'refraction-light',
    equipment: [
      { name: 'Diode Red Laser Pointer', icon: '🔦', spec: '650 nm monochromatic collimated ray' },
      { name: 'Semicircular Acrylic Block', icon: '🧊', spec: 'Optical grade PMMA (n = 1.49)' },
      { name: '360° Circular Protractor', icon: '📐', spec: '0.5° angular division plate' },
      { name: 'Water Tank Interface', icon: '💧', spec: 'Liquid boundary cell (n = 1.33)' }
    ],
    controls: [
      { id: 'incidentAngle', label: 'Incident Angle (θ₁)', unit: '°', min: 0, max: 85, step: 5, defaultValue: 40, description: 'Angle of incidence relative to surface normal' },
      { id: 'mediumIndex', label: 'Refractive Index (n₂)', unit: '', min: 1.0, max: 2.4, step: 0.1, defaultValue: 1.5, description: '1.33: Water, 1.50: Crown Glass, 2.42: Diamond' }
    ]
  },
  {
    id: 'lens-focal-length',
    title: 'Lens Focal Length & Thin Lens Formula',
    category: 'physics',
    subcategory: 'Optics & Waves',
    topic: 'Convex Lenses & Ray Optics',
    keywords: ['lens', 'focal length', 'thin lens formula', 'magnification', 'real image', 'optics'],
    shortDescription: 'Project real inverted images of an optical object onto a screen to verify 1/f = 1/d_o + 1/d_i and calculate optical magnification.',
    learningObjective: 'Verify the Thin Lens Equation by varying object distance and measuring focal plane image location and magnification.',
    scientificPrinciple: '1/f = 1/d_o + 1/d_i and Magnification M = -d_i / d_o = h_i / h_o. Real images form on screens when object distance d_o > f.',
    whyItWorks: 'Curved spherical lens surfaces refract parallel rays to converge at a focal point f. Geometry of similar triangles dictates conjugate image positions.',
    observationGuide: 'When d_o = 2f, image distance d_i = 2f and magnification M = -1.0 (inverted, exact same size). As object approaches f, image moves to infinity.',
    conclusionTemplate: 'Thin Lens equation verified. Focal length determined to within 1% experimental uncertainty.',
    formula: '1/f = 1/d_o + 1/d_i,  M = -d_i / d_o',
    difficulty: 'Advanced',
    duration: '20 min',
    xpReward: 80,
    procedure: [
      "Mount a biconvex converging thin lens, an illuminated object target, and a projection screen on an optical bench.",
      "Position the illuminated object at a distance d_o greater than twice the lens focal length (d_o > 2f).",
      "Slide the ground glass image screen along the track until a razor-sharp inverted real image appears.",
      "Measure object distance d_o and image distance d_i from the optical center of the lens.",
      "Calculate focal length using the Thin Lens Equation 1/f = 1/d_o + 1/d_i and measure optical magnification M = -d_i / d_o."
],
    learningPoints: [
      "The Thin Lens Equation (1/f = 1/d_o + 1/d_i) mathematically relates object distance, image distance, and lens focal length.",
      "Converging convex lenses produce real, inverted images on screens when the object is placed outside the focal point (d_o > f).",
      "Optical magnification M = -d_i / d_o: negative magnification signifies image inversion, while |M| > 1 indicates image enlargement."
],
    simulationType: 'lens-focal-length',
    equipment: [
      { name: 'Optical Bench Rail', icon: '📏', spec: '1.5 meter graduated precision track' },
      { name: 'Illuminated Object Target', icon: '🕯️', spec: 'Luminescent "F" aperture light' },
      { name: 'Biconvex Converging Lens', icon: '🔭', spec: 'f = +10 cm coated glass' },
      { name: 'Ground Glass Image Screen', icon: '⬜', spec: 'Milky focal projection target' }
    ],
    controls: [
      { id: 'focalLength', label: 'Lens Focal Length (f)', unit: 'cm', min: 5, max: 25, step: 1, defaultValue: 10, description: 'Inherent optical focal distance of lens' },
      { id: 'objectDistance', label: 'Object Distance (d_o)', unit: 'cm', min: 11, max: 50, step: 1, defaultValue: 25, description: 'Distance from illuminated target to lens' }
    ]
  },
  {
    id: 'wave-motion',
    title: 'Wave Motion & Standing Waves',
    category: 'physics',
    subcategory: 'Oscillations & Waves',
    topic: 'Standing Waves & Resonance',
    keywords: ['wave', 'frequency', 'wavelength', 'standing waves', 'harmonics', 'nodes', 'antinodes'],
    shortDescription: 'Vibrate an elastic tensioned cord with a mechanical oscillator to generate standing wave harmonics, nodes, and antinodes.',
    learningObjective: 'Demonstrate wave speed v = f × λ and observe harmonic standing wave resonance on a string fixed at both ends.',
    scientificPrinciple: 'v = f × λ and v = √(T_tension / μ_linear). Standing wave modes occur when string length L = n (λ / 2) for integer harmonics n.',
    whyItWorks: 'Continuous reflection and superposition of identical forward and backward propagating waves produces stationary nodes (zero vibration) and antinodes (maximum amplitude).',
    observationGuide: 'Increasing oscillator frequency through resonant modes produces 1, 2, 3, and 4 clean harmonic loops with stationary nodal points.',
    conclusionTemplate: 'Harmonic resonance conditions verified: λ_n = 2L/n, confirming fundamental wave equation v = f λ.',
    formula: 'v = f · λ = √(T / μ),  L = n·(λ / 2)',
    difficulty: 'Expert',
    duration: '20 min',
    xpReward: 120,
    procedure: [
      "Clamp an elastic string of linear mass density μ to a variable-frequency electromechanical sine oscillator.",
      "Pass the distal end of the string over a low-friction pulley and attach suspended weights to set tension T.",
      "Power on the wave driver at 10 Hz and gradually increase vibration frequency while inspecting the string.",
      "Locate resonant frequencies where stationary standing wave harmonics (n = 1, 2, 3, 4 antinode loops) form.",
      "Measure the distance between adjacent stationary nodes (λ/2) to determine wavelength and confirm wave speed v = f · λ = √(T/μ)."
],
    learningPoints: [
      "Standing waves arise from the superposition and constructive/destructive interference of identical forward and reflected traveling waves.",
      "Nodes are stationary points of zero displacement; antinodes are points of maximum vibrational amplitude.",
      "Wave speed along a tensioned string depends strictly on mechanical medium properties: v = √(T / μ)."
],
    simulationType: 'wave-motion',
    equipment: [
      { name: 'Electromechanical Wave Driver', icon: '🔊', spec: '1 – 200 Hz digital sine oscillator' },
      { name: 'Braided Elastic String', icon: '🪢', spec: 'Linear mass density μ = 0.002 kg/m' },
      { name: 'Tension Pulley System', icon: '⚖️', spec: 'Adjustable suspended weight load' },
      { name: 'Stroboscopic Inspection Lamp', icon: '💡', spec: 'Phase-synchronized motion freeze' }
    ],
    controls: [
      { id: 'waveFrequency', label: 'Oscillator Frequency (f)', unit: 'Hz', min: 10, max: 120, step: 5, defaultValue: 40, description: 'Vibration frequency of the mechanical driver' },
      { id: 'stringTension', label: 'String Tension (T)', unit: 'N', min: 1, max: 10, step: 1, defaultValue: 4, description: 'Tensile force stretching the cord' },
      { id: 'stringLength', label: 'String Length (L)', unit: 'm', min: 1.0, max: 3.0, step: 0.5, defaultValue: 1.5, description: 'Distance between fixed boundary nodes' }
    ]
  }
];
